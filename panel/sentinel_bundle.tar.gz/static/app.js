/* Sentinel front-end. Vanilla ES2022, no dependencies. */
'use strict';
const P = location.pathname.replace(/\/$/, '');
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
/* Extension points: feature blocks at the end of this file register here. */
const HOOKS = {
  refresh: [],   // fn(data) after every dashboard poll
  settings: [],  // fn(settings, data) when the Settings page is filled
  drawer: [],    // fn(config, detail, live) -> HTML placed in the config drawer above the Name field
  drawerBind: [],// fn(config, detail, live) after the drawer HTML is in the page
};
const S = { data: null, range: '24h', view: localStorage.getItem('sentinel_view') || 'cards', tab: 'dashboard', drawerId: null, sparks: {}, polling: null, paused: false };

/* ---------- toast ---------- */
let toastT;
function toast(msg, kind = 'ok') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast';
  el.style.border = kind === 'err' ? '1px solid var(--er)' : '1px solid var(--ln2)';
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.add('hidden'), 3500);
}

/* ---------- api ---------- */
async function api(path, body) {
  const r = await fetch(`${P}/api/${path}`, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { 'X-R': '1', 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (r.status === 401 && path !== 'login') { showLogin(); throw new Error('unauthorized'); }
  return r;
}
const getJSON = async p => (await api(p)).json();

/* ---------- format helpers ---------- */
const ago = ts => {
  if (!ts) return '—';
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)}m ago` : s < 86400 ? `${Math.round(s / 3600)}h ago` : `${Math.round(s / 86400)}d ago`;
};
const dur = s => s < 60 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${Math.floor(s / 3600)}h ${Math.floor(s % 3600 / 60)}m`;
const when = ts => ts ? new Date(ts * 1000).toLocaleString() : '—';
const latColor = ms => ms == null ? 'var(--mu)' : ms < 250 ? 'var(--ok)' : ms < 600 ? 'var(--wr)' : 'var(--er)';
const state = c => c.state || (c.enabled === 0 ? 'paused' : (c.is_down && c.ok_iran === 1) ? 'iran_only' : c.is_down ? 'down' : c.last_ok === 1 ? 'up' : c.last_ok === 0 ? 'fail' : 'new');
const badge = c => ({
  paused: '<span class="badge dim"><span class="dot"></span>PAUSED</span>',
  iran_only: '<span class="badge warn" title="International blocked, Iran intranet connected"><span class="dot"></span>IRAN ONLY</span>',
  down: '<span class="badge err"><span class="dot"></span>DOWN</span>',
  up: '<span class="badge ok"><span class="dot"></span>ONLINE</span>',
  fail: '<span class="badge warn"><span class="dot"></span>FAILING</span>',
  slow: '<span class="badge warn" title="Works, but slower than the limit in Settings"><span class="dot"></span>SLOW</span>',
  no_engine: `<span class="badge dim" title="${esc(c.engine_note || 'This protocol needs sing-box, which is not installed')}"><span class="dot"></span>NEEDS SING-BOX</span>`,
  new: '<span class="badge dim"><span class="dot"></span>QUEUED</span>',
}[state(c)] || '');
const _px = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
function rgba(css, a) { _px.clearRect(0, 0, 1, 1); _px.fillStyle = '#38bdf8'; _px.fillStyle = css; _px.fillRect(0, 0, 1, 1); const [r, g, b] = _px.getImageData(0, 0, 1, 1).data; return `rgba(${r},${g},${b},${a})`; }
const speedPill = c => c.last_speed_mbps
  ? `<span class="pill pill-speed" title="Latest speed test, ${ago(c.last_speed_time)}">⚡ ${c.last_speed_mbps} Mbps</span>`
  : '';
const subBadge = c => c.sub_name
  ? `<span class="pill pill-sub" title="${esc(c.sub_url || '')}">Feed: ${esc(c.sub_name)}</span>`
  : `<span class="pill pill-port">Manual</span>`;
// Names often start with their own flag; show the country flag only when they don't.
const RI_FLAG = /^\s*[\u{1F1E6}-\u{1F1FF}]{2}/u;
const nameHtml = c => `${c.country_flag && !RI_FLAG.test(c.name || '') ? `<span class="cfg-flag" title="${esc(c.country_name || c.country_code)}">${c.country_flag}</span> ` : ''}${esc(c.name)}`;
// Down and failing configs first, paused last; the rest keep their order.
const STATE_RANK = { down: 0, iran_only: 1, fail: 2, no_engine: 3, slow: 4, up: 5, new: 6, paused: 7 };
const byState = list => [...list].sort((a, b) => STATE_RANK[state(a)] - STATE_RANK[state(b)]);
// Probe errors in plain words; the raw curl text stays in the tooltip.
function humanErr(e) {
  const t = String(e || '');
  if (!t) return '';
  if (/^(Xray rejected|This Xray|Hysteria2 needs|sing-box rejected|Needs )/.test(t)) return t;
  const m = [
    [/\(28\)|timed out/i, 'No answer before the timeout'],
    [/\(56\)|reset by peer/i, 'The server closed the connection'],
    [/\(7\)|Couldn't connect|Failed to connect/i, 'Could not connect to the local proxy (Xray is not running?)'],
    [/\(97\)|SOCKS/i, 'The proxy could not reach the server'],
    [/\(35\)|SSL|TLS/i, 'TLS handshake failed'],
    [/\(6\)|resolve/i, 'Could not resolve the address'],
    [/HTTP (\d+)/, x => `The probe URL answered HTTP ${t.match(/HTTP (\d+)/)[1]}`],
  ].find(([re]) => re.test(t));
  return m ? (typeof m[1] === 'function' ? m[1]() : m[1]) : t;
}
const errBox = (e, mono) => `<div class="cfg-err" title="${esc(e)}">${esc(humanErr(e))}${humanErr(e) !== e ? `<span class="cfg-err-raw${mono ? '' : ' u-hide-sm'}">${esc(e)}</span>` : ''}</div>`;
const noteBox = t => `<div class="cfg-note">${esc(t)}</div>`;  // a step to take, not a failure
const secPill = c => c.security && c.security !== 'none' ? `<span class="pill pill-sec">${esc(c.security)}</span>` : '';
const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--ac').trim() || '#38bdf8';

/* ---------- auth / shell ---------- */
function showLogin() { $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); stopPolling(); }
function showApp() { $('#login').classList.add('hidden'); $('#app').classList.remove('hidden'); startPolling(); }

$('#toggle').addEventListener('click', () => {
  const i = $('#p'), show = i.type === 'password';
  i.type = show ? 'text' : 'password';
  $('#eye').innerHTML = '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>' + (show ? '<path d="M3 3l18 18"/>' : '');
});
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = $('#loginBtn'); btn.disabled = true;
  const totpCode = ($('#totpCode')?.value || '').trim();
  try {
    const r = await api('login', { password: $('#p').value, totp_code: totpCode });
    const d = await r.json().catch(() => ({}));
    if (r.ok) {
      $('#p').value = ''; if ($('#totpCode')) $('#totpCode').value = '';
      $('#codeField')?.classList.add('hidden');
      $('#loginErr').textContent = '';
      showApp(); await refresh();
    } else {
      if (d.need_2fa) {
        $('#codeField').classList.remove('hidden');
        $('#totpCode').focus();
        $('#loginErr').textContent = totpCode ? 'Invalid 6-digit code.' : 'Enter 6-digit 2FA code from authenticator app.';
      } else {
        $('#loginErr').textContent = r.status === 429 ? 'Too many attempts. Wait 5 minutes.' : (d.error || 'Invalid password.');
      }
    }
  } catch { $('#loginErr').textContent = 'Network or server error.'; }
  btn.disabled = false;
});
$('#logoutBtn').addEventListener('click', async () => { await api('logout', {}); showLogin(); });

/* ---------- tabs ---------- */
const TITLES = { dashboard: ['Dashboard', 'Live Edge Health · Real-time Probes'], configs: ['Configs', 'Every node Sentinel probes'], speedtest: ['Speed Test', '100MB CDN benchmark & node throughput ranking'], incidents: ['Incidents', 'Outage & recovery history'], settings: ['Settings', 'Health checks, Telegram, notifications and security'] };
function switchTab(name) {
  S.tab = name;
  $$('#sideNav .nav-item').forEach(b => { b.classList.toggle('on', b.dataset.tab === name); b.setAttribute('aria-selected', b.dataset.tab === name); });
  $$('main.page > section').forEach(s => s.classList.toggle('hidden', s.id !== `tab-${name}`));
  [$('#topTitle').textContent, $('#subRole').textContent] = TITLES[name];
  history.replaceState(null, '', `#${name}`);
  window.scrollTo(0, 0); const pg = $('main.page'); if (pg) pg.scrollTop = 0;
  if (name === 'incidents') loadIncidents();
  if (name === 'dashboard') requestAnimationFrame(drawHistory);
  if (name === 'speedtest') renderSpeedTestTab();
  if (name === 'settings') load2FaStatus();
}
$$('#sideNav .nav-item').forEach(b => b.addEventListener('click', () => switchTab(b.dataset.tab)));

/* ---------- polling ---------- */
function startPolling() { stopPolling(); S.polling = setInterval(() => { if (!document.hidden) refresh(); }, 3000); }
function stopPolling() { clearInterval(S.polling); S.polling = null; }
async function refresh() {
  try {
    S.data = await getJSON('dashboard');
    S.sparks = await getJSON('sparks').catch(() => S.sparks);
    if (!S._st || Date.now() - S._st > 30000) { S._st = Date.now(); loadSubs(); loadCleanSub(); }
    render();
    if (S.drawerId) loadDrawer(S.drawerId, true);
    if (S.tab === 'speedtest') renderSpeedTestTab();
  } catch { /* 401 handled in api() */ }
}

/* ---------- render ---------- */
function render() {
  const d = S.data; if (!d) return;
  const cfgs = d.configs || [];
  const n = st => cfgs.filter(c => state(c) === st).length;
  const up = n('up'), slow = n('slow'), down = n('down');
  const enabled = cfgs.filter(c => c.enabled !== 0).length;
  const lats = cfgs.filter(c => (state(c) === 'up' || state(c) === 'slow') && c.latency).map(c => c.latency);
  const avg = lats.length ? Math.round(lats.reduce((a, b) => a + b, 0) / lats.length) : null;
  const setKpi = (id, val, color, sub) => { const v = $(`#${id}`); v.textContent = val; v.style.color = color; $(`#${id}Sub`).textContent = sub; };
  setKpi('kpiUp', up, up ? 'var(--ok)' : 'var(--tx)', `Out of ${enabled} enabled`);
  const lim = +(d.settings.slow_ms || 0);
  setKpi('kpiSlow', slow, slow ? 'var(--wr)' : 'var(--tx)', lim ? `Slower than ${lim} ms` : 'No limit set in Settings');
  const longest = Math.min(...cfgs.filter(c => state(c) === 'down' && c.down_since).map(c => c.down_since));
  setKpi('kpiDown', down, down ? 'var(--er)' : 'var(--tx)', down && isFinite(longest) ? `Longest for ${dur(Math.round(Date.now() / 1000 - longest))}` : 'No outage now');
  const ut = d.uptime_30d;
  setKpi('kpiUptime', ut == null ? '—' : `${ut}%`, ut == null ? 'var(--tx)' : ut >= 99 ? 'var(--ok)' : ut >= 95 ? 'var(--wr)' : 'var(--er)', avg ? `Average latency now ${avg} ms` : 'No working config now');
  renderAttention(d, cfgs);
  fillChartCfg(cfgs);
  // The nav badge counts outages in red, otherwise all configs in grey.
  const nb = $('#cfgBadge'); nb.textContent = down || cfgs.length; nb.className = `badge sm nav-badge ${down ? 'err' : 'dim'}`; nb.title = down ? `${down} down` : `${cfgs.length} configs`;
  const tg = $('#kpiTg'); if (tg) tg.textContent = d.settings.token_configured && d.settings.chat_configured ? 'Connected' : 'Not set';
  $('#kpiTgSub').textContent = d.pending_alerts ? `${d.pending_alerts} alert(s) queued` : 'No queued alerts';

  renderDashTable(byState(cfgs));
  updateSubFilterOptions(cfgs);
  renderConfigs(cfgs);
  if (!$('#tab-settings').dataset.filled) {
    fillSettings(d.settings);
    HOOKS.settings.forEach(f => { try { f(d.settings, d); } catch (e) { console.error(e); } });
    $('#tab-settings').dataset.filled = '1';
  }
  HOOKS.refresh.forEach(f => { try { f(d); } catch (e) { console.error(e); } });
  $$('.acc-btn').forEach(b => b.classList.toggle('selected', b.dataset.acc === document.documentElement.dataset.acc));
}

/* ---------- attention strip: what needs a look now, worst first ---------- */
function attentionItems(d, cfgs) {
  const now = Date.now() / 1000, lim = +(d.settings.slow_ms || 0), out = [];
  for (const c of byState(cfgs)) {
    const st = state(c), name = c.name;
    if (st === 'down') out.push({ sev: 'err', id: c.id, name, text: `Down for ${dur(Math.round(now - (c.down_since || now)))}`, why: c.down_why || humanErr(c.last_error) });
    else if (st === 'iran_only') out.push({ sev: 'warn', id: c.id, name, text: 'Reaches Iranian sites only', why: 'International traffic does not get through' });
    else if (st === 'fail') out.push({ sev: 'warn', id: c.id, name, text: 'Failed its last check', why: humanErr(c.last_error) });
    else if (st === 'slow') out.push({ sev: 'warn', id: c.id, name, text: 'Slow', why: c.latency && lim && c.latency > lim ? `${c.latency} ms, the limit is ${lim} ms` : c.last_speed_mbps ? `${c.last_speed_mbps} Mbps in the last speed test` : '' });
  }
  const ne = cfgs.filter(c => state(c) === 'no_engine').length;
  if (ne) out.push({ sev: 'info', go: 'engines', name: `${ne} config${ne > 1 ? 's' : ''} need${ne > 1 ? '' : 's'} sing-box`, text: 'Not checked until it is installed', why: 'Install it in Settings, Engines' });
  for (const x of S.subs || []) if (x.enabled && x.last_sync && !x.last_ok) out.push({ sev: 'warn', go: 'feeds', name: `Feed ${x.name}`, text: 'Did not sync', why: humanErr(x.last_msg) });
  return out;
}
function renderAttention(d, cfgs) {
  const el = $('#attn'); if (!el) return;
  const items = attentionItems(d, cfgs), on = cfgs.filter(c => c.enabled !== 0).length;
  if (!cfgs.length) { el.innerHTML = ''; return; }
  if (!items.length) { el.innerHTML = `<div class="attn-ok"><span class="dot"></span>All ${on} enabled configs are working.</div>`; return; }
  const MAX = 5, more = items.length - MAX;
  el.innerHTML = `<div class="attn-list">${items.slice(0, MAX).map((x, i) => `
    <button type="button" class="attn-row attn-${x.sev}" data-attn="${i}">
      <span class="dot"></span><span class="attn-name">${esc(x.name)}</span><span class="attn-text">${esc(x.text)}</span>
      <span class="attn-why">${esc(x.why || '')}</span></button>`).join('')}
    ${more > 0 ? `<button type="button" class="attn-more" data-attn="more">${more} more in Configs</button>` : ''}</div>`;
  el.onclick = e => {
    const b = e.target.closest('[data-attn]'); if (!b) return;
    const x = items[+b.dataset.attn];
    if (!x) return switchTab('configs');
    if (x.id) return openDrawer(x.id);
    if (x.go === 'feeds') { switchTab('configs'); return openSubs(); }
    switchTab('settings'); requestAnimationFrame(() => $('#set-engines')?.scrollIntoView({ block: 'start' }));
  };
}

function spark(id, w = 100, h = 26) {
  const v = S.sparks[id];
  if (!v || v.length < 2) return '';
  const nums = v.filter(x => x != null), mx = Math.max(...nums, 1), step = w / (v.length - 1);
  let d = '', pen = false;
  v.forEach((x, i) => { if (x == null) { pen = false; return; } d += `${pen ? 'L' : 'M'}${(i * step).toFixed(1)},${(h - 2 - (x / mx) * (h - 4)).toFixed(1)} `; pen = true; });
  const fails = v.map((x, i) => x == null ? `<circle cx="${(i * step).toFixed(1)}" cy="${h - 2}" r="1.6" fill="var(--er)"/>` : '').join('');
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="${accent()}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>${fails}</svg>`;
}

function renderSlaBars(bars) {
  if (!bars || !bars.length) return '';
  return `<div class="sla-bar-wrap" title="24h SLA Health History">` + bars.map(b => {
    let cls = 'none';
    let tip = `${b.h}: No checks`;
    if (b.status === 1) {
      cls = 'up';
      tip = `${b.h}: 100% UP${b.ms ? ` (${b.ms}ms)` : ''}`;
    } else if (b.status === 0) {
      cls = 'down';
      tip = `${b.h}: 100% Outage`;
    } else if (b.status === 2) {
      cls = 'degraded';
      tip = `${b.h}: Degraded (${b.up_pct}% UP${b.ms ? `, ${b.ms}ms` : ''})`;
    }
    return `<div class="sla-bar ${cls}" title="${esc(tip)}"></div>`;
  }).join('') + `</div>`;
}

function renderDashTable(cfgs) {
  $('#dashTable').innerHTML = cfgs.length ? cfgs.map(c => `
    <tr data-open="${c.id}" style="cursor:pointer">
      <td><strong>${nameHtml(c)}</strong></td>
      <td class="cfg-addr">${esc(c.addr)}</td>
      <td>${subBadge(c)}</td>
      <td>${badge(c)}</td>
      <td class="mono" style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</td>
      <td>${c.uptime != null ? c.uptime + '%' : '—'}</td>
      <td><div style="display:flex;flex-direction:column;gap:3px;min-width:130px"><div class="cfg-spark-wrap">${spark(c.id)}</div>${renderSlaBars(c.sla_bars)}</div></td>
      <td style="color:var(--mu);font-size:12px">${ago(c.last_check)}</td>
    </tr>`).join('')
    : '<tr><td colspan="8" class="u-mu" style="text-align:center;padding:28px">No configs yet. Open <b>Configs</b> and import some.</td></tr>';
}

function updateSubFilterOptions(cfgs) {
  const sel = $('#cfgSubFilter'); if (!sel) return;
  const curVal = sel.value;
  const groups = {};
  let manualCount = 0;
  for (const c of cfgs) {
    if (c.sub_id) {
      if (!groups[c.sub_id]) groups[c.sub_id] = { name: c.sub_name || c.sub_id, count: 0 };
      groups[c.sub_id].count++;
    } else {
      manualCount++;
    }
  }
  let opts = `<option value="">All Sources (${cfgs.length})</option>`;
  for (const [sid, g] of Object.entries(groups)) {
    opts += `<option value="${esc(sid)}">${esc(g.name)} (${g.count})</option>`;
  }
  if (manualCount > 0) {
    opts += `<option value="__manual__">Manual (${manualCount})</option>`;
  }
  sel.innerHTML = opts;
  if (curVal && (curVal === '__manual__' || groups[curVal])) sel.value = curVal;
}

function renderConfigs(cfgs) {
  const q = ($('#cfgSearch').value || '').toLowerCase();
  const subSel = $('#cfgSubFilter')?.value || '';
  const list = byState(cfgs).filter(c => {
    if (subSel === '__manual__' && c.sub_id) return false;
    if (subSel && subSel !== '__manual__' && c.sub_id !== subSel) return false;
    if (q && !c.name.toLowerCase().includes(q) && !c.addr.toLowerCase().includes(q)) return false;
    return true;
  });
  $$('.view-seg button').forEach(b => b.classList.toggle('on', b.dataset.v === S.view));
  $('#cfgGrid').classList.toggle('hidden', S.view !== 'cards');
  $('#cfgTableWrap').classList.toggle('hidden', S.view !== 'table');
  if (!list.length) {
    const msg = `<div style="grid-column:1/-1;text-align:center;padding:48px 16px;color:var(--mu)">${cfgs.length ? 'No match.' : 'No configs registered yet. Click <b>Import Configs</b> to start.'}</div>`;
    $('#cfgGrid').innerHTML = msg; $('#cfgTable').innerHTML = `<tr><td colspan="7" class="u-mu" style="text-align:center;padding:24px">${cfgs.length ? 'No match.' : 'No configs.'}</td></tr>`;
    return;
  }
  $('#cfgGrid').innerHTML = list.map(c => `
    <div class="cfg-card" data-open="${c.id}" style="${c.enabled === 0 ? 'opacity:.6' : ''}">
      <div class="cfg-head"><div><div class="cfg-title">${nameHtml(c)}</div><div class="cfg-addr">${esc(c.addr)}</div></div>${badge(c)}</div>
      <div class="cfg-pills"><span class="pill pill-proto">${esc((c.protocol || 'vless').toUpperCase())}</span><span class="pill pill-net">${esc(c.network || 'tcp')}</span>${secPill(c)}${subBadge(c)}${speedPill(c)}</div>
      <div class="cfg-spark-wrap" style="width:100%;height:32px">${spark(c.id, 300, 32)}</div>
      ${renderSlaBars(c.sla_bars)}
      ${(state(c) === 'down' || state(c) === 'fail') && c.last_error ? errBox(c.last_error) : state(c) === 'no_engine' && c.engine_note ? noteBox(c.engine_note) : ''}
      <div class="cfg-meta"><span>Ping <b style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</b></span><span>Uptime <b style="color:var(--tx)">${c.uptime != null ? c.uptime + '%' : '—'}</b></span><span>${ago(c.last_check)}</span></div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding-top:4px;border-top:1px dashed var(--ln)">
        <button class="hashem-btn hashem-btn-secondary sm" data-sp-test="${c.id}" onclick="event.stopPropagation()" ${state(c) === 'paused' || state(c) === 'no_engine' ? 'disabled' : ''}>⚡ Speed test</button>
        <span style="font-size:11px;color:var(--dim)">${c.last_speed_mbps ? c.last_speed_mbps + ' Mbps' : 'Not tested'}</span>
      </div>
    </div>`).join('');
  $('#cfgTable').innerHTML = list.map(c => `
    <tr data-open="${c.id}" style="cursor:pointer;${c.enabled === 0 ? 'opacity:.6' : ''}">
      <td><strong>${nameHtml(c)}</strong></td><td class="cfg-addr">${esc(c.addr)}</td>
      <td>${subBadge(c)}</td>
      <td><span class="pill pill-proto">${esc((c.protocol || 'vless').toUpperCase())}</span> <span class="pill pill-net">${esc(c.network || 'tcp')}</span> ${secPill(c)}</td>
      <td>${badge(c)}</td><td class="mono" style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</td>
      <td>${c.uptime != null ? c.uptime + '%' : '—'}</td><td style="color:var(--mu);font-size:12px">${ago(c.last_check)}</td>
    </tr>`).join('');
}
document.addEventListener('click', e => { const t = e.target.closest('[data-open]'); if (t) openDrawer(t.dataset.open); });
$('#cfgSearch').addEventListener('input', () => renderConfigs(S.data?.configs || []));
$('#cfgSubFilter')?.addEventListener('change', () => renderConfigs(S.data?.configs || []));
$$('.view-seg button').forEach(b => b.addEventListener('click', () => { S.view = b.dataset.v; localStorage.setItem('sentinel_view', S.view); renderConfigs(S.data?.configs || []); }));

/* ---------- speed test tab ---------- */
function renderSpeedTestTab() {
  const cfgs = S.data?.configs || [];
  if (!cfgs.length) return;

  // Populate Hero Select
  const sel = $('#spSelect');
  if (sel) {
    const curId = sel.value;
    // Healthy configs first, so the default choice is one that can be tested.
    const ok = c => state(c) === 'up' || state(c) === 'slow';
    sel.innerHTML = byState(cfgs).sort((a, b) => (ok(a) ? 0 : 1) - (ok(b) ? 0 : 1))
      .map(c => `<option value="${c.id}">${esc(c.name)} (${esc(c.addr)})${state(c) === 'up' ? '' : ' · ' + state(c)}</option>`).join('');
    if (curId && cfgs.find(c => c.id === curId)) sel.value = curId;
    updateHeroMeta();
  }

  // Sort Leaderboard: fastest first, untested at bottom
  const sorted = [...cfgs].sort((a, b) => (b.last_speed_mbps || 0) - (a.last_speed_mbps || 0));
  const maxSpeed = Math.max(100, ...sorted.map(c => c.last_speed_mbps || 0));

  const el = $('#spGrid');
  if (!el) return;
  el.innerHTML = sorted.map((c, i) => {
    const rankClass = i === 0 && c.last_speed_mbps ? 'rank-1' : i === 1 && c.last_speed_mbps ? 'rank-2' : i === 2 && c.last_speed_mbps ? 'rank-3' : 'rank-other';
    const rankLabel = c.last_speed_mbps ? `#${i + 1}` : '—';
    const pct = c.last_speed_mbps ? Math.min(100, (c.last_speed_mbps / maxSpeed) * 100).toFixed(1) : 0;
    return `
      <div class="cfg-card">
        <div class="cfg-head">
          <div>
            <div class="cfg-title" style="display:flex;align-items:center;gap:6px">
              <span class="rank-badge ${rankClass}">${rankLabel}</span>
              ${nameHtml(c)}
            </div>
            <div class="cfg-addr">${esc(c.addr)}</div>
          </div>
          ${badge(c)}
        </div>
        <div class="cfg-pills">
          <span class="pill pill-proto">${esc((c.protocol || 'vless').toUpperCase())}</span>
          <span class="pill pill-net">${esc(c.network || 'tcp')}</span>
          ${subBadge(c)}
        </div>
        <div style="background:var(--s2);border:1px solid var(--ln);border-radius:var(--r-md);padding:10px 12px;margin-top:2px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:11px;color:var(--mu);text-transform:uppercase;font-weight:700">Latest speed</span>
            <span style="font-size:16px;font-weight:800;color:${c.last_speed_mbps ? 'var(--ac)' : 'var(--mu)'};font-family:var(--font-mono)">
              ${c.last_speed_mbps ? `⚡ ${c.last_speed_mbps} Mbps` : 'Not tested'}
            </span>
          </div>
          <div class="sp-bar-wrap">
            <div class="sp-bar-fill" style="width:${pct}%"></div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:var(--dim);margin-top:4px">
            <span>Ping: <b style="color:${latColor(c.latency)}">${c.latency ? c.latency + 'ms' : '—'}</b></span>
            <span>${c.last_speed_time ? ago(c.last_speed_time) : 'No tests run'}</span>
          </div>
          ${pfTrendHtml(c)}
        </div>
        <button class="hashem-btn hashem-btn-primary sp-card-btn" data-sp-test="${c.id}" ${state(c) === 'paused' || state(c) === 'no_engine' ? 'disabled' : ''}>
          ⚡ Test Speed (100MB)
        </button>
      </div>`;
  }).join('');
}

function updateHeroMeta() {
  const sel = $('#spSelect'); if (!sel) return;
  const c = S.data?.configs.find(x => x.id === sel.value);
  if (!c) return;
  $('#spHeroPing').textContent = c.latency ? `${c.latency}ms` : '—';
  $('#spHeroSource').textContent = c.sub_name ? `Feed: ${c.sub_name}` : 'Manual';
  $('#spHeroSpeed').textContent = c.last_speed_mbps ? `⚡ ${c.last_speed_mbps} Mbps` : '—';
  $('#spHeroStatus').textContent = c.last_speed_time ? `Last tested ${ago(c.last_speed_time)}` : 'Ready to test';
}

$('#spSelect')?.addEventListener('change', updateHeroMeta);

$('#spHeroTestBtn')?.addEventListener('click', async () => {
  const sel = $('#spSelect'); if (!sel || !sel.value) return;
  const id = sel.value;
  const btn = $('#spHeroTestBtn'); btn.disabled = true; btn.textContent = '⚡ Downloading 100MB...';
  $('#spHeroStatus').textContent = 'Downloading 100MB test chunk from Cloudflare CDN...';
  try {
    const res = await (await api('speedtest', { id })).json();
    if (res.ok) {
      toast(`Speed: ${res.mbps} Mbps (${res.elapsed}s)`);
      $('#spHeroSpeed').textContent = `⚡ ${res.mbps} Mbps`;
      $('#spHeroStatus').textContent = `Downloaded 100MB in ${res.elapsed}s`;
      await refresh();
      renderSpeedTestTab();
    } else {
      toast(res.error || 'Speed test failed', 'err');
      $('#spHeroStatus').textContent = `Failed: ${res.error || 'Error'}`;
    }
  } catch(e) {
    toast('Communication error', 'err');
  } finally {
    btn.disabled = false; btn.textContent = 'Test Selected Config';
  }
});

$('#spAllBtn')?.addEventListener('click', () => $('#spTestAllBtn')?.click());

/* ---------- charts ---------- */
function lineChart(canvas, pts, span, opts = {}) {
  const dpr = devicePixelRatio || 1, r = canvas.getBoundingClientRect();
  if (!r.width) return;
  canvas.width = r.width * dpr; canvas.height = r.height * dpr;
  const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const W = r.width, H = r.height, L = 44, B = 22, T = 10, R = 8, light = document.documentElement.dataset.t === 'light';
  ctx.clearRect(0, 0, W, H);
  const good = pts.filter(p => p.ok && p.latency_ms);
  const top = Math.ceil(Math.max(300, ...good.map(p => p.latency_ms)) / 100) * 100;
  ctx.font = '10px ui-monospace,monospace'; ctx.textAlign = 'right'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = T + (H - T - B) * i / 4;
    ctx.strokeStyle = light ? 'rgba(0,0,0,.07)' : 'rgba(255,255,255,.06)'; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke();
    ctx.fillStyle = light ? '#52525b' : '#71717a'; ctx.fillText(`${Math.round(top * (1 - i / 4))}ms`, L - 6, y + 3);
  }
  if (!pts.length) { ctx.fillStyle = '#71717a'; ctx.textAlign = 'center'; ctx.font = '12px system-ui'; ctx.fillText('Collecting probe history…', W / 2, H / 2); return; }
  const NB = opts.buckets || 40, start = Date.now() / 1000 - span, bw = span / NB;
  const bk = Array.from({ length: NB }, () => ({ l: [], n: 0, f: 0 }));
  for (const p of pts) { const b = bk[Math.min(NB - 1, Math.max(0, Math.floor((p.checked_at - start) / bw)))]; b.n++; if (p.ok && p.latency_ms) b.l.push(p.latency_ms); else if (!p.ok) b.f++; }
  const X = i => L + i * (W - L - R) / (NB - 1), Y = v => T + (H - T - B) * (1 - v / top);
  bk.forEach((b, i) => { if (b.f && b.f === b.n) { ctx.fillStyle = 'rgba(239,68,68,.16)'; ctx.fillRect(X(i) - (W - L - R) / NB / 2, T, (W - L - R) / NB, H - T - B); } });
  let xy = bk.map((b, i) => b.l.length ? [X(i), Y(b.l.reduce((a, c) => a + c, 0) / b.l.length)] : null).filter(Boolean);
  if (!xy.length) { ctx.fillStyle = '#71717a'; ctx.textAlign = 'center'; ctx.font = '12px system-ui'; ctx.fillText('No successful probes in this range.', W / 2, H / 2); return; }
  if (xy.length === 1) { xy = [[L, xy[0][1]], [W - R, xy[0][1]]]; }
  const ac = accent(), g = ctx.createLinearGradient(0, T, 0, H - B);
  g.addColorStop(0, rgba(ac, .25)); g.addColorStop(1, rgba(ac, 0));
  ctx.beginPath(); xy.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.strokeStyle = ac; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
  ctx.lineTo(xy.at(-1)[0], H - B); ctx.lineTo(xy[0][0], H - B); ctx.closePath(); ctx.fillStyle = g; ctx.fill();
}
/* The dashboard chart: buckets come from the server (average, fastest, 95th percentile), and every
   outage is drawn as a red span over its own time, so one config going down shows among many healthy ones. */
const CHART_BUCKETS = { '1h': 30, '24h': 48, '7d': 84, '30d': 120 };
S.chartCfg = '';
function fillChartCfg(cfgs) {
  const sel = $('#chartCfg'); if (!sel) return;
  const key = cfgs.map(c => c.id + c.name).join('|'); if (sel.dataset.key === key) return;
  sel.dataset.key = key;
  sel.innerHTML = '<option value="">All configs</option>' + cfgs.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  sel.value = cfgs.some(c => c.id === S.chartCfg) ? S.chartCfg : '';
}
function bucketChart(canvas, h) {
  const dpr = devicePixelRatio || 1, r = canvas.getBoundingClientRect();
  if (!r.width) return;
  canvas.width = r.width * dpr; canvas.height = r.height * dpr;
  const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const W = r.width, H = r.height, L = 44, B = 22, T = 10, R = 8, light = document.documentElement.dataset.t === 'light';
  const bk = h.buckets, good = bk.filter(b => b.avg != null);
  const top = Math.ceil(Math.max(300, ...good.map(b => b.p95)) / 100) * 100;
  const X = t => L + (t - h.since) / h.span * (W - L - R), Y = v => T + (H - T - B) * (1 - Math.min(v, top) / top);
  ctx.clearRect(0, 0, W, H);
  ctx.font = '10px ui-monospace,monospace'; ctx.textAlign = 'right'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = T + (H - T - B) * i / 4;
    ctx.strokeStyle = light ? 'rgba(0,0,0,.07)' : 'rgba(255,255,255,.06)'; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke();
    ctx.fillStyle = light ? '#52525b' : '#71717a'; ctx.fillText(`${Math.round(top * (1 - i / 4))}ms`, L - 6, y + 3);
  }
  // time labels: start, middle, end
  ctx.textAlign = 'center';
  const lab = t => { const d = new Date(t * 1000); return h.span > 2 * 86400 ? d.toLocaleDateString([], { month: 'short', day: 'numeric' }) : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); };
  [[h.since, 'left'], [h.since + h.span / 2, 'center'], [h.now, 'right']].forEach(([t, al]) => { ctx.textAlign = al; ctx.fillText(lab(t), X(t), H - 6); });
  for (const x of h.incidents) {  // at least 2px so a short outage on a 30-day chart still shows
    const x0 = X(x.start), w = Math.max(2, X(x.end) - x0);
    ctx.fillStyle = x.open ? 'rgba(239,68,68,.32)' : 'rgba(239,68,68,.18)'; ctx.fillRect(x0, T, w, H - T - B);
  }
  if (!good.length) { ctx.fillStyle = '#71717a'; ctx.textAlign = 'center'; ctx.font = '12px system-ui'; ctx.fillText(bk.some(b => b.n) ? 'No successful probes in this range.' : 'Collecting probe history…', W / 2, H / 2); return; }
  const ac = accent();
  // the band, drawn per run of buckets that have data
  const runs = []; let run = [];
  bk.forEach(b => { if (b.avg != null) run.push(b); else if (run.length) { runs.push(run); run = []; } });
  if (run.length) runs.push(run);
  for (const rn of runs) {
    const pts = rn.length === 1 ? [{ ...rn[0], t: rn[0].t - h.span / bk.length / 2 }, { ...rn[0], t: rn[0].t + h.span / bk.length / 2 }] : rn;
    ctx.beginPath(); pts.forEach((b, i) => i ? ctx.lineTo(X(b.t), Y(b.p95)) : ctx.moveTo(X(b.t), Y(b.p95)));
    [...pts].reverse().forEach(b => ctx.lineTo(X(b.t), Y(b.min))); ctx.closePath();
    ctx.fillStyle = rgba(ac, light ? .14 : .16); ctx.fill();
    ctx.beginPath(); pts.forEach((b, i) => i ? ctx.lineTo(X(b.t), Y(b.avg)) : ctx.moveTo(X(b.t), Y(b.avg)));
    ctx.strokeStyle = ac; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.stroke();
  }
  canvas._chart = { h, X, L, R, W };
}
function chartTip(e) {
  const c = $('#histChart'), tip = $('#histTip'), m = c?._chart; if (!m) return;
  const r = c.getBoundingClientRect(), px = e.clientX - r.left;
  if (px < m.L || px > m.W - m.R) { tip.classList.add('hidden'); return; }
  const h = m.h, t = h.since + (px - m.L) / (m.W - m.L - m.R) * h.span;
  const b = h.buckets[Math.min(h.buckets.length - 1, Math.max(0, Math.floor((t - h.since) / h.span * h.buckets.length)))];
  const near = h.span / 200;  // a hair either side, so a 2px outage can be hovered
  const outs = h.incidents.filter(x => t >= x.start - near && t <= x.end + near);
  const at = new Date(b.t * 1000).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  tip.innerHTML = `<div class="u-mu">${esc(at)}</div>` +
    (b.avg != null ? `<div>${b.avg} ms average, ${b.min} to ${b.p95} ms</div>` : `<div class="u-mu">${b.n ? 'Every probe failed' : 'No probes'}</div>`) +
    outs.slice(0, 4).map(x => `<div style="color:var(--er)">${esc(x.name)}: ${x.open ? 'down now' : `down ${dur(x.end - x.start)}`}${x.why ? `, ${esc(x.why)}` : ''}</div>`).join('') +
    (outs.length > 4 ? `<div class="u-mu">${outs.length - 4} more outages</div>` : '');
  tip.classList.remove('hidden');
  const left = Math.min(px + 12, r.width - tip.offsetWidth - 4);
  tip.style.left = `${Math.max(4, left)}px`; tip.style.top = '8px';
}
async function drawHistory() {
  const c = $('#histChart'); if (!c || S.tab !== 'dashboard') return;
  const id = S.chartCfg ? `&id=${encodeURIComponent(S.chartCfg)}` : '';
  const h = await getJSON(`history?range=${S.range}&buckets=${CHART_BUCKETS[S.range] || 60}${id}`).catch(() => null);
  if (!h || !h.buckets) return;
  const n = h.incidents.length, name = S.chartCfg ? (S.data?.configs.find(x => x.id === S.chartCfg)?.name || 'This config') : 'Every config together';
  $('#chartSub').textContent = `${name}. ${n ? `${n} outage${n > 1 ? 's' : ''} in this range` : 'No outage in this range'}.`;
  bucketChart(c, h);
  $('#histTip')?.classList.add('hidden');  // its numbers belonged to the last drawing
}
$$('#chartFilters button').forEach(b => b.addEventListener('click', () => {
  $$('#chartFilters button').forEach(x => x.removeAttribute('aria-pressed')); b.setAttribute('aria-pressed', 'true');
  S.range = b.dataset.r; drawHistory();
}));
$('#chartCfg')?.addEventListener('change', e => { S.chartCfg = e.target.value; drawHistory(); });
$('#histChart')?.addEventListener('mousemove', chartTip);
$('#histChart')?.addEventListener('mouseleave', () => $('#histTip')?.classList.add('hidden'));
setInterval(() => { if (!document.hidden && S.tab === 'dashboard') drawHistory(); }, 15000);
addEventListener('resize', () => { if (S.tab === 'dashboard') drawHistory(); });

/* ---------- detail drawer ---------- */
function openDrawer(id) { S.drawerId = id; $('#detOv').classList.add('open'); $('#detDrawer').classList.add('open'); $('#detBody').innerHTML = '<div class="u-mu">Loading…</div>'; loadDrawer(id); }
function closeDrawer() { S.drawerId = null; $('#detOv').classList.remove('open'); $('#detDrawer').classList.remove('open'); }
$('#detOv').addEventListener('click', closeDrawer);
$('#detClose').addEventListener('click', closeDrawer);
async function loadDrawer(id, quiet) {
  const d = await getJSON(`config?id=${id}&range=${S.range}`).catch(() => null);
  if (!d || d.error) { if (!quiet) { closeDrawer(); toast('Config not found', 'err'); } return; }
  if (S.drawerId !== id) return;
  const c = d.config, live = S.data?.configs.find(x => x.id === id) || c, st = d.stats;
  const keepName = quiet && document.activeElement?.id === 'detName';
  $('#detTitle').textContent = c.name;
  $('#detBody').innerHTML = `
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">${badge(live)}<span class="pill pill-proto">${esc((live.protocol || c.protocol || 'vless').toUpperCase())}</span><span class="pill pill-net">${esc(c.network)}</span>${secPill(c)}</div>
    <div class="det-stat-grid">
      <div class="det-box"><div class="det-box-label">Uptime (${S.range})</div><div class="det-box-val" style="color:${st.uptime == null ? 'var(--tx)' : st.uptime >= 99 ? 'var(--ok)' : st.uptime >= 90 ? 'var(--wr)' : 'var(--er)'}">${st.uptime ?? '—'}${st.uptime != null ? '%' : ''}</div></div>
      <div class="det-box"><div class="det-box-label">Avg latency</div><div class="det-box-val">${st.avg != null ? st.avg + 'ms' : '—'}</div></div>
      <div class="det-box"><div class="det-box-label">Latest speed</div><div class="det-box-val" style="color:var(--ac);font-size:18px">${live.last_speed_mbps ? live.last_speed_mbps + ' Mbps' : '—'}</div></div>
      <div class="det-box"><div class="det-box-label">Probes</div><div class="det-box-val">${st.checks}</div></div>
    </div>
    <div class="det-chart-box"><canvas id="detChart" style="width:100%;height:100%"></canvas></div>
    ${live.last_error && (state(live) === 'down' || state(live) === 'fail') ? errBox(live.last_error, true) : ''}
    ${HOOKS.drawer.map(f => { try { return f(c, d, live) || ''; } catch (e) { console.error(e); return ''; } }).join('')}
    <div class="field"><label class="field-lbl">Name</label><div style="display:flex;gap:8px"><input class="hashem-input" id="detName" value="${esc(c.name)}" maxlength="80"><button class="hashem-btn hashem-btn-secondary" id="detRename">Save</button></div></div>
    <div class="field"><label class="field-lbl">Address</label><div class="cfg-addr" style="padding:4px 0">${esc(c.addr)}</div></div>
    <div class="field"><label class="field-lbl">Subscription Source</label><div style="font-size:12px;padding:4px 0">${c.sub_name ? `<span class="pill pill-sub">Feed: ${esc(c.sub_name)}</span> <div class="sub-url" style="margin-top:4px">${esc(c.sub_url || '')}</div>` : '<span class="pill pill-port">Manual Entry</span>'}</div></div>
    <div><div class="field-lbl" style="margin-bottom:6px">Recent incidents</div>${d.incidents.length ? d.incidents.slice(0, 6).map(i => `<div class="det-box" style="margin-bottom:6px;font-size:12px"><b>${when(i.started_at)}</b> &rarr; ${i.resolved_at ? `${when(i.resolved_at)} <span class="u-mu">(${dur(i.resolved_at - i.started_at)})</span>` : '<span class="badge err">ONGOING</span>'}</div>`).join('') : '<div class="u-mu" style="font-size:12px">None.</div>'}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:auto">
      <button class="hashem-btn ${state(live) === 'up' ? 'hashem-btn-primary' : 'hashem-btn-secondary'}" id="detSpTest" ${c.enabled ? '' : 'disabled'}>⚡ Speed test</button>
      <button class="hashem-btn hashem-btn-secondary" id="detToggle">${c.enabled ? 'Pause' : 'Resume'}</button>
      <button class="hashem-btn hashem-btn-secondary" id="detMute" title="Telegram alerts for this config">${live.muted ? '🔔 Unmute alerts' : '🔕 Mute alerts'}</button>
      <button class="hashem-btn hashem-btn-secondary" id="detCopy">Copy URI</button>
      <button class="hashem-btn hashem-btn-danger" id="detDel">Delete</button>
    </div>`;
  if (keepName) $('#detName').focus();
  lineChart($('#detChart'), d.points, d.span, { buckets: 30 });
  $('#detSpTest').onclick = async (e) => {
    const b = e.currentTarget; b.disabled = true; b.textContent = '⚡ Downloading 100MB...';
    try {
      const res = await (await api('speedtest', { id })).json();
      if (res.ok) { toast(`Speed: ${res.mbps} Mbps (${res.elapsed}s)`); refresh(); loadDrawer(id, true); }
      else toast(res.error || 'Speed test failed', 'err');
    } catch { toast('Speed test error', 'err'); }
    finally { b.disabled = false; b.textContent = '⚡ Speed test'; }
  };
  $('#detRename').onclick = async () => { const r = await api('configs/rename', { id, name: $('#detName').value }); r.ok ? (toast('Renamed'), refresh()) : toast('Rename failed', 'err'); };
  $('#detToggle').onclick = async () => { const r = await (await api('configs/toggle', { id })).json(); toast(r.enabled ? 'Resumed' : 'Paused'); refresh(); };
  $('#detMute').onclick = async () => { const r = await (await api('configs/mute', { id })).json(); toast(r.muted ? 'Alerts muted for this config' : 'Alerts on'); await refresh(); loadDrawer(id, true); };
  $('#detCopy').onclick = () => navigator.clipboard.writeText(c.uri).then(() => toast('URI copied'));
  $('#detDel').onclick = async () => { if (!confirm(`Delete "${c.name}" and its history?`)) return; await api('configs/delete', { id }); closeDrawer(); toast('Deleted'); refresh(); };
  HOOKS.drawerBind.forEach(f => { try { f(c, d, live); } catch (e) { console.error(e); } });
}

/* ---------- import modal ---------- */
const openImport = () => { $('#importModal').classList.remove('hidden'); $('#importUris').focus(); };
const closeImport = () => { $('#importModal').classList.add('hidden'); $('#importUris').value = ''; };
$('#importBtn').addEventListener('click', openImport);
$('#importBtn2').addEventListener('click', openImport);
$('#importClose').addEventListener('click', closeImport);
$('#importCancel').addEventListener('click', closeImport);
$('#importOk').addEventListener('click', async () => {
  const text = $('#importUris').value.trim(); if (!text) return toast('Paste at least one config link', 'err');
  const r = await (await api('configs/add', { text })).json();
  closeImport();
  r.errors?.length ? toast(`Added ${r.added}. Failed: ${r.errors[0]}${r.errors.length > 1 ? ` (+${r.errors.length - 1})` : ''}`, 'err') : toast(`Imported ${r.added} config(s)`);
  refresh();
});

/* ---------- 2FA management ---------- */
let temp2faSecret = '';
async function load2FaStatus() {
  const d = await getJSON('2fa').catch(() => null); if (!d) return;
  const b = $('#twoFaBadge');
  b.textContent = d.enabled ? 'On' : 'Off';
  b.className = `badge sm ${d.enabled ? 'ok' : 'dim'}`;
  $('#twoFaDetails').innerHTML = d.enabled
    ? `<button class="hashem-btn hashem-btn-danger" id="twoFaDisableBtn">Turn Off 2FA</button>`
    : `<button class="hashem-btn hashem-btn-secondary" id="twoFaSetupBtn">Set Up 2FA</button>`;
  temp2faSecret = d.secret;
  $('#twoFaSecretText').textContent = d.secret;
  $('#twoFaOtpLink').href = d.uri;
  $('#twoFaDisableBtn')?.addEventListener('click', async () => {
    const pw = prompt('Enter your admin password to disable 2FA:'); if (!pw) return;
    const r = await api('2fa/disable', { password: pw });
    if (r.ok) { toast('2FA disabled'); load2FaStatus(); }
    else toast((await r.json()).error || 'Failed', 'err');
  });
  $('#twoFaSetupBtn')?.addEventListener('click', () => {
    $('#twoFaModal').classList.remove('hidden'); $('#twoFaVerifyCode').value = ''; $('#twoFaVerifyCode').focus();
  });
}
$('#twoFaClose').addEventListener('click', () => $('#twoFaModal').classList.add('hidden'));
$('#twoFaCancel').addEventListener('click', () => $('#twoFaModal').classList.add('hidden'));
$('#twoFaModal').addEventListener('click', e => { if (e.target.id === 'twoFaModal') $('#twoFaModal').classList.add('hidden'); });
$('#twoFaConfirmBtn').addEventListener('click', async () => {
  const code = $('#twoFaVerifyCode').value.trim();
  if (code.length !== 6) return toast('Enter 6-digit code', 'err');
  const r = await api('2fa/enable', { secret: temp2faSecret, code });
  if (r.ok) { toast('2FA enabled successfully!'); $('#twoFaModal').classList.add('hidden'); load2FaStatus(); }
  else toast((await r.json()).error || 'Verification failed', 'err');
});

/* ---------- clean subscription feed ---------- */
let baseCleanSubUrl = '';
async function loadCleanSub() {
  const d = await getJSON('clean-sub').catch(() => null); if (!d) return;
  baseCleanSubUrl = d.public_url || `${location.origin}${d.url}`;
  updateCleanSubDisplay();
  $('#cleanSubBadge').textContent = d.healthy_count;
  $('#cleanSubCount').textContent = `${d.healthy_count} of ${d.total_count} Nodes`;
}

function updateCleanSubDisplay() {
  if (!baseCleanSubUrl) return;
  const activeBtn = $('#cleanSubFilterPills .sub-filter-btn.active');
  const q = activeBtn ? (activeBtn.dataset.q || '') : '';
  const fullUrl = q ? `${baseCleanSubUrl}?${q}` : baseCleanSubUrl;
  $('#cleanSubUrl').value = fullUrl;
  const qrWrap = $('#cleanSubQr');
  if (qrWrap && window.QRCode) {
    qrWrap.innerHTML = '';
    try {
      new QRCode(qrWrap, {
        text: fullUrl,
        width: 160,
        height: 160,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch (e) {
      console.error('QR render error:', e);
    }
  }
}

$('#cleanSubFilterPills')?.addEventListener('click', e => {
  const btn = e.target.closest('.sub-filter-btn');
  if (!btn) return;
  $$('#cleanSubFilterPills .sub-filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  updateCleanSubDisplay();
});
const openCleanSub = async () => { $('#cleanSubModal').classList.remove('hidden'); await loadCleanSub(); };
const closeCleanSub = () => $('#cleanSubModal').classList.add('hidden');
if ($('#cleanSubBtn')) $('#cleanSubBtn').addEventListener('click', openCleanSub);
if ($('#dashCleanSubBtn')) $('#dashCleanSubBtn').addEventListener('click', openCleanSub);
$('#cleanSubClose').addEventListener('click', closeCleanSub);
$('#cleanSubDone').addEventListener('click', closeCleanSub);
$('#cleanSubModal').addEventListener('click', e => { if (e.target.id === 'cleanSubModal') closeCleanSub(); });
$('#cleanSubCopy').addEventListener('click', () => {
  navigator.clipboard.writeText($('#cleanSubUrl').value).then(() => toast('Clean Subscription URL copied!'));
});
$('#cleanSubRotate').addEventListener('click', async () => {
  if (!confirm('Rotate secret token? Existing clients will lose access until they update the subscription URL.')) return;
  const r = await api('clean-sub/rotate', {}); const d = await r.json();
  if (r.ok) { toast('Token rotated!'); await loadCleanSub(); }
  else toast('Rotate failed', 'err');
});

/* ---------- subscriptions ---------- */
S.subs = [];
const INTERVALS = { 1: '1 hour', 6: '6 hours', 12: '12 hours', 24: '24 hours' };
async function loadSubs() {
  const d = await getJSON('subscriptions').catch(() => null); if (!d) return;
  S.subs = d.subscriptions;
  $('#subBadge').textContent = S.subs.length;
  $('#subBadge').className = `badge sm ${S.subs.length ? 'ok' : 'dim'}`;
  renderSubs();
}
function renderSubs() {
  const next = x => x.last_sync ? Math.max(0, x.last_sync + x.interval_hours * 3600 - Math.floor(Date.now() / 1000)) : 0;
  $('#subList').innerHTML = S.subs.length ? S.subs.map(x => `
    <div class="sub-item" style="${x.enabled ? '' : 'opacity:.6'}">
      <div class="sub-head">
        <div><div class="sub-title">${esc(x.name)} <span class="pill pill-proto">${x.config_count} configs</span></div><div class="sub-url">${esc(x.url.length > 70 ? x.url.slice(0, 60) + '…' + x.url.slice(-8) : x.url)}</div></div>
        ${x.last_sync == null ? '<span class="badge dim"><span class="dot"></span>PENDING</span>' : x.last_ok ? '<span class="badge ok"><span class="dot"></span>SYNCED</span>' : '<span class="badge err"><span class="dot"></span>FAILED</span>'}
      </div>
      <div class="sub-meta">
        <span>${x.last_sync ? `Last: ${ago(x.last_sync)} &middot; ${esc(x.last_msg)}` : 'Never synced'}${x.enabled && x.last_sync ? ` &middot; next in ${dur(next(x))}` : ''}</span>
        <span class="sub-acts">
          <select class="hashem-select" data-sub-int="${x.id}" style="height:28px;width:auto;font-size:12px;padding:0 8px">${Object.entries(INTERVALS).map(([h, l]) => `<option value="${h}" ${+h === x.interval_hours ? 'selected' : ''}>${l}</option>`).join('')}</select>
          <button class="hashem-btn hashem-btn-secondary" style="height:28px;font-size:12px" data-sub-sync="${x.id}">Sync now</button>
          <button class="hashem-btn hashem-btn-ghost" style="height:28px;font-size:12px" data-sub-tog="${x.id}">${x.enabled ? 'Pause' : 'Resume'}</button>
          <button class="hashem-btn hashem-btn-danger" style="height:28px;font-size:12px" data-sub-del="${x.id}">Delete</button>
        </span>
      </div>
      ${x.last_sync && !x.last_ok ? `<div style="font-size:11px;color:var(--er);font-family:var(--font-mono);word-break:break-all">${esc(x.last_msg)}</div>` : ''}
    </div>`).join('') : '<div class="u-mu" style="text-align:center;padding:18px;font-size:12.5px">No subscriptions yet. Add one above.</div>';
}
const openSubs = () => { $('#subModal').classList.remove('hidden'); loadSubs(); $('#subUrl').focus(); };
const closeSubs = () => $('#subModal').classList.add('hidden');
$('#subBtn').addEventListener('click', openSubs);
$('#subClose').addEventListener('click', closeSubs);
$('#subModal').addEventListener('click', e => { if (e.target.id === 'subModal') closeSubs(); });
$('#subAddBtn').addEventListener('click', async e => {
  const url = $('#subUrl').value.trim(); if (!url) return toast('Paste a subscription URL', 'err');
  const b = e.currentTarget; b.disabled = true; b.textContent = 'Fetching…';
  try {
    const r = await api('subscriptions/add', { url, name: $('#subName').value, interval_hours: +$('#subInterval').value });
    const d = await r.json();
    if (r.ok) { toast(`Subscribed: ${d.total} config(s) imported`); $('#subUrl').value = $('#subName').value = ''; await loadSubs(); refresh(); }
    else toast(d.error || 'Failed', 'err');
  } finally { b.disabled = false; b.textContent = 'Add & Sync'; }
});
$('#subList').addEventListener('click', async e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.subSync) {
    t.disabled = true; t.textContent = 'Syncing…';
    const r = await api('subscriptions/sync', { id: t.dataset.subSync }); const d = await r.json();
    r.ok ? toast(`Synced: +${d.added} new, -${d.removed} removed`) : toast(d.error || 'Sync failed', 'err');
    await loadSubs(); refresh();
  } else if (t.dataset.subTog) {
    const x = S.subs.find(v => v.id === t.dataset.subTog);
    await api('subscriptions/update', { id: x.id, enabled: !x.enabled }); loadSubs();
  } else if (t.dataset.subDel) {
    const x = S.subs.find(v => v.id === t.dataset.subDel);
    if (!confirm(`Delete subscription "${x.name}"?\n\nOK = also delete its ${x.config_count} configs\nCancel = keep the configs`)) {
      if (!confirm('Delete only the subscription link and KEEP its configs as manual entries?')) return;
      await api('subscriptions/delete', { id: x.id, delete_configs: false });
    } else await api('subscriptions/delete', { id: x.id, delete_configs: true });
    toast('Subscription removed'); await loadSubs(); refresh();
  }
});
$('#subList').addEventListener('change', async e => {
  const id = e.target.dataset.subInt; if (!id) return;
  const r = await api('subscriptions/update', { id, interval_hours: +e.target.value });
  r.ok ? toast(`Auto-sync every ${INTERVALS[e.target.value]}`) : toast('Update failed', 'err'); loadSubs();
});

/* ---------- incidents ---------- */
async function loadIncidents() {
  const d = await getJSON('incidents').catch(() => null); if (!d) return;
  $('#incTable').innerHTML = d.incidents.length ? d.incidents.map(i => `
    <tr data-open="${i.config_id}" style="cursor:pointer"><td><strong>${nameHtml(i)}</strong><br><span class="cfg-addr">${esc(i.addr)}</span></td>
    <td>${when(i.started_at)}</td><td>${i.resolved_at ? when(i.resolved_at) : '<span class="badge err"><span class="dot"></span>ONGOING</span>'}</td>
    <td>${dur((i.resolved_at || Math.floor(Date.now() / 1000)) - i.started_at)}</td>
    <td>${i.diag_verdict ? `<div class="inc-cause">${esc(i.diag_verdict)}</div>` : ''}${i.last_error ? errBox(i.last_error) : (i.diag_verdict ? '' : '—')}</td></tr>`).join('')
    : '<tr><td colspan="5" class="u-mu" style="text-align:center;padding:24px">No incidents recorded.</td></tr>';
}
$('#csvBtn').addEventListener('click', async () => {
  const r = await api('incidents.csv'); const a = document.createElement('a');
  a.href = URL.createObjectURL(await r.blob()); a.download = 'sentinel-incidents.csv'; a.click(); URL.revokeObjectURL(a.href);
});

/* ---------- settings ---------- */
function fillSettings(s) {
  $('#cfgInterval').value = s.interval; $('#cfgThreshold').value = s.threshold; $('#cfgTimeout').value = s.timeout;
  $('#cfgUrl').value = s.url;
  $('#nDown').checked = s.notify_down !== '0'; $('#nRecover').checked = s.notify_recover !== '0';
  $('#nBackup').checked = s.daily_backup !== '0'; $('#nReport').checked = s.daily_report === '1';
  $('#nRemind').value = s.remind_hours ?? '2'; $('#nAdmins').value = (s.tg_admins || '').split(',').filter(Boolean).join(', ');
  $('#cfgChat').value = '';
  $('#cfgChat').placeholder = s.chat_configured ? 'Saved — leave blank to keep' : '-100... or user ID';
  $('#cfgToken').value = '';
  $('#cfgToken').placeholder = s.token_configured ? 'Saved — leave blank to keep' : '123456789:ABCdef…';
  const isHttps = s.use_https === '1' || location.protocol === 'https:';
  const badge = $('#httpsBadge');
  const btn = $('#toggleHttpsBtn');
  const txt = $('#httpsStatusText');
  badge.textContent = isHttps ? 'On' : 'Off';
  badge.className = isHttps ? 'badge ok sm' : 'badge dim sm';
  btn.textContent = isHttps ? 'Switch to HTTP' : 'Turn On HTTPS';
  txt.textContent = isHttps
    ? 'The panel and the clean feed are served over HTTPS. Sentinel restarts to switch.'
    : 'Serve the panel and the clean feed over HTTPS. A self-signed certificate is made if there is no other one. Sentinel restarts to switch.';
  const tg = $('#tgBadge'), tgOk = s.token_configured && s.chat_configured, tgSome = s.token_configured || s.chat_configured;
  tg.textContent = tgOk ? 'Connected' : tgSome ? 'Half set up' : 'Not set up';
  tg.className = `badge sm ${tgOk ? 'ok' : tgSome ? 'warn' : 'dim'}`;
  intervalHint();
}
/* Spell the check interval out so 86400 reads as "once a day". */
function intervalHint() {
  const v = +$('#cfgInterval').value, h = $('#cfgIntervalHint');
  if (!v) { h.textContent = 'Between 2 and 3600 seconds'; return; }
  const n = (x, u) => { const r = +x.toFixed(1); return r === 1 ? u : `${r} ${u}s`; };
  h.textContent = 'Every ' + (v < 60 ? n(v, 'second') : v < 3600 ? n(v / 60, 'minute') : v < 86400 ? n(v / 3600, 'hour') : n(v / 86400, 'day'));
}
$('#cfgInterval').addEventListener('input', intervalHint);
/* Section index: scroll without touching the #tab hash, and mark the section in view. */
const markSec = id => $$('.set-index a').forEach(a => a.classList.toggle('on', a.dataset.sec === id));
$$('.set-index a').forEach(a => a.addEventListener('click', e => {
  e.preventDefault(); markSec(a.dataset.sec);
  $('#' + a.dataset.sec).scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
}));
/* The section in view is the last one whose top has passed the top bar; at the bottom, the last one. */
let secTick = 0;
addEventListener('scroll', () => {
  if (S.tab !== 'settings' || secTick) return;
  secTick = requestAnimationFrame(() => {
    secTick = 0;
    const secs = $$('.set-sec:not([hidden])'), atEnd = innerHeight + scrollY >= document.documentElement.scrollHeight - 4;
    const cur = atEnd ? secs.at(-1) : secs.filter(x => x.getBoundingClientRect().top <= 140).at(-1) || secs[0];
    markSec(cur.id);
  });
}, { passive: true });
markSec('set-checks');

$('#toggleHttpsBtn')?.addEventListener('click', async () => {
  const curHttps = S.data?.settings?.use_https === '1' || location.protocol === 'https:';
  const nextVal = curHttps ? '0' : '1';
  const r = await api('settings', { use_https: nextVal });
  if (r.ok) {
    toast(`HTTPS ${nextVal === '1' ? 'on' : 'off'}. Restarting Sentinel…`);
    setTimeout(() => {
      const targetProto = nextVal === '1' ? 'https:' : 'http:';
      location.href = `${targetProto}//${location.host}${location.pathname}`;
    }, 2000);
  } else {
    toast('Failed updating HTTPS setting', 'err');
  }
});
async function saveSettings() {
  const p = { interval: $('#cfgInterval').value, threshold: $('#cfgThreshold').value, timeout: $('#cfgTimeout').value, url: $('#cfgUrl').value, chat: $('#cfgChat').value.trim() };
  const t = $('#cfgToken').value.trim(); if (t) p.token = t;
  const r = await api('settings', p);
  if (r.ok) { toast('Settings saved'); $('#cfgToken').value = ''; $('#tab-settings').dataset.filled = ''; refresh(); }
  else toast((await r.json()).error || 'Invalid settings', 'err');
}
$('#saveProbe').addEventListener('click', saveSettings);
$('#saveNotify').addEventListener('click', async () => {
  const r = await api('settings', {
    notify_down: $('#nDown').checked ? '1' : '0', notify_recover: $('#nRecover').checked ? '1' : '0',
    daily_backup: $('#nBackup').checked ? '1' : '0', daily_report: $('#nReport').checked ? '1' : '0',
    remind_hours: $('#nRemind').value, tg_admins: $('#nAdmins').value,
    notify_all_down: $('#nAllDown')?.checked ? '1' : '0',
  });
  if (r.ok) { toast('Notifications saved'); $('#tab-settings').dataset.filled = ''; refresh(); }
  else toast((await r.json()).error || 'Could not save', 'err');
});
$('#saveTg').addEventListener('click', saveSettings);
$('#testTg').addEventListener('click', async () => {
  const btn = $('#testTg'); btn.disabled = true; btn.textContent = 'Routing…';
  const tr = $('#tgTrace'); tr.classList.remove('hidden');
  tr.innerHTML = '<div class="u-mu">Attempting delivery via healthy configs (round-robin)…</div>';
  try {
    const res = await (await api('test-telegram', {})).json();
    if (res.ok) {
      toast(`Delivered via ${res.used_node}`);
      tr.innerHTML = `
        <div style="color:var(--ok);font-weight:700;margin-bottom:6px">✔ Delivered via: <b>${esc(res.used_node)}</b> <span class="u-mu">(${esc(res.used_addr)})</span></div>
        <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Route Attempts (${res.attempts.length}):</div>
        ${res.attempts.map(a => `
          <div style="font-family:var(--font-mono);font-size:11px;padding:3px 0;border-top:1px solid var(--ln)">
            <span style="color:${a.ok ? 'var(--ok)' : 'var(--er)'}">${a.ok ? '✔' : '✖'}</span> <b>${esc(a.node)}</b> <span class="pill ${a.sub_name ? 'pill-sub' : 'pill-port'}" style="font-size:10px;padding:1px 5px">${a.sub_name ? '? SUB: ' + esc(a.sub_name) : 'Manual'}</span>
            ${a.ms != null ? `<span style="color:var(--dim)">${a.ms}ms</span>` : ''}
            ${a.error ? `<span style="color:var(--er)">(${esc(a.error)})</span>` : ''}
          </div>`).join('')}`;
    } else {
      toast('Failed to deliver alert', 'err');
      tr.innerHTML = `
        <div style="color:var(--er);font-weight:700;margin-bottom:6px">✖ Delivery Failed across all routes</div>
        <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Attempts (${(res.attempts||[]).length}):</div>
        ${(res.attempts||[]).map(a => `
          <div style="font-family:var(--font-mono);font-size:11px;padding:3px 0;border-top:1px solid var(--ln)">
            <span style="color:var(--er)">✖</span> <b>${esc(a.node || 'Route')}</b>
            ${a.error ? `<span style="color:var(--er)">: ${esc(a.error)}</span>` : ''}
          </div>`).join('')}`;
    }
  } catch(e) {
    toast('Communication error', 'err');
    tr.innerHTML = `<div style="color:var(--er)">Error: ${esc(e.message)}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Send Test Alert';
  }
});
$('#pwSave').addEventListener('click', async () => {
  const r = await api('password', { old: $('#pwOld').value, new: $('#pwNew').value });
  if (r.ok) { toast('Password changed'); $('#pwOld').value = $('#pwNew').value = ''; } else toast((await r.json()).error, 'err');
});
$$('.acc-btn').forEach(b => b.addEventListener('click', () => { setAccent(b.dataset.acc); api('settings', { accent: b.dataset.acc }); }));
function setAccent(a) { document.documentElement.dataset.acc = a; localStorage.setItem('sentinel_accent', a); $$('.acc-btn').forEach(x => x.classList.toggle('selected', x.dataset.acc === a)); if (S.tab === 'dashboard') drawHistory(); }

/* ---------- theme / sidebar ---------- */
$('#themeBtn').addEventListener('click', () => {
  const n = document.documentElement.dataset.t === 'light' ? 'dark' : 'light';
  document.documentElement.dataset.t = document.body.dataset.t = n; localStorage.setItem('sentinel_theme', n);
  if (S.tab === 'dashboard') drawHistory();
});
$('#sbToggle').addEventListener('click', () => {
  const on = document.documentElement.dataset.sb !== '1';
  document.documentElement.dataset.sb = on ? '1' : '0'; localStorage.setItem('sentinel_sb', on ? '1' : '0');
  $('#sbToggle').setAttribute('aria-pressed', on);
});
$('#checkNowBtn').addEventListener('click', async () => { toast('Probing all configs…'); await api('check-now', {}); setTimeout(refresh, 2500); });

/* ---------- command palette ---------- */
const palItems = () => [
  ...['dashboard', 'configs', 'speedtest', 'incidents', 'settings'].map(t => ({ g: 'Go to', t: TITLES[t][0], run: () => switchTab(t) })),
  { g: 'Actions', t: 'Import configs', run: () => { switchTab('configs'); openImport(); } },
  { g: 'Actions', t: 'Get Clean Subscription link', run: () => openCleanSub() },
  { g: 'Actions', t: 'Manage subscriptions', run: () => { switchTab('configs'); openSubs(); } },
  { g: 'Actions', t: 'Probe all now', run: () => $('#checkNowBtn').click() },
  { g: 'Actions', t: 'Toggle theme', run: () => $('#themeBtn').click() },
  { g: 'Actions', t: 'Export incidents CSV', run: () => $('#csvBtn').click() },
  ...(S.data?.configs || []).map(c => ({ g: 'Configs', t: c.name, sub: c.addr, run: () => openDrawer(c.id) })),
];
let palSel = 0, palRows = [];
function palRender() {
  const q = $('#palInput').value.toLowerCase();
  palRows = palItems().filter(i => !q || (i.t + ' ' + (i.sub || '')).toLowerCase().includes(q));
  palSel = Math.min(palSel, Math.max(0, palRows.length - 1));
  let g = '';
  $('#palList').innerHTML = palRows.length ? palRows.map((i, n) => { const h = i.g !== g ? `<div class="pal-g">${g = i.g}</div>` : ''; return `${h}<div class="pal-it ${n === palSel ? 'on' : ''}" data-n="${n}"><span class="pal-t">${esc(i.t)}</span>${i.sub ? `<span class="pal-gt">${esc(i.sub)}</span>` : ''}</div>`; }).join('') : '<div class="pal-none">No results</div>';
  $('#palList .on')?.scrollIntoView({ block: 'nearest' });
}
function palOpen() { $('#palOv').hidden = false; $('#palInput').value = ''; palSel = 0; palRender(); $('#palInput').focus(); }
function palClose() { $('#palOv').hidden = true; }
function palRun(n) { const i = palRows[n]; if (i) { palClose(); i.run(); } }
$('#palBtn').addEventListener('click', palOpen);
$('#palEsc').addEventListener('click', palClose);

// SP-Test triggers
document.addEventListener('click', async e => {
  const btn = e.target.closest('[data-sp-test]');
  if (!btn) return;
  e.stopPropagation();
  const id = btn.dataset.spTest, label = btn.textContent;
  btn.disabled = true;
  btn.textContent = '⚡ Testing…';
  try {
    const res = await (await api('speedtest', { id })).json();
    if (res.ok) {
      toast(`⚡ Download Speed: ${res.mbps} Mbps (${res.elapsed}s)`);
      await refresh();
      if (S.tab === 'speedtest') renderSpeedTestTab();
    } else {
      toast(res.error || 'Speed test failed', 'err');
    }
  } catch(ex) {
    toast('Speed test communication error', 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
});

$('#spTestAllBtn')?.addEventListener('click', async () => {
  toast('Started 100MB speed test across all healthy nodes...');
  const res = await (await api('speedtest/all', {})).json();
  if (res.ok) toast('Running 100MB tests in background. Cards will update sequentially.');
  else toast(res.error || 'Could not start', 'err');
});
$('#palOv').addEventListener('click', e => { if (e.target.id === 'palOv') palClose(); });
$('#palInput').addEventListener('input', () => { palSel = 0; palRender(); });
$('#palList').addEventListener('click', e => { const r = e.target.closest('.pal-it'); if (r) palRun(+r.dataset.n); });
$('#palInput').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { palSel = Math.min(palRows.length - 1, palSel + 1); palRender(); e.preventDefault(); }
  else if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); palRender(); e.preventDefault(); }
  else if (e.key === 'Enter') palRun(palSel);
});
addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('#subModal').classList.contains('hidden')) { closeSubs(); return; }
  if (e.key === 'Escape' && !$('#cleanSubModal').classList.contains('hidden')) { closeCleanSub(); return; }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k' && !$('#app').classList.contains('hidden')) { e.preventDefault(); $('#palOv').hidden ? palOpen() : palClose(); }
  if (e.key === 'Escape') { if ($('#supCard') && !$('#supCard').hidden) supHide('close'); else if (!$('#palOv').hidden) palClose(); else if (S.drawerId) closeDrawer(); else if (!$('#importModal').classList.contains('hidden')) closeImport(); }
});

/* ---------- login background: kinetic grid (Hashem exact) ---------- */
(function(){
  const CELL_SIZE = 55, INFLUENCE_RADIUS = 260, MAX_WARP = 24;
  const DOT_SPACING = 28, LERP_SPEED = 0.08;
  const LINE_BASE = { r: 255, g: 255, b: 255, a: 0.13 };
  const NODE_BASE_RADIUS = 1.8, NODE_ACTIVE_RADIUS = 3.2;
  const lerpN = (a,b,t) => a + (b - a) * t;
  const lerpColor = (base,active,t) => {
    const r = Math.round(lerpN(base.r,active.r,t)), g = Math.round(lerpN(base.g,active.g,t)),
          b = Math.round(lerpN(base.b,active.b,t)), a = lerpN(base.a,active.a,t);
    return 'rgba('+r+','+g+','+b+','+a.toFixed(3)+')';
  };
  const canvas = document.getElementById('kineticGrid');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, mouse = {x:-9999,y:-9999}, targetMouse = {x:-9999,y:-9999}, ripples = [];
  const theme = { bg:'#09090b', lineActive:{r:56,g:189,b:248,a:0.9},
    nodeActive:{r:56,g:189,b:248,a:1.0}, glow:'56,189,248', ripple:'56,189,248' };
  function setSize(){ W = innerWidth; H = innerHeight; canvas.width = W; canvas.height = H;
    if (mouse.x === -9999) { mouse = {x:W/2,y:H/2}; targetMouse = {x:W/2,y:H/2}; } }
  addEventListener('resize', setSize); setSize();
  addEventListener('mousemove', e => { targetMouse.x = e.clientX; targetMouse.y = e.clientY; });
  addEventListener('click', e => { ripples.push({x:e.clientX,y:e.clientY,radius:0,opacity:1,born:performance.now()}); });
  function getWarpedPoint(gx,gy,col,row,cols,rows){
    const edgeMargin = 1.5;
    const colPin = Math.min(col/edgeMargin,(cols-1-col)/edgeMargin,1);
    const rowPin = Math.min(row/edgeMargin,(rows-1-row)/edgeMargin,1);
    const pinFactor = colPin*colPin*rowPin*rowPin;
    const dx = gx-mouse.x, dy = gy-mouse.y, dist = Math.sqrt(dx*dx+dy*dy);
    const proximity = Math.max(0,1-dist/INFLUENCE_RADIUS)*pinFactor;
    let rx = 0, ry = 0;
    for (const r of ripples){
      const rdx = gx-r.x, rdy = gy-r.y, rdist = Math.sqrt(rdx*rdx+rdy*rdy);
      const waveWidth = 55, diff = rdist-r.radius;
      if (Math.abs(diff) < waveWidth){
        const strength = (1-Math.abs(diff)/waveWidth)*r.opacity*18*pinFactor;
        const angle = Math.atan2(rdy,rdx), sign = diff < 0 ? -1 : 1;
        rx += Math.cos(angle)*strength*sign*-1; ry += Math.sin(angle)*strength*sign*-1;
      }
    }
    if (dist < INFLUENCE_RADIUS && dist > 0 && pinFactor > 0){
      const t = dist/INFLUENCE_RADIUS;
      const eased = t < 0.01 ? 0 : (1-t)*(1-t)*Math.min(1,dist/60);
      const warpAmt = eased*MAX_WARP*pinFactor, angle = Math.atan2(dy,dx);
      return { pt:{x:gx-Math.cos(angle)*warpAmt+rx, y:gy-Math.sin(angle)*warpAmt+ry}, proximity };
    }
    return { pt:{x:gx+rx, y:gy+ry}, proximity };
  }
  function draw(now){
    ctx.clearRect(0,0,W,H); ctx.fillStyle = theme.bg; ctx.fillRect(0,0,W,H);
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    for (let x = DOT_SPACING/2; x < W; x += DOT_SPACING)
      for (let y = DOT_SPACING/2; y < H; y += DOT_SPACING){
        ctx.beginPath(); ctx.arc(x,y,0.7,0,Math.PI*2); ctx.fill();
      }
    for (let i = ripples.length-1; i >= 0; i--){
      const r = ripples[i], age = (now-r.born)/1000;
      r.radius = Math.max(0,age*400); r.opacity = Math.max(0,1-age*1.2);
      if (r.opacity <= 0) ripples.splice(i,1);
    }
    const cols = Math.max(2,Math.ceil(W/CELL_SIZE))+1, rows = Math.max(2,Math.ceil(H/CELL_SIZE))+1;
    const cellW = W/(cols-1), cellH = H/(rows-1), pts = [], prox = [];
    for (let row = 0; row < rows; row++){
      pts[row] = []; prox[row] = [];
      for (let col = 0; col < cols; col++){
        const wp = getWarpedPoint(col*cellW,row*cellH,col,row,cols,rows);
        pts[row][col] = wp.pt; prox[row][col] = wp.proximity;
      }
    }
    const drawSeg = (p1,p2,pr1,pr2) => {
      const avg = (pr1+pr2)/2, t = avg*avg*(3-2*avg);
      ctx.beginPath(); ctx.moveTo(p1.x,p1.y); ctx.lineTo(p2.x,p2.y);
      ctx.strokeStyle = lerpColor(LINE_BASE,theme.lineActive,t);
      ctx.lineWidth = lerpN(0.8,1.5,t); ctx.stroke();
    };
    ctx.lineCap = 'butt';
    for (let row = 0; row < rows; row++)
      for (let col = 0; col < cols-1; col++) drawSeg(pts[row][col],pts[row][col+1],prox[row][col],prox[row][col+1]);
    for (let col = 0; col < cols; col++)
      for (let row = 0; row < rows-1; row++) drawSeg(pts[row][col],pts[row+1][col],prox[row][col],prox[row+1][col]);
    for (let row = 0; row < rows; row++)
      for (let col = 0; col < cols; col++){
        const p = pts[row][col], pr = prox[row][col], t = pr*pr*(3-2*pr);
        const r = lerpN(NODE_BASE_RADIUS,NODE_ACTIVE_RADIUS,t);
        if (t > 0.3){
          const glowR = r+lerpN(0,6,(t-0.3)/0.7);
          const grd = ctx.createRadialGradient(p.x,p.y,r*0.5,p.x,p.y,glowR);
          grd.addColorStop(0,'rgba('+theme.glow+','+(t*0.3).toFixed(3)+')');
          grd.addColorStop(1,'rgba('+theme.glow+',0)');
          ctx.beginPath(); ctx.arc(p.x,p.y,glowR,0,Math.PI*2);
          ctx.fillStyle = grd; ctx.fill();
        }
        ctx.beginPath(); ctx.arc(p.x,p.y,r,0,Math.PI*2);
        ctx.fillStyle = lerpColor({r:255,g:255,b:255,a:0.2},theme.nodeActive,t); ctx.fill();
      }
    for (const r of ripples){
      ctx.beginPath(); ctx.arc(r.x,r.y,Math.max(0,r.radius),0,Math.PI*2);
      ctx.strokeStyle = 'rgba('+theme.ripple+','+(r.opacity*0.28).toFixed(3)+')';
      ctx.lineWidth = 1.5; ctx.stroke();
    }
  }
  (function animate(now){
    mouse.x = lerpN(mouse.x,targetMouse.x,LERP_SPEED);
    mouse.y = lerpN(mouse.y,targetMouse.y,LERP_SPEED);
    draw(now); requestAnimationFrame(animate);
  })(0);
})();

/* ---------- boot ---------- */
(async function boot() {
  const a = localStorage.getItem('sentinel_accent'); if (a) setAccent(a); loadCleanSub(); load2FaStatus();
  const r = await api('dashboard').catch(() => null);
  if (r?.ok) {
    S.data = await r.json(); showApp(); render();
    const h = location.hash.slice(1); switchTab(TITLES[h] ? h : 'dashboard');
    refresh();
  } else showLogin();
})();

/* ---------- Feature: diagnostics ---------- */
/* Why a config is down: the likely cause and each direct check (DNS, connection, TLS, proxy),
   "Diagnose again", and certificate pinning for TLS links with insecure=1.
   The drawer is rebuilt on every refresh, so replies are cached here and rendered from the cache. */
const DG = { cache: {}, at: {}, timer: {}, busy: {} };
const DG_MARK = { ok: '✓', fail: '✕', unknown: '?' };
const DG_SOFT = ['unknown', 'not_probed', 'udp_unknown'];
function dgHtml(id) {
  const r = DG.cache[id];
  if (!r) return '<div class="dg-box" id="dgBox"><div class="dg-sub">Loading diagnosis…</div></div>';
  const d = r.diag, run = r.running, p = r.pin;
  const tone = d ? (d.cause === 'healthy' ? 'ok' : DG_SOFT.includes(d.cause) ? 'warn' : 'err') : '';
  const sub = run ? 'Running checks from this server…'
    : d ? `Ran ${ago(d.ran_at)}${d.auto ? ' · automatic' : ''} · direct from this server, not through the proxy`
    : 'Checks DNS, the connection and TLS directly from this server.';
  let h = `<div class="dg-box" id="dgBox">
    <div class="dg-head"><div><b>Diagnosis</b><span class="dg-sub">${sub}</span></div>
      <button class="hashem-btn hashem-btn-secondary" id="dgRun" ${run ? 'disabled' : ''}>${run ? 'Diagnosing…' : d ? 'Diagnose again' : 'Diagnose'}</button></div>`;
  if (d) h += `<div class="dg-verdict ${tone}"><b>Likely: ${esc(d.title)}</b><span>${esc(d.action)}</span></div>
    <ul class="dg-stages">${d.stages.map(s => `<li class="${esc(s.status)}"><i aria-hidden="true">${DG_MARK[s.status] || '?'}</i><b>${esc(s.name)}</b><span>${esc(s.detail)}</span></li>`).join('')}</ul>`;
  if (p && p.eligible) {
    const why = p.sha ? `Pinned ${ago(p.at)}: <code>${esc(p.sha.slice(0, 16))}…</code>. Checks trust only this certificate.`
      : `This link skips certificate checks (insecure=1)${p.xray_insecure ? '.' : ', which the installed Xray no longer allows, so a self-signed certificate fails.'} Pin the certificate the server presents now so checks can verify it.`;
    h += `<div class="dg-pin"><div><b>Certificate</b><span>${why}</span>
        ${p.sha && p.note === 'trusted' ? '<span>This certificate is publicly trusted, so the pin is not needed and stops working when it renews.</span>' : ''}
        ${p.error ? `<span class="dg-err">${esc(p.error)}</span>` : ''}</div>
      <div class="dg-pin-btns">${p.sha ? '<button class="hashem-btn hashem-btn-secondary" id="dgUnpin">Remove pin</button>' : ''}
        <button class="hashem-btn hashem-btn-secondary" id="dgPin" ${p.running ? 'disabled' : ''}>${p.running ? 'Fetching…' : p.sha ? 'Pin again' : 'Pin certificate'}</button></div></div>`;
  }
  return h + '</div>';
}
function dgPaint(id) {
  const box = $('#dgBox'); if (!box || S.drawerId !== id) return;
  box.outerHTML = dgHtml(id); dgBind(id);
}
function dgSet(id, r) {
  const was = DG.cache[id];
  if (was?.pin?.running && r.pin && !r.pin.running) r.pin.error ? toast(r.pin.error, 'err') : toast('Certificate pinned');
  if (was?.running && !r.running && r.diag) toast('Diagnosis finished');
  DG.cache[id] = r; DG.at[id] = Date.now(); dgPaint(id);
  if ((r.running || r.pin?.running) && S.drawerId === id && !DG.timer[id])
    DG.timer[id] = setTimeout(() => { DG.timer[id] = null; dgFetch(id); }, 1500);
}
async function dgFetch(id) {
  if (DG.busy[id]) return; DG.busy[id] = true;
  try { const r = await api(`diag?id=${encodeURIComponent(id)}`); if (r.ok) dgSet(id, await r.json()); }
  catch { /* 401 handled in api() */ } finally { DG.busy[id] = false; }
}
async function dgPost(ep, body) {
  const r = await api(ep, body), j = await r.json().catch(() => ({}));
  if (!r.ok) return toast(j.error || 'Request failed', 'err');
  dgSet(body.id, j);
}
function dgBind(id) {
  const run = $('#dgRun'); if (run) run.onclick = () => { run.disabled = true; dgPost('diag/run', { id }); };
  const pin = $('#dgPin'); if (pin) pin.onclick = () => { pin.disabled = true; dgPost('diag/pin', { id }); };
  const un = $('#dgUnpin'); if (un) un.onclick = async () => {
    if (!confirm('Remove the pinned certificate? Checks of this link will verify the certificate normally again.')) return;
    await dgPost('diag/pin', { id, remove: 1 }); toast('Pin removed');
  };
}
HOOKS.drawer.push(c => dgHtml(c.id));
HOOKS.drawerBind.push(c => {
  dgBind(c.id);
  const r = DG.cache[c.id];
  if (!r || Date.now() - (DG.at[c.id] || 0) > 30000) dgFetch(c.id);
});
HOOKS.settings.push(s => { const el = $('#dgAutoPin'); if (el && !el.dataset.dirty) el.checked = s.auto_pin === '1'; });
$('#dgAutoPin')?.addEventListener('change', e => { e.target.dataset.dirty = '1'; });
$('#saveProbe').addEventListener('click', async () => {
  const el = $('#dgAutoPin'); if (!el?.dataset.dirty) return;
  const r = await api('settings', { auto_pin: el.checked ? '1' : '0' });
  if (r.ok) { delete el.dataset.dirty; if (S.data) S.data.settings.auto_pin = el.checked ? '1' : '0'; }
  else toast((await r.json()).error || 'Could not save automatic pinning', 'err');
});



/* ---------- Feature: alert channels ---------- */
/* Bale and a webhook, sent straight from the server; the "Everything is down" switch under Notifications. */
const AL = {
  bale: { badge: '#alBaleBadge', res: '#alBaleRes', mode: '#alBaleMode', help: '#alBaleModeHelp', test: '#alBaleTest' },
  webhook: { badge: '#alHookBadge', res: '#alHookRes', mode: '#alHookMode', help: '#alHookModeHelp', test: '#alHookTest' },
};
const AL_MODE_HELP = {
  off: 'Never used, not even when everything is down.',
  fallback: 'Gets an alert only when it could not reach Telegram, and always gets the “everything is down” alert.',
  always: 'Gets every alert, as well as Telegram.',
};
const alResShown = {};  // channel -> true while a fresh test result is on screen
function alBadge(info) {
  if (!info || !info.configured) return ['Not set up', 'dim'];
  if (info.mode === 'off') return ['Off', 'dim'];
  const st = info.status || {};
  if (!st.at) return ['Not tested', 'info'];
  return st.ok ? ['Connected', 'ok'] : ['Failing', 'err'];
}
function alRes(ch, text, kind) {
  const el = $(AL[ch].res); if (!el) return;
  el.textContent = text; el.className = 'al-res' + (kind ? ' ' + kind : '');
}
function alDraw(d) {
  const info = d.alert_channels; if (!info) return;
  for (const ch of Object.keys(AL)) {
    const c = info[ch] || {}, [txt, cls] = alBadge(c), b = $(AL[ch].badge);
    if (b) { b.textContent = txt; b.className = `badge sm ${cls}`; }
    const st = c.status || {};
    if (alResShown[ch]) continue;
    if (c.configured && st.at && !st.ok) alRes(ch, `Last send failed ${ago(st.at)}: ${st.error || 'no reason given'}`, 'err');
    else if (c.configured && st.at) alRes(ch, `Last send worked ${ago(st.at)}.`, '');
    else alRes(ch, c.configured ? 'Saved. Send a test to check it.' : '', '');
  }
}
function alModeHelp() {
  for (const ch of Object.keys(AL)) { const m = $(AL[ch].mode), h = $(AL[ch].help); if (m && h) h.textContent = AL_MODE_HELP[m.value] || ''; }
}
function alFill(s) {
  const nd = $('#nAllDown'); if (nd) nd.checked = s.notify_all_down !== '0';
  if (!$('#set-channels')) return;
  $('#alBaleToken').value = ''; $('#alBaleToken').placeholder = s.bale_token_configured ? 'Saved — leave blank to keep' : 'From @BotFather in Bale';
  $('#alBaleChat').value = s.bale_chat || '';
  $('#alHookUrl').value = ''; $('#alHookUrl').placeholder = s.webhook_url_configured ? 'Saved — leave blank to keep' : 'https://example.com/hook';
  $('#alHookSecret').value = ''; $('#alHookSecret').placeholder = s.webhook_secret_configured ? 'Saved — leave blank to keep' : 'Any shared secret';
  $('#alBaleMode').value = s.bale_mode || 'fallback'; $('#alHookMode').value = s.webhook_mode || 'fallback';
  $('#alBaleBackup').checked = s.bale_backup === '1';
  alModeHelp();
}
/* Blank secret fields keep the saved value; "-" removes it. */
function alFields(ch) {
  if (ch === 'bale') {
    const p = { bale_chat: $('#alBaleChat').value.trim(), bale_mode: $('#alBaleMode').value, bale_backup: $('#alBaleBackup').checked ? '1' : '0' };
    const t = $('#alBaleToken').value.trim(); if (t) p.bale_token = t;
    return p;
  }
  const p = { webhook_mode: $('#alHookMode').value };
  const u = $('#alHookUrl').value.trim(); if (u) p.webhook_url = u;
  const k = $('#alHookSecret').value.trim(); if (k) p.webhook_secret = k;
  return p;
}
async function alSave(body) {
  const r = await api('settings', body);
  if (r.ok) return null;
  try { return (await r.json()).error || 'Could not save'; } catch (e) { return 'Could not save'; }
}
/* Save this channel, start a test send on the server, then poll until it is done. */
async function alTest(ch) {
  const btn = $(AL[ch].test); btn.disabled = true; alResShown[ch] = true;
  try {
    alRes(ch, 'Saving…', '');
    const err = await alSave(alFields(ch));
    if (err) { alRes(ch, err, 'err'); return; }
    alRes(ch, 'Sending a test message…', '');
    let job = await (await api('al-test', { channel: ch })).json();
    for (let i = 0; job.running && i < 40; i++) {
      await new Promise(r => setTimeout(r, 750));
      job = await getJSON(`al-test?channel=${ch}`);
    }
    if (job.running) alRes(ch, 'Still sending. The badge updates when it is done.', '');
    else if (job.ok) alRes(ch, 'Test message delivered.', 'ok');
    else alRes(ch, `Not delivered: ${job.error || 'no reason given'}`, 'err');
    $('#tab-settings').dataset.filled = ''; refresh();
  } catch (e) {
    alRes(ch, `Error: ${e.message}`, 'err');
  } finally { btn.disabled = false; }
}
if ($('#set-channels')) {
  $$('.al-mode').forEach(m => m.addEventListener('change', alModeHelp));
  $('#alBaleTest').addEventListener('click', () => alTest('bale'));
  $('#alHookTest').addEventListener('click', () => alTest('webhook'));
  $('#alSave').addEventListener('click', async () => {
    const err = await alSave({ ...alFields('bale'), ...alFields('webhook') });
    if (err) { toast(err, 'err'); return; }
    toast('Alert channels saved'); alResShown.bale = alResShown.webhook = false;
    $('#tab-settings').dataset.filled = ''; refresh();
  });
}
HOOKS.settings.push(alFill);
HOOKS.refresh.push(alDraw);



/* ---------- Feature: engines ---------- */
/* Settings -> Engines: versions and state of Xray and sing-box, restart, install sing-box. */
const EN_STATE = { running: ['ok', 'Running'], idle: ['dim', 'Idle'], stopped: ['err', 'Stopped'], missing: ['dim', 'Not installed'] };
const enMB = n => (n / 1048576).toFixed(1);
const enPlural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
function enMsg(el, text, kind) {
  el.hidden = !text; el.textContent = text || ''; el.className = `en-msg${kind ? ' en-' + kind : ''}`;
}
function renderEngines(e) {
  if (!e || !$('#set-engines')) return;
  S.engines = e;
  const x = e.xray, sb = e.singbox, ins = e.install;
  $('#enSentinelVer').textContent = e.sentinel || '—';
  // Xray
  const [xk, xl] = EN_STATE[x.state] || EN_STATE.missing;
  $('#enXrayBadge').className = `badge sm ${xk}`; $('#enXrayBadge').textContent = xl;
  $('#enXrayVer').textContent = x.version || (x.installed ? 'Unknown' : 'Not installed');
  $('#enXrayText').textContent = !x.installed ? `Not installed. Put the binary in Sentinel's folder or run the installer again.`
    : x.configs ? `Runs ${enPlural(x.configs, 'config', 'configs')}.` : 'No config uses it right now.';
  enMsg($('#enXrayMsg'), x.old ? `Version ${x.version} is older than ${x.min}, the minimum: Hysteria2 links need ${x.min} or newer.${x.error ? ' ' + x.error : ''}` : x.error,
    x.old ? 'warn' : x.state === 'stopped' ? 'err' : 'warn');
  // sing-box
  const [sk, sl] = sb.installed && !sb.usable ? ['warn', sb.old ? 'Too old' : 'Not working'] : EN_STATE[sb.state] || EN_STATE.missing;
  $('#enSbBadge').className = `badge sm ${sk}`; $('#enSbBadge').textContent = sl;
  $('#enSbVer').textContent = sb.installed ? (sb.version || 'Unknown') : 'Not installed';
  const need = sb.configs ? `${enPlural(sb.configs, 'config needs', 'configs need')} it` : 'No config needs it yet';
  $('#enSbText').textContent = !sb.usable
    ? `${need}${sb.waiting ? `; ${sb.waiting === 1 ? 'it is' : 'they are'} not checked until sing-box ${sb.installed ? sb.min + ' or newer ' : ''}is installed` : ''}.`
    : `${need}.${sb.waiting ? ` ${enPlural(sb.waiting, 'config waits', 'configs wait')} for a sing-box build with NaiveProxy.` : ''}`;
  enMsg($('#enSbMsg'), sb.usable ? sb.error : sb.old ? `Version ${sb.version} is older than ${sb.min}, the minimum.` : '', sb.usable && sb.state === 'stopped' ? 'err' : 'warn');
  // install progress or result
  const row = $('#enInstallRow'), bar = $('#enInstallBar');
  const recent = ins.at && Date.now() / 1000 - ins.at < 600;
  row.hidden = !(ins.running || (recent && ins.ok !== null));
  if (ins.running) {
    $('#enInstallTitle').textContent = 'Installing sing-box';
    $('#enInstallText').className = '';
    $('#enInstallText').textContent = `${ins.stage}${ins.total ? ` — ${enMB(ins.done)} of ${enMB(ins.total)} MB` : ins.done ? ` — ${enMB(ins.done)} MB` : '…'}`;
    const pct = ins.total ? Math.round(100 * ins.done / ins.total) : 0;
    bar.style.width = `${pct}%`; $('#enInstallBarWrap').setAttribute('aria-valuenow', pct);
    $('#enInstallBarWrap').hidden = false;
  } else if (!row.hidden) {
    $('#enInstallTitle').textContent = ins.ok ? 'sing-box installed' : 'sing-box was not installed';
    $('#enInstallText').textContent = ins.ok ? ins.stage
      : `${ins.error} If GitHub cannot be reached from this server, copy the sing-box binary into Sentinel's folder by hand.`;
    $('#enInstallText').className = ins.ok ? '' : 'en-err';
    $('#enInstallBarWrap').hidden = true;
  }
  const ib = $('#enInstall');
  ib.disabled = !!ins.running;
  ib.textContent = ins.running ? 'Installing…' : sb.installed && sb.usable ? 'Reinstall sing-box' : sb.installed ? 'Update sing-box' : 'Install sing-box';
  ib.className = `hashem-btn ${sb.usable && !sb.waiting ? 'hashem-btn-secondary' : 'hashem-btn-primary'}`;
  // header badge
  const trouble = x.state === 'stopped' || sb.state === 'stopped' || x.old || (sb.installed && !sb.usable) || sb.waiting;
  $('#enBadge').className = `badge sm ${trouble ? 'warn' : 'ok'}`;
  $('#enBadge').textContent = trouble ? 'Needs attention' : 'Working';
  if (ins.running) enPoll();
}
let enPollT = null;
function enPoll() {
  if (enPollT) return;
  enPollT = setTimeout(async () => {
    enPollT = null;
    const e = await getJSON('engines').catch(() => null);
    if (!e) return;
    const was = S.engines?.install?.running;
    renderEngines(e);
    if (was && !e.install.running) { toast(e.install.ok ? e.install.stage : 'sing-box was not installed', e.install.ok ? 'ok' : 'err'); refresh(); }
  }, 1500);
}
HOOKS.refresh.push(d => renderEngines(d.engines));
$('#enRestart')?.addEventListener('click', async e => {
  const b = e.currentTarget; b.disabled = true; b.textContent = 'Restarting…';
  try {
    const r = await api('engines/restart', {});
    const d = await r.json().catch(() => ({}));
    r.ok ? toast('Restarting Xray and sing-box') : toast(d.error || 'Could not restart the engines', 'err');
    setTimeout(refresh, 2500);
  } catch { toast('Could not restart the engines', 'err'); }
  finally { setTimeout(() => { b.disabled = false; b.textContent = 'Restart engines'; }, 2500); }
});
$('#enInstall')?.addEventListener('click', async e => {
  const b = e.currentTarget; b.disabled = true;
  try {
    const r = await api('engines/install', {});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { toast(d.error || 'Could not start the download', 'err'); b.disabled = false; return; }
    toast('Downloading sing-box; this can take a few minutes');
    const en = await getJSON('engines').catch(() => null);
    if (en) renderEngines(en);
  } catch { toast('Could not start the download', 'err'); b.disabled = false; }
});
// Config drawer: which engine runs it, and why it waits.
HOOKS.drawer.push((c, d, live) => live.engine !== 'sing-box' && !live.engine_note ? '' : `
    <div class="field"><label class="field-lbl">Engine</label><div class="en-drawer">${live.engine === 'sing-box' ? 'sing-box' : 'Xray'}${live.engine_note && state(live) !== 'down' && state(live) !== 'fail' ? noteBox(live.engine_note) : ''}</div></div>`);



/* ---------- Feature: performance ---------- */
/* Slow limits and the speed schedule (Settings), speed history in the config drawer,
   and the trend of each config on the Speed Test page. */
const PF = { hist: {}, loading: null };

/* Latest test against the 7-day average: an arrow, or '' with fewer than 2 tests. */
function pfTrendHtml(c) {
  const a = S.data?.perf?.avg7?.[c.id];
  if (!a || a[1] < 2 || !c.last_speed_mbps || !a[0]) return '';
  const pct = Math.round((c.last_speed_mbps / a[0] - 1) * 100);
  const dir = pct > 5 ? 'up' : pct < -5 ? 'down' : 'flat';
  const txt = dir === 'flat' ? 'Steady' : `${pct > 0 ? '+' : ''}${pct}%`;
  const icon = { up: '▲', down: '▼', flat: '▬' }[dir];
  return `<div class="pf-trend pf-${dir}" title="Latest test against the average of ${a[1]} tests in the last 7 days">
    <span>${icon} ${txt}</span><span>7-day avg ${a[0]} Mbps</span></div>`;
}

/* A small speed-over-time chart: one dot per test, scheduled tests hollow. */
function pfChart(pts) {
  const W = 320, H = 96, L = 34, R = 6, T = 8, B = 18;
  const t0 = pts[0].tested_at, t1 = Math.max(pts.at(-1).tested_at, t0 + 3600);
  const top = Math.max(10, Math.ceil(Math.max(...pts.map(p => p.mbps)) * 1.15 / 10) * 10);
  const X = t => L + (W - L - R) * (pts.length === 1 ? .5 : (t - t0) / (t1 - t0)), Y = v => T + (H - T - B) * (1 - v / top);
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.tested_at).toFixed(1)},${Y(p.mbps).toFixed(1)}`).join(' ');
  const day = t => new Date(t * 1000).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  const grid = [0, .5, 1].map(f => `<line class="pf-grid" x1="${L}" x2="${W - R}" y1="${Y(top * f).toFixed(1)}" y2="${Y(top * f).toFixed(1)}"/>
    <text class="pf-axis" x="${L - 4}" y="${(Y(top * f) + 3).toFixed(1)}" text-anchor="end">${Math.round(top * f)}</text>`).join('');
  const dots = pts.map(p => `<circle class="${p.source === 'scheduled' ? 'pf-dot pf-dot-s' : 'pf-dot'}" cx="${X(p.tested_at).toFixed(1)}" cy="${Y(p.mbps).toFixed(1)}" r="2.6"><title>${p.mbps} Mbps · ${esc(p.source)} · ${when(p.tested_at)}</title></circle>`).join('');
  return `<svg class="pf-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Download speed over time, in Mbps">${grid}
    ${pts.length > 1 ? `<path class="pf-line" d="${line}"/>` : ''}${dots}
    <text class="pf-axis" x="${L}" y="${H - 4}">${day(t0)}</text><text class="pf-axis" x="${W - R}" y="${H - 4}" text-anchor="end">${pts.length > 1 ? day(t1) : ''}</text></svg>`;
}

function pfDrawerHtml(d) {
  if (!d.points.length) return `<div class="field-lbl">Speed history</div><div class="u-mu" style="font-size:12px">No speed tests yet. Run one below, or turn on scheduled tests in Settings, Performance.</div>`;
  const tr = { up: ' ▲', down: ' ▼', flat: '' }[d.trend] || '';
  return `<div class="field-lbl">Speed history <span class="u-mu" style="text-transform:none;font-weight:400">· ${d.points.length} test${d.points.length > 1 ? 's' : ''}, last 90 days</span></div>
    <div class="pf-stats">
      <div><span>Latest</span><b>${d.latest} Mbps${tr}</b></div>
      <div><span>Average</span><b>${d.avg} Mbps</b></div>
      <div><span>Lowest</span><b>${d.min} Mbps</b></div>
    </div>
    ${pfChart(d.points)}
    ${d.avg7 != null && d.n7 > 1 ? `<div class="set-help" style="margin-top:4px">7-day average ${d.avg7} Mbps from ${d.n7} tests. Hollow dots are scheduled tests.</div>` : ''}`;
}

async function pfLoadHist(id, key) {
  if (PF.loading === id + ':' + key) return;
  PF.loading = id + ':' + key;
  const d = await getJSON(`perf/speed?id=${encodeURIComponent(id)}`).catch(() => null);
  PF.loading = null;
  if (!d || d.error) return;
  PF.hist[id] = { key, data: d };
  const el = $('#pfDrawer');
  if (el && S.drawerId === id) el.innerHTML = pfDrawerHtml(d);
}

// The drawer is rebuilt on every poll: reuse the history until a new test lands.
HOOKS.drawer.push((c, d, live) => {
  const key = String(live.last_speed_time || 0), h = PF.hist[c.id];
  if (!h || h.key !== key) pfLoadHist(c.id, key);
  return `<div class="pf-drawer" id="pfDrawer">${h ? pfDrawerHtml(h.data) : '<div class="u-mu" style="font-size:12px">Loading speed history…</div>'}</div>`;
});

/* Settings */
function pfCostText() {
  const p = S.data?.perf || {}, h = +$('#pfEvery').value, mb = +$('#pfSize').value, n = p.working ?? 0;
  if (!h) return 'Download per config and run. Smaller saves bandwidth on metered servers but reads a little lower.';
  const day = n * mb * (24 / h), size = day >= 1024 ? `${(day / 1024).toFixed(1)} GB` : `${day} MB`;
  return `About ${size} a day: ${n} working config${n === 1 ? '' : 's'} × ${mb} MB × ${24 / h} runs. Smaller sizes read a little lower.`;
}
function pfStatus() {
  const p = S.data?.perf, s = S.data?.settings || {};
  const on = +(s.slow_ms || 0) > 0 || +(s.slow_mbps || 0) > 0, sched = +(s.speed_every_hours || 0) > 0;
  const b = $('#pfBadge');
  b.textContent = on && sched ? 'On' : on ? 'Limits on' : sched ? 'Schedule on' : 'Off';
  b.className = `badge sm ${on || sched ? 'ok' : 'dim'}`;
  $('#pfCost').textContent = pfCostText();
  const help = $('#pfEveryHelp'), base = 'Tests every working config, one at a time, never while you run a test yourself.';
  const sc = p?.sched;
  if (!sched || !sc) { help.textContent = base; return; }
  const now = Date.now() / 1000;
  help.textContent = sc.running ? `Running now: ${sc.done} of ${sc.total} done.`
    : `${sc.last ? `Last run ${ago(sc.last)}. ` : ''}${sc.next && sc.next > now ? `Next in ${dur(Math.round(sc.next - now))}.` : 'Next run starts within a minute.'}`;
}
HOOKS.settings.push(s => {
  $('#pfSlowMs').value = s.slow_ms ?? '0';
  $('#pfSlowMbps').value = s.slow_mbps ?? '0';
  $('#pfNotify').checked = s.notify_slow === '1';
  $('#pfEvery').value = s.speed_every_hours ?? '0';
  $('#pfSize').value = s.speed_size_mb ?? '100';
  pfStatus();
});
HOOKS.refresh.push(() => { if (S.tab === 'settings') pfStatus(); });
['#pfEvery', '#pfSize'].forEach(id => $(id).addEventListener('change', () => { $('#pfCost').textContent = pfCostText(); }));
$('#pfSave').addEventListener('click', async () => {
  const r = await api('settings', {
    slow_ms: $('#pfSlowMs').value || '0', slow_mbps: $('#pfSlowMbps').value || '0',
    notify_slow: $('#pfNotify').checked ? '1' : '0',
    speed_every_hours: $('#pfEvery').value, speed_size_mb: $('#pfSize').value,
  });
  if (r.ok) { toast('Performance settings saved'); $('#tab-settings').dataset.filled = ''; refresh(); }
  else toast((await r.json()).error || 'Could not save', 'err');
});



/* ---------- Feature: sharing ---------- */
/* Customer feeds, the public status page and the public address, in Settings > Sharing. */
const SH = { data: null, json: '', at: 0, qr: null, edit: null };
const SH_SRC = { setting: 'set above', certificate: 'from the HTTPS certificate', ip: "the server's IP" };
const shPlural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
function shSummary(f) {
  const o = SH.data?.options || {}, parts = [];
  parts.push(f.protocols.length ? f.protocols.map(p => p.toUpperCase()).join(', ') : 'All protocols');
  parts.push(f.countries.length ? f.countries.join(', ') : 'all countries');
  if (f.source) parts.push(f.source_name || 'one subscription');
  parts.push((o.sorts?.[f.sort] || f.sort).toLowerCase());
  if (f.max_items) parts.push(`at most ${f.max_items}`);
  return parts.join(' · ');
}
function shCard(f, main) {
  const stats = `${f.fetch_count} ${f.fetch_count === 1 ? 'fetch' : 'fetches'} · ${shPlural(f.clients, 'client')} in ${SH.data.client_days} days · last ${f.last_fetch ? ago(f.last_fetch) : 'never'}`;
  const acts = main
    ? `<button class="hashem-btn hashem-btn-ghost" data-act="rotate" type="button">Rotate link</button>`
    : `<button class="hashem-btn hashem-btn-ghost" data-act="edit" type="button">Edit</button>
       <button class="hashem-btn hashem-btn-ghost" data-act="rotate" type="button">Rotate link</button>
       <button class="hashem-btn hashem-btn-ghost" data-act="toggle" type="button">${f.enabled ? 'Turn off' : 'Turn on'}</button>
       <button class="hashem-btn hashem-btn-ghost shr-del" data-act="delete" type="button">Delete</button>`;
  return `<div class="shr-feed${f.enabled ? '' : ' off'}" data-id="${esc(f.id)}">
    <div class="shr-feed-head">
      <div><b>${esc(f.name)}${main ? ' <span class="badge dim sm">Main</span>' : f.enabled ? '' : ' <span class="badge warn sm">Off</span>'}</b>
        <span>${esc(main ? 'Every healthy config. Customers already use this link.' : shSummary(f))}</span></div>
      <span class="shr-items" title="Configs this link serves right now">${shPlural(f.items, 'config')}</span>
    </div>
    <div class="shr-inline">
      <input class="hashem-input set-mono" type="text" readonly value="${esc(f.url)}" aria-label="Link of ${esc(f.name)}">
      <button class="hashem-btn hashem-btn-secondary" data-act="copy" type="button">Copy</button>
      <button class="hashem-btn hashem-btn-secondary" data-act="qr" type="button" aria-expanded="${SH.qr === f.id}">QR</button>
    </div>
    <div class="shr-qr"${SH.qr === f.id ? '' : ' hidden'}><div></div></div>
    <div class="shr-foot"><span class="shr-stats">${esc(f.enabled ? stats : 'Turned off: the link answers like a wrong link. ' + stats)}</span><div class="shr-acts">${acts}</div></div>
  </div>`;
}
function shQr(card, url) {
  const box = card.querySelector('.shr-qr > div'); if (!box) return;
  box.innerHTML = '';
  if (!window.QRCode) { box.textContent = 'QR code unavailable'; return; }
  try { new QRCode(box, { text: url, width: 168, height: 168, colorDark: '#000000', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M }); }
  catch (e) { console.error('QR render error:', e); }
}
function shRender() {
  const d = SH.data; if (!d) return;
  const addr = $('#shAddr');
  if (document.activeElement !== addr && !addr.dataset.dirty) addr.value = d.public.setting === 'auto' ? '' : d.public.setting;
  $('#shAddrNow').innerHTML = `Links use <code>${esc(d.public.base)}</code> (${esc(SH_SRC[d.public.source] || d.public.source)}).` +
    (d.public.local ? ' Sentinel could not find its public IP; set the address above.' : '');
  const on = d.status.enabled, b = $('#shStBadge');
  $('#shStOn').checked = on; b.textContent = on ? 'On' : 'Off'; b.className = `badge sm ${on ? 'ok' : 'dim'}`;
  $('#shStRow').hidden = !on;
  $('#shStUrl').value = d.status.url; $('#shStOpen').href = d.status.url;
  $('#shStHelp').textContent = `${shPlural(d.status.shown, 'config')} shown${d.status.hidden ? `, ${d.status.hidden} hidden` : ''}. To hide a config, turn it off in the config's details.`;
  $('#shFeeds').innerHTML = [shCard(d.main, true), ...d.feeds.map(f => shCard(f, false))].join('') +
    (d.feeds.length ? '' : '<div class="set-help">No customer feeds yet. Use <b>New feed</b> to make a link for one customer.</div>');
  if (SH.qr) { const c = $(`.shr-feed[data-id="${CSS.escape(SH.qr)}"]`), f = shFeedById(SH.qr); if (c && f) shQr(c, f.url); else SH.qr = null; }
}
const shFeedById = id => id === 'main' ? SH.data?.main : SH.data?.feeds.find(f => f.id === id);
async function shLoad(force) {
  const r = await api('share').catch(() => null); if (!r?.ok) return;
  const d = await r.json(); SH.at = Date.now();
  const j = JSON.stringify(d); if (!force && j === SH.json) return;
  SH.json = j; SH.data = d; shRender();
}
async function shPost(ep, body, okMsg) {
  const r = await api(ep, body).catch(() => null);
  if (!r) { toast('Could not reach Sentinel', 'err'); return false; }
  if (!r.ok) { toast((await r.json().catch(() => ({}))).error || 'Could not save', 'err'); return false; }
  if (okMsg) toast(okMsg);
  await shLoad(true); return true;
}
$('#shAddr').addEventListener('input', e => { e.target.dataset.dirty = '1'; });
$('#shAddrSave').addEventListener('click', async () => {
  const el = $('#shAddr');
  if (await shPost('settings', { public_addr: el.value.trim() || 'auto' }, 'Public address saved')) { delete el.dataset.dirty; shRender(); }
});
$('#shAddr').addEventListener('keydown', e => { if (e.key === 'Enter') $('#shAddrSave').click(); });
$('#shStOn').addEventListener('change', async e => {
  const on = e.target.checked;
  if (!await shPost('settings', { status_page: on ? '1' : '0' }, on ? 'Status page is on' : 'Status page is off')) e.target.checked = !on;
  else if (S.data?.settings) S.data.settings.status_page = on ? '1' : '0';
});
$('#shStCopy').addEventListener('click', () => navigator.clipboard.writeText($('#shStUrl').value).then(() => toast('Status page link copied')));
$('#shStRotate').addEventListener('click', () => {
  if (confirm('Make a new status page link? The current link stops working.')) shPost('share/status/rotate', {}, 'New status page link made');
});
$('#shFeeds').addEventListener('click', async e => {
  const btn = e.target.closest('[data-act]'), card = e.target.closest('.shr-feed'); if (!btn || !card) return;
  const id = card.dataset.id, f = shFeedById(id); if (!f) return;
  const act = btn.dataset.act;
  if (act === 'copy') return navigator.clipboard.writeText(f.url).then(() => toast(`Link of ${f.name} copied`));
  if (act === 'qr') {
    const q = card.querySelector('.shr-qr'), open = q.hidden;
    $$('#shFeeds .shr-qr').forEach(x => { x.hidden = true; }); $$('#shFeeds [data-act="qr"]').forEach(x => x.setAttribute('aria-expanded', 'false'));
    SH.qr = open ? id : null;
    if (open) { q.hidden = false; btn.setAttribute('aria-expanded', 'true'); shQr(card, f.url); }
    return;
  }
  if (act === 'edit') return shOpen(f);
  if (act === 'rotate') {
    if (!confirm(`Make a new link for "${f.name}"? The current link stops working, and ${id === 'main' ? 'every customer using it' : 'this customer'} must add the new one.`)) return;
    return shPost('share/feed/rotate', { id }, 'New link made');
  }
  if (act === 'toggle') return shPost('share/feed/toggle', { id }, f.enabled ? `${f.name} is off` : `${f.name} is on`);
  if (act === 'delete') {
    if (!confirm(`Delete the feed "${f.name}"? Its link stops working. This cannot be undone.`)) return;
    if (SH.qr === id) SH.qr = null;
    return shPost('share/feed/delete', { id }, 'Feed deleted');
  }
});

/* Feed editor: a modal built once, used for New feed and Edit. */
function shModal() {
  let m = $('#shFeedModal'); if (m) return m;
  m = document.createElement('div'); m.id = 'shFeedModal'; m.className = 'modal-ov hidden';
  m.innerHTML = `<div class="modal-card shr-modal" role="dialog" aria-modal="true" aria-labelledby="shFmTitle">
    <div class="modal-head"><span class="modal-title" id="shFmTitle">New feed</span><button class="modal-close" type="button" data-x aria-label="Close">&times;</button></div>
    <div class="shr-form">
      <div class="field"><label class="field-lbl" for="shFmName">Name</label><input class="hashem-input" id="shFmName" maxlength="60" autocomplete="off" placeholder="For example, the customer's name"></div>
      <div class="field"><div class="field-lbl">Protocols</div><div class="sub-filter-pills" id="shFmProto"></div><div class="set-help">None selected serves every protocol.</div></div>
      <div class="field"><div class="field-lbl">Countries</div><div class="sub-filter-pills" id="shFmCc"></div><div class="set-help">None selected serves every country.</div></div>
      <div class="set-grid3">
        <div class="field"><label class="field-lbl" for="shFmSrc">Source</label><select class="hashem-select" id="shFmSrc"></select></div>
        <div class="field"><label class="field-lbl" for="shFmSort">Order</label><select class="hashem-select" id="shFmSort"></select></div>
        <div class="field"><label class="field-lbl" for="shFmMax">At most</label><div class="set-unit"><input class="hashem-input" id="shFmMax" type="number" min="0" max="1000" placeholder="All"><span>configs</span></div></div>
      </div>
    </div>
    <div class="shr-modal-foot"><button class="hashem-btn hashem-btn-secondary" type="button" data-x>Cancel</button><button class="hashem-btn hashem-btn-primary" type="button" id="shFmSave">Create feed</button></div>
  </div>`;
  document.body.appendChild(m);
  m.addEventListener('click', e => { if (e.target === m || e.target.closest('[data-x]')) shClose(); });
  m.addEventListener('click', e => { const p = e.target.closest('.sub-filter-btn'); if (p) { p.classList.toggle('active'); p.setAttribute('aria-pressed', p.classList.contains('active')); } });
  m.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); shClose(); } });
  $('#shFmSave', m).addEventListener('click', shSave);
  return m;
}
const shPills = (vals, cur, label) => vals.map(v => `<button type="button" class="sub-filter-btn${cur.includes(v) ? ' active' : ''}" data-v="${esc(v)}" aria-pressed="${cur.includes(v)}">${label(v)}</button>`).join('') || '<span class="set-help">Nothing to choose yet.</span>';
function shOpen(f) {
  const m = shModal(), o = SH.data.options;
  SH.edit = f ? f.id : null;
  $('#shFmTitle').textContent = f ? `Edit ${f.name}` : 'New feed';
  $('#shFmSave').textContent = f ? 'Save feed' : 'Create feed';
  $('#shFmName').value = f ? f.name : '';
  const protos = [...new Set([...o.protocols, ...(f?.protocols || [])])];
  $('#shFmProto').innerHTML = shPills(protos, f?.protocols || [], p => esc(p.toUpperCase()));
  const ccName = Object.fromEntries(o.countries.map(c => [c.code, `${c.flag} ${c.name || c.code}`]));
  const ccs = [...new Set([...o.countries.map(c => c.code), ...(f?.countries || [])])];
  $('#shFmCc').innerHTML = shPills(ccs, f?.countries || [], c => esc(ccName[c] || c));
  const src = f?.source || '';
  $('#shFmSrc').innerHTML = `<option value="">Any source</option><option value="manual">Added by hand</option>` +
    o.subs.map(s => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join('') +
    (src && src !== 'manual' && !o.subs.some(s => s.id === src) ? `<option value="${esc(src)}">Deleted subscription</option>` : '');
  $('#shFmSrc').value = src;
  $('#shFmSort').innerHTML = Object.entries(o.sorts).map(([k, v]) => `<option value="${esc(k)}">${esc(v)}</option>`).join('');
  $('#shFmSort').value = f?.sort || 'recent';
  $('#shFmMax').value = f?.max_items || '';
  m.classList.remove('hidden'); $('#shFmName').focus();
}
function shClose() { $('#shFeedModal')?.classList.add('hidden'); SH.edit = null; }
async function shSave() {
  const pick = sel => $$(`${sel} .sub-filter-btn.active`).map(b => b.dataset.v);
  const body = {
    name: $('#shFmName').value.trim(), protocols: pick('#shFmProto'), countries: pick('#shFmCc'),
    source: $('#shFmSrc').value, sort: $('#shFmSort').value, max_items: $('#shFmMax').value.trim() || '0',
  };
  if (!body.name) { toast('Give the feed a name', 'err'); $('#shFmName').focus(); return; }
  if (SH.edit) body.id = SH.edit;
  const btn = $('#shFmSave'); btn.disabled = true;
  try { if (await shPost('share/feed', body, SH.edit ? 'Feed saved' : 'Feed created')) shClose(); }
  finally { btn.disabled = false; }
}
$('#shNew').addEventListener('click', () => { if (SH.data) shOpen(null); else shLoad(true).then(() => SH.data && shOpen(null)); });

HOOKS.settings.push(() => shLoad(true));
HOOKS.refresh.push(() => { if (S.tab === 'settings' && Date.now() - SH.at > 20000) shLoad(); });

/* Config drawer: show or hide this config on the public status page (only while the page is on). */
HOOKS.drawer.push(c => S.data?.settings?.status_page === '1'
  ? `<label class="shr-drawer"><span><b>Show on the status page</b><span>Customers see its name, state and uptime there, never its address.</span></span><input type="checkbox" class="set-switch" id="shHide"${c.status_hidden ? '' : ' checked'}></label>`
  : '');
HOOKS.drawerBind.push(c => {
  const x = $('#shHide'); if (!x) return;
  x.onchange = async () => {
    const r = await api('share/status/hide', { id: c.id, hidden: !x.checked }).catch(() => null);
    if (r?.ok) { toast(x.checked ? 'Shown on the status page' : 'Hidden from the status page'); SH.at = 0; }
    else { x.checked = !x.checked; toast('Could not save', 'err'); }
  };
});



/* ---------- Feature: reports ---------- */
/* Weekly report switch and buttons in Settings > Notifications. The switch is saved with
   "Save notifications" by a second listener, so the shared handler stays as it is. */
(() => {
  let saving = null;
  HOOKS.settings.push(s => { if (!saving) $('#nWeekly').checked = s.weekly_report !== '0'; });
  $('#saveNotify').addEventListener('click', () => {
    saving = api('settings', { weekly_report: $('#nWeekly').checked ? '1' : '0' })
      .then(async r => { if (!r.ok) toast((await r.json()).error || 'Could not save the weekly report setting', 'err'); })
      .catch(() => {})
      .finally(() => { saving = null; });
  });
  $('#rpPreview').addEventListener('click', () => window.open(`${P}/api/report.png?t=${Date.now()}`, '_blank', 'noopener'));
  $('#rpSend').addEventListener('click', async () => {
    const btn = $('#rpSend');
    btn.disabled = true; btn.textContent = 'Sending…';
    try {
      const r = await api('report-send', {});
      if (!r.ok) { toast((await r.json()).error || 'Could not send the report', 'err'); return; }
      for (let i = 0; i < 120; i++) {
        await new Promise(res => setTimeout(res, 2000));
        const st = await getJSON('report-send');
        if (!st.running) {
          if (st.last?.ok) toast('Weekly report sent to Telegram');
          else toast(`Report not sent: ${st.last?.error || 'unknown error'}`, 'err');
          return;
        }
      }
      toast('Still sending; check Telegram in a minute');
    } catch (e) {
      toast('Could not send the report', 'err');
    } finally {
      btn.disabled = false; btn.textContent = 'Send now';
    }
  });
})();


