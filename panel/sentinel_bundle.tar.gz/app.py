#!/usr/bin/env python3
"""Sentinel: proxy health monitor (VLESS, VMess, Trojan, SS, Hysteria2, WireGuard, SOCKS) with SQLite storage and Telegram alerts."""
import base64, gzip, json, os, sys, time, hmac, hashlib, secrets, subprocess, threading, re, random, socket, sqlite3
import urllib.parse as up
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from concurrent.futures import ThreadPoolExecutor

D = os.path.dirname(os.path.abspath(__file__))
DB_FILE = D + "/sentinel.db"
XCFG = D + "/xray.json"
XBIN = D + "/xray"
CRED = D + "/credentials.txt"
STATIC_DIR = D + "/static"
INDEX_FILE = D + "/index.html"
BASE_PORT = int(os.getenv("SENTINEL_BASE_PORT", "41000"))  # first local SOCKS port

lock = threading.RLock()
wake = threading.Event()
xp = None
fails_by_ip = {}

DEF_SETTINGS = {
    "interval": "30",
    "threshold": "3",
    "timeout": "8",
    "url": "http://cp.cloudflare.com/generate_204",
    "token": "",
    "chat": "",
    "theme": "dark",
    "accent": "sky",
    "use_https": "0",
    # Telegram notifications
    "notify_down": "1",       # alert when a config goes down
    "notify_recover": "1",    # alert when it comes back
    "remind_hours": "2",      # repeat an ongoing outage every N hours (0 = never)
    "daily_backup": "1",      # send sentinel.db at 00:00 UTC
    "daily_report": "0",      # send a status summary at 00:00 UTC
    "tg_admins": "",          # Telegram user IDs allowed to control the bot
}
NOTIFY_FLAGS = ("notify_down", "notify_recover", "daily_backup", "daily_report")
SECRET_SETTINGS = {"token", "chat"}  # never sent to the browser; an empty value keeps the saved one, "-" clears it

# ---------- Extension points ----------
# Every feature lives in its own "# ---------- Feature: X ----------" block further down and
# registers itself here, so features don't edit the shared functions.
SETTING_RULES = {}     # key -> fn(value) -> str to store; raise ValueError("message") to reject
MIGRATIONS = []        # fn(conn): CREATE TABLE IF NOT EXISTS / ADD COLUMN only; runs inside init_db
TICK_HOOKS = []        # fn(settings): runs after every probe round; errors are logged, never raised
ROW_HOOKS = []         # fn(rows): adds fields to config_states() rows before their state is worked out
STATE_RULES = []       # fn(c, state) -> new state or None; can turn a built-in state into another one
API_ROUTES = {}        # "ep" -> fn(handler, method, body, qs) for signed-in API calls; return handler.out(...)
PUBLIC_ROUTES = []     # fn(handler, method, path, qs) -> True when it answered; runs before sign-in
STATE_EXTRAS = []      # fn(reply): adds keys to the dashboard reply the web panel polls
TG_ROUTES = {}         # callback prefix -> fn(args, uid, chat_id, msg_id, cb_id, show)
TG_PENDING = {}        # pending-reply kind prefix -> fn(text, uid, chat_id, pending)
TG_MAIN_ROWS = []      # extra button rows [(label, callback), ...] for the bot's main menu
TG_SETTINGS_ROWS = []  # extra button rows for the bot's settings screen
TG_CONFIG_LINES = []   # fn(c) -> list of lines for the bot's config detail
TG_CONFIG_ROWS = []    # fn(c) -> list of button rows for the bot's config detail
SELFTESTS = []         # fn(): assert-based checks run by --selftest


def run_hooks(hooks, *args):
    for h in hooks:
        try:
            h(*args)
        except Exception as e:
            print(f"hook {getattr(h, '__name__', h)} failed: {e}", flush=True)

# ---------- Database ----------
def get_db():
    conn = sqlite3.connect(DB_FILE, timeout=10, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn

db_conn = None

def init_db():
    global db_conn
    db_conn = get_db()
    with db_conn:
        db_conn.executescript("""
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS configs (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            uri TEXT NOT NULL UNIQUE,
            addr TEXT NOT NULL,
            port INTEGER NOT NULL UNIQUE,
            protocol TEXT DEFAULT 'vless',
            network TEXT DEFAULT 'tcp',
            security TEXT DEFAULT 'none',
            enabled INTEGER DEFAULT 1,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_id TEXT NOT NULL,
            ok INTEGER NOT NULL,
            latency_ms INTEGER,
            error TEXT,
            checked_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_checks_cfg_time ON checks(config_id, checked_at);
        CREATE INDEX IF NOT EXISTS idx_checks_time ON checks(checked_at);
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_id TEXT NOT NULL,
            started_at INTEGER NOT NULL,
            resolved_at INTEGER,
            last_error TEXT,
            alert_sent INTEGER DEFAULT 0,
            resolved_alert_sent INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_incidents_cfg ON incidents(config_id);
        CREATE TABLE IF NOT EXISTS subscriptions (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            url TEXT NOT NULL UNIQUE,
            interval_hours INTEGER NOT NULL DEFAULT 6,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_sync INTEGER,
            last_ok INTEGER,
            last_msg TEXT DEFAULT '',
            config_count INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pending_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        """)
        if "sub_id" not in [r[1] for r in db_conn.execute("PRAGMA table_info(configs)")]:
            db_conn.execute("ALTER TABLE configs ADD COLUMN sub_id TEXT")
        if "ok_iran" not in [r[1] for r in db_conn.execute("PRAGMA table_info(checks)")]:
            db_conn.execute("ALTER TABLE checks ADD COLUMN ok_iran INTEGER DEFAULT 1")
        cfg_cols = [r[1] for r in db_conn.execute("PRAGMA table_info(configs)")]
        if "last_speed_mbps" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN last_speed_mbps REAL")
        if "last_speed_time" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN last_speed_time INTEGER")
        inc_cols = [r[1] for r in db_conn.execute("PRAGMA table_info(incidents)")]
        if "last_reminder_at" not in inc_cols:
            db_conn.execute("ALTER TABLE incidents ADD COLUMN last_reminder_at INTEGER DEFAULT 0")
        if "country_code" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN country_code TEXT DEFAULT ''")
        if "country_name" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN country_name TEXT DEFAULT ''")
        if "muted" not in cfg_cols:
            db_conn.execute("ALTER TABLE configs ADD COLUMN muted INTEGER DEFAULT 0")
        for m in MIGRATIONS:
            m(db_conn)
        db_conn.execute('''
        CREATE TABLE IF NOT EXISTS geo_cache (
            ip TEXT PRIMARY KEY,
            country_code TEXT NOT NULL,
            country_name TEXT NOT NULL,
            updated_at INTEGER NOT NULL
        );
        ''')
        # Initialize defaults
        for k, v in DEF_SETTINGS.items():
            db_conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
        # Panel credentials
        cur = db_conn.execute("SELECT value FROM meta WHERE key='sub_token'")
        if not cur.fetchone():
            db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sub_token', ?)", (secrets.token_hex(8),))

        cur = db_conn.execute("SELECT value FROM meta WHERE key='secret'")
        if not cur.fetchone():
            pw = secrets.token_urlsafe(12)
            salt = secrets.token_hex(8)
            pwh = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100000).hex()
            secret = secrets.token_hex(32)
            path = secrets.token_hex(6)
            env_port = os.getenv("SENTINEL_PORT", "").strip()
            port = env_port if env_port.isdigit() and 1 <= int(env_port) <= 65535 else str(free_port(30000, 39999))
            for k, val in [("secret", secret), ("path", path), ("port", port), ("salt", salt), ("pw", pwh)]:
                db_conn.execute("INSERT INTO meta (key, value) VALUES (?, ?)", (k, val))
            write_credentials(pw, path, port)

def write_credentials(pw, path, port):
    # credentials.txt is what the Hashem panel reads to show URL/port/password.
    with open(CRED, "w") as f:
        f.write(f"path=/{path}/\nport={port}\npassword={pw}\n")
    os.chmod(CRED, 0o600)

def free_port(lo, hi):
    for _ in range(50):
        p = random.randint(lo, hi)
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return 39878

def get_public_ip():
    ip = get_meta("public_ip")
    if ip:
        return ip
    for p in ("https://api.ipify.org", "https://icanhazip.com", "https://ifconfig.me"):
        try:
            r = subprocess.run(["curl", "-fsSL", "--max-time", "3", p], capture_output=True, text=True)
            v = r.stdout.strip()
            if v and re.match(r"^\d{1,3}(\.\d{1,3}){3}$", v):
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('public_ip', ?)", (v,))
                return v
        except Exception:
            pass
    return "127.0.0.1"

def get_meta(k):
    with lock:
        r = db_conn.execute("SELECT value FROM meta WHERE key=?", (k,)).fetchone()
    return r["value"] if r else None

def get_settings():
    with lock:
        return {r["key"]: r["value"] for r in db_conn.execute("SELECT key, value FROM settings").fetchall()}

def hashpw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100000).hex()

# ---------- Multi-Protocol URI Parsers & Geo-IP ----------

def flag_to_cc(text):
    if not text: return None
    for i in range(len(text) - 1):
        c1, c2 = ord(text[i]), ord(text[i+1])
        if 0x1F1E6 <= c1 <= 0x1F1FF and 0x1F1E6 <= c2 <= 0x1F1FF:
            return (chr(c1 - 127397) + chr(c2 - 127397)).upper()
    return None

def country_flag(cc):
    if not cc or len(cc) != 2 or cc.upper() == "XX":
        return "🌐"
    return chr(ord(cc[0].upper()) + 127397) + chr(ord(cc[1].upper()) + 127397)

COUNTRY_NAMES = {
    "DE": "Germany", "FI": "Finland", "FR": "France", "NL": "Netherlands",
    "US": "United States", "GB": "United Kingdom", "TR": "Turkey", "IR": "Iran",
    "CA": "Canada", "SE": "Sweden", "RU": "Russia", "SG": "Singapore",
    "AE": "UAE", "PL": "Poland", "IT": "Italy", "ES": "Spain",
    "CH": "Switzerland", "AT": "Austria", "JP": "Japan", "KR": "South Korea",
    "AU": "Australia", "RO": "Romania", "UA": "Ukraine", "NO": "Norway"
}

COUNTRY_KW = {
    "germany": "DE", "deutschland": "DE", "finland": "FI", "france": "FR",
    "netherlands": "NL", "holland": "NL", "amsterdam": "NL",
    "united states": "US", "usa": "US", "america": "US",
    "united kingdom": "GB", "uk": "GB", "london": "GB", "england": "GB",
    "turkey": "TR", "turkiye": "TR", "istanbul": "TR",
    "iran": "IR", "tehran": "IR",
    "canada": "CA", "sweden": "SE", "russia": "RU", "singapore": "SG",
    "uae": "AE", "dubai": "AE", "poland": "PL", "italy": "IT",
    "spain": "ES", "switzerland": "CH", "austria": "AT",
    "japan": "JP", "tokyo": "JP", "korea": "KR", "australia": "AU"
}

def resolve_country(host, name=""):
    # 1. Flag in name
    cc = flag_to_cc(name)
    if cc:
        return cc, COUNTRY_NAMES.get(cc, cc)

    # 2. Keyword in name
    n_low = (name or "").lower()
    for kw, c in COUNTRY_KW.items():
        if kw in n_low or f"[{c.lower()}]" in n_low or f"({c.lower()})" in n_low or f" {c.lower()} " in f" {n_low} ":
            return c, COUNTRY_NAMES.get(c, c)

    # 3. Resolve IP
    ip = host
    if not re.fullmatch(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", host):
        try:
            ip = socket.gethostbyname(host)
        except Exception:
            return "XX", "Unknown"

    with lock:
        r = db_conn.execute("SELECT country_code, country_name FROM geo_cache WHERE ip=?", (ip,)).fetchone()
        if r:
            return r["country_code"], r["country_name"]

    try:
        url = f"http://ip-api.com/json/{ip}?fields=countryCode,country"
        req = urllib.request.Request(url, headers={"User-Agent": "curl/7.88"})
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            data = json.loads(resp.read().decode())
            c_code = data.get("countryCode", "XX")
            c_name = data.get("country", "Unknown")
            if c_code and c_code != "XX":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO geo_cache (ip, country_code, country_name, updated_at) VALUES (?, ?, ?, ?)",
                                   (ip, c_code, c_name, int(time.time())))
                    db_conn.commit()
                return c_code, c_name
    except Exception:
        pass

    return "XX", "Unknown"

# What the installed Xray accepts; refresh_caps() tests the binary. Newer Xray
# refuses "allowInsecure": true (one such link stopped the whole config), and
# only Xray 26.1.18+ knows Hysteria2.
CAPS = {"insecure": True, "hysteria": True}
# Certificate pins Sentinel stored for links that have none of their own (uri -> SHA-256 hex);
# filled from configs.cert_pin by Feature: diagnostics.
CERT_PINS = {}

def _truthy(v):
    return str(v or "").strip().lower() in ("1", "true", "yes")

def _tls_settings(server_name, insecure, pin="", fp="", alpn=None):
    t = {"serverName": server_name}
    pin = re.sub(r"[^0-9a-fA-F,]", "", pin or "")
    if pin:
        t["pinnedPeerCertSha256"] = pin
    elif insecure and CAPS["insecure"]:
        t["allowInsecure"] = True
    if fp: t["fingerprint"] = fp
    if alpn: t["alpn"] = alpn
    return t

def _build_stream_settings(net, sec, q, host_default):
    net = net or "tcp"
    sec = sec or "none"
    ss = {"network": net, "security": sec}
    if sec == "tls":
        ss["tlsSettings"] = _tls_settings(
            q.get("sni") or q.get("host") or host_default,
            _truthy(q.get("allowInsecure")) or _truthy(q.get("insecure")),
            q.get("pcs", ""), q.get("fp", ""),
            q["alpn"].split(",") if q.get("alpn") else None)
    elif sec == "reality":
        ss["realitySettings"] = {
            "serverName": q.get("sni", ""),
            "fingerprint": q.get("fp", "chrome"),
            "publicKey": q.get("pbk", ""),
            "shortId": q.get("sid", ""),
            "spiderX": q.get("spx", "")
        }
    elif sec != "none":
        raise ValueError("Unsupported security: " + sec)

    path = q.get("path", "/")
    h_hdr = q.get("host", "")
    if net == "ws":
        ss["wsSettings"] = {"path": path, "headers": {"Host": h_hdr} if h_hdr else {}}
    elif net == "grpc":
        ss["grpcSettings"] = {"serviceName": q.get("serviceName", ""), "multiMode": q.get("mode") == "multi"}
    elif net == "httpupgrade":
        ss["httpupgradeSettings"] = {"path": path, "host": h_hdr}
    elif net in ("xhttp", "splithttp"):
        ss["network"] = "xhttp"
        ss["xhttpSettings"] = {"path": path, "host": h_hdr, "mode": q.get("mode", "auto")}
    elif net == "tcp" and q.get("headerType") == "http":
        ss["tcpSettings"] = {"header": {"type": "http", "request": {"path": [path], "headers": {"Host": [h_hdr]}}}}
    elif net != "tcp":
        raise ValueError("Unsupported transport: " + net)

    return ss

def parse_vless(uri):
    """Backward-compatible VLESS parser returning (urlparse_obj, query_dict, name)"""
    u = up.urlparse(uri.strip())
    if u.scheme != "vless" or not u.hostname or not u.username or not u.port:
        raise ValueError("Invalid VLESS URI format")
    q = {k: v[0] for k, v in up.parse_qs(u.query).items()}
    name = up.unquote(u.fragment) or f"{u.hostname}:{u.port}"
    return u, q, name

def _split_uri(s):
    """scheme://userinfo@host:ports/?query#name -> (scheme, userinfo, hostports, q, name).
    Unlike urlparse it accepts port lists such as 443,20000-30000 (Hysteria2 port hopping)."""
    scheme, rest = s.split("://", 1)
    name = ""
    if "#" in rest:
        rest, frag = rest.split("#", 1)
        name = up.unquote(frag)
    query = ""
    if "?" in rest:
        rest, query = rest.split("?", 1)
    q = {k: v[0] for k, v in up.parse_qs(query).items()}
    # Split at "@" first: a base64 key or password may hold an unescaped "/".
    userinfo, _, hp = rest.rpartition("@")
    hp = hp.split("/", 1)[0]
    return scheme.lower(), up.unquote(userinfo), hp, q, name

def _split_hostport(hp, default_port):
    """host:port, [v6]:port or host:443,20000-30000 -> (host, first port)."""
    hp = hp.strip()
    if hp.startswith("["):
        host, _, rest = hp[1:].partition("]")
        ports = rest[1:] if rest.startswith(":") else ""
    elif hp.count(":") == 1:
        host, ports = hp.split(":")
    else:
        host, ports = hp, ""
    m = re.match(r"\d+", ports)
    port = int(m.group()) if m else default_port
    if not host or not 0 < port < 65536:
        raise ValueError("Invalid host or port")
    return host, port

def _addr(host, port):
    return f"[{host}]:{port}" if ":" in host else f"{host}:{port}"

def _b64key(v):
    # parse_qs turns an unescaped "+" of a base64 key into a space.
    return (v or "").strip().replace(" ", "+")

# Schemes Xray cannot carry; they need a sing-box engine.
NEEDS_SINGBOX = ("tuic", "hysteria", "anytls", "naive+https", "naive+quic", "ssh", "shadowtls")

def parse_proxy_uri(uri):
    s = uri.strip()
    if s.startswith(("hysteria2://", "hy2://")):
        _, auth, hp, q, name = _split_uri(s)
        host, port = _split_hostport(hp, 443)
        obfs = q.get("obfs", "")
        if obfs and obfs != "salamander":
            raise ValueError("Unsupported Hysteria2 obfs: " + obfs)
        if obfs and not q.get("obfs-password"):
            raise ValueError("Hysteria2 salamander obfs needs obfs-password")
        return {
            "protocol": "hysteria2", "name": name or _addr(host, port), "addr": _addr(host, port),
            "host": host, "port": port, "password": auth,
            "network": "quic", "security": "tls", "q": q
        }
    if s.startswith(("wireguard://", "wg://")):
        _, key, hp, q, name = _split_uri(s)
        host, port = _split_hostport(hp, 51820)
        secret = _b64key(key or q.get("privatekey") or q.get("secretkey"))
        pub = _b64key(q.get("publickey") or q.get("peer"))
        address = [a.strip() for a in (q.get("address") or q.get("ip") or "").split(",") if a.strip()]
        if not secret or not pub:
            raise ValueError("WireGuard link needs the private key and the peer's publickey")
        if not address:
            raise ValueError("WireGuard link needs address= (the interface IP, e.g. 172.16.0.2/32)")
        return {
            "protocol": "wireguard", "name": name or _addr(host, port), "addr": _addr(host, port),
            "host": host, "port": port, "secret": secret, "pub": pub, "address": address,
            "network": "udp", "security": "none", "q": q
        }
    if s.startswith(("socks://", "socks5://")):
        _, ui, hp, q, name = _split_uri(s)
        host, port = _split_hostport(hp, 1080)
        if ui and ":" not in ui:
            try:
                ui = base64.b64decode(ui + "=" * (-len(ui) % 4), altchars=b"-_").decode("utf-8")
            except Exception:
                pass
        user, _, pw = ui.partition(":")
        return {
            "protocol": "socks", "name": name or _addr(host, port), "addr": _addr(host, port),
            "host": host, "port": port, "user": user, "pass": pw,
            "network": "tcp", "security": "none", "q": q
        }
    if needs_singbox_parser(s):
        return parse_singbox_uri(s)  # Feature: engines (tuic, hysteria, anytls, naive, ssh, ss over ShadowTLS)
    if s.startswith("vless://"):
        u, q, name = parse_vless(s)
        return {
            "protocol": "vless", "name": name, "addr": f"{u.hostname}:{u.port}",
            "host": u.hostname, "port": u.port, "uuid": u.username,
            "network": q.get("type", "tcp"), "security": q.get("security", "none"), "q": q
        }
    elif s.startswith("trojan://"):
        u = up.urlparse(s)
        if not u.hostname or not u.username or not u.port:
            raise ValueError("Invalid Trojan URI format")
        q = {k: v[0] for k, v in up.parse_qs(u.query).items()}
        name = up.unquote(u.fragment) or f"{u.hostname}:{u.port}"
        return {
            "protocol": "trojan", "name": name, "addr": f"{u.hostname}:{u.port}",
            "host": u.hostname, "port": u.port, "password": u.username,
            "network": q.get("type", "tcp"), "security": q.get("security", "tls"), "q": q
        }
    elif s.startswith("ss://"):
        raw = s[5:]
        name = ""
        if "#" in raw: raw, frag = raw.split("#", 1); name = up.unquote(frag)
        q = {}
        if "?" in raw: raw, qs = raw.split("?", 1); q = {k: v[0] for k, v in up.parse_qs(qs).items()}
        if "@" in raw:
            uinfo, hport = raw.split("@", 1)
            try:
                dec = base64.b64decode(uinfo + "=" * (-len(uinfo) % 4), altchars=b"-_").decode("utf-8")
                method, password = dec.split(":", 1) if ":" in dec else uinfo.split(":", 1)
            except Exception:
                method, password = uinfo.split(":", 1)
            host, port_s = hport.rsplit(":", 1)
            port = int(port_s)
        else:
            dec = base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8")
            uinfo, hport = dec.split("@", 1)
            method, password = uinfo.split(":", 1)
            host, port_s = hport.rsplit(":", 1)
            port = int(port_s)
        return {
            "protocol": "shadowsocks", "name": name or f"{host}:{port}",
            "addr": f"{host}:{port}", "host": host, "port": port,
            "method": method, "password": password, "network": "tcp", "security": "none", "q": q
        }
    elif s.startswith("vmess://"):
        raw = s[8:]
        data = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8"))
        host = data.get("add", "")
        port = int(data.get("port", 443))
        q = {
            "host": data.get("host", ""),
            "path": data.get("path", "/"),
            "sni": data.get("sni") or data.get("host") or host,
            "alpn": data.get("alpn", ""),
            "type": data.get("type", "none")
        }
        return {
            "protocol": "vmess", "name": data.get("ps") or f"{host}:{port}",
            "addr": f"{host}:{port}", "host": host, "port": port,
            "uuid": data.get("id", ""), "aid": int(data.get("aid", 0) or 0),
            "scy": data.get("scy", "auto") or "auto", "network": data.get("net", "tcp") or "tcp",
            "security": data.get("tls", "none") or "none", "q": q
        }
    raise ValueError(f"Unsupported URI scheme: {s.split('://')[0] if '://' in s else s[:15]}")

def outbound_for(c):
    info = parse_proxy_uri(c["uri"])
    proto = info["protocol"]
    q = info.get("q", {})
    if proto in SB_PROTOCOLS:
        return singbox_outbounds(c, info)[0]  # Feature: engines: these run in sing-box
    if proto in ("vless", "trojan", "vmess") and not q.get("pcs") and CERT_PINS.get(c.get("uri")):
        q["pcs"] = CERT_PINS[c["uri"]]  # a pin Sentinel stored for an insecure=1 link (Feature: diagnostics)

    if proto == "vless":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        user = {"id": info["uuid"], "encryption": q.get("encryption", "none")}
        if q.get("flow"): user["flow"] = q["flow"]
        return {
            "tag": "o_" + c["id"],
            "protocol": "vless",
            "settings": {"vnext": [{"address": info["host"], "port": info["port"], "users": [user]}]},
            "streamSettings": ss
        }
    elif proto == "trojan":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        return {
            "tag": "o_" + c["id"],
            "protocol": "trojan",
            "settings": {"servers": [{"address": info["host"], "port": info["port"], "password": info["password"]}]},
            "streamSettings": ss
        }
    elif proto == "shadowsocks":
        return {
            "tag": "o_" + c["id"],
            "protocol": "shadowsocks",
            "settings": {"servers": [{
                "address": info["host"],
                "port": info["port"],
                "method": info["method"],
                "password": info["password"],
                "uot": True
            }]}
        }
    elif proto == "vmess":
        ss = _build_stream_settings(info["network"], info["security"], q, info["host"])
        return {
            "tag": "o_" + c["id"],
            "protocol": "vmess",
            "settings": {"vnext": [{
                "address": info["host"],
                "port": info["port"],
                "users": [{"id": info["uuid"], "alterId": info["aid"], "security": info["scy"]}]
            }]},
            "streamSettings": ss
        }
    elif proto == "hysteria2":
        # Xray splits Hysteria2: the server in settings, auth in hysteriaSettings,
        # salamander in finalmask. Probing uses the first port of a hopping range.
        ss = {
            "network": "hysteria", "security": "tls",
            "tlsSettings": _tls_settings(q.get("sni") or info["host"], _truthy(q.get("insecure")),
                                         q.get("pinSHA256", ""), alpn=["h3"]),
            "hysteriaSettings": {"version": 2, "auth": info["password"]}
        }
        if q.get("obfs") == "salamander":
            ss["finalmask"] = {"udp": [{"type": "salamander", "settings": {"password": q.get("obfs-password", "")}}]}
        return {
            "tag": "o_" + c["id"],
            "protocol": "hysteria",
            "settings": {"version": 2, "address": info["host"], "port": info["port"]},
            "streamSettings": ss
        }
    elif proto == "wireguard":
        peer = {"publicKey": info["pub"], "endpoint": _addr(info["host"], info["port"]),
                "allowedIPs": ["0.0.0.0/0", "::/0"]}
        psk = _b64key(q.get("presharedkey") or q.get("psk"))
        if psk: peer["preSharedKey"] = psk
        st = {"secretKey": info["secret"], "address": info["address"], "peers": [peer]}
        if (q.get("mtu") or "").isdigit(): st["mtu"] = int(q["mtu"])
        reserved = [int(x) for x in re.findall(r"\d+", q.get("reserved", ""))]
        if len(reserved) == 3: st["reserved"] = reserved
        return {"tag": "o_" + c["id"], "protocol": "wireguard", "settings": st}
    elif proto == "socks":
        srv = {"address": info["host"], "port": info["port"]}
        if info["user"]: srv["users"] = [{"user": info["user"], "pass": info["pass"]}]
        return {"tag": "o_" + c["id"], "protocol": "socks", "settings": {"servers": [srv]}}
    raise ValueError(f"Unsupported protocol: {proto}")

def gen_xray_config(configs):
    configs = [c for c in configs if engine_of(c) == "xray"]  # Feature: engines: the rest run in sing-box
    inbounds = [{
        "tag": "i_" + c["id"],
        "listen": "127.0.0.1",
        "port": c["port"],
        "protocol": "socks",
        "settings": {"udp": False}
    } for c in configs]
    outbounds = [outbound_for(c) for c in configs]
    rules = [{
        "type": "field",
        "inboundTag": ["i_" + c["id"]],
        "outboundTag": "o_" + c["id"]
    } for c in configs]
    return {
        "log": {"loglevel": "warning"},
        "inbounds": inbounds,
        "outbounds": outbounds,
        "routing": {"rules": rules}
    }

# Configs Xray refused, by id: tick() reports this error instead of probing.
config_errors = {}
# (uri, xray mtime) -> error or "" so a refused link is not re-tested on every restart.
_cfg_test_cache = {}
_caps_mtime = None

def xray_test(cfg):
    """Ask Xray to validate cfg without starting it: (ok, error)."""
    # Xray picks the format from the extension, so the name must end in .json.
    path = f"{XCFG[:-5]}.test.{threading.get_ident()}.json"
    try:
        with open(path, "w") as f:
            json.dump(cfg, f)
        r = subprocess.run([XBIN, "run", "-test", "-c", path], capture_output=True, text=True, timeout=30)
    except Exception as e:
        return True, str(e)  # cannot tell: let the real start decide
    finally:
        try: os.remove(path)
        except OSError: pass
    if r.returncode == 0:
        return True, ""
    lines = [l for l in (r.stdout + "\n" + r.stderr).splitlines() if l.strip()]
    msg = next((l for l in reversed(lines) if "rror" in l or "fail" in l), lines[-1] if lines else "invalid config")
    # Xray chains causes with " > "; the last one is the actual reason.
    return False, msg.strip().split(" > ")[-1][:200]

def refresh_caps():
    """Learn which features the installed Xray accepts (once per binary)."""
    global _caps_mtime
    mt = os.path.getmtime(XBIN)
    if mt == _caps_mtime:
        return
    _caps_mtime = mt
    base = {"tag": "o_t", "protocol": "vless",
            "settings": {"vnext": [{"address": "127.0.0.1", "port": 443, "users": [{"id": "11111111-1111-1111-1111-111111111111", "encryption": "none"}]}]},
            "streamSettings": {"network": "tcp", "security": "tls", "tlsSettings": {"serverName": "a.example", "allowInsecure": True}}}
    hy = {"tag": "o_t", "protocol": "hysteria", "settings": {"version": 2, "address": "127.0.0.1", "port": 443},
          "streamSettings": {"network": "hysteria", "security": "tls", "tlsSettings": {"serverName": "a.example", "alpn": ["h3"]},
                             "hysteriaSettings": {"version": 2, "auth": "t"}}}
    for key, ob in (("insecure", base), ("hysteria", hy)):
        CAPS[key] = xray_test({"log": {"loglevel": "none"}, "outbounds": [ob]})[0]

def insecure_dropped(uri):
    """True when the link asks to skip certificate checks, has no pinned hash,
    and the installed Xray refuses allowInsecure: a failure is then most likely
    the certificate, which curl only reports as a proxy error."""
    if CAPS["insecure"] or CERT_PINS.get(uri) or engine_of({"uri": uri}) != "xray":  # engines: sing-box honours insecure
        return False
    try:
        q = parse_proxy_uri(uri).get("q", {})
    except Exception:
        return False
    return (_truthy(q.get("allowInsecure")) or _truthy(q.get("insecure"))) and not (q.get("pcs") or q.get("pinSHA256"))

def _restart_xray():  # restart_xray() (Feature: engines) runs this, then sing-box
    global xp, config_errors
    with lock:
        if xp and xp.poll() is None:
            xp.terminate()
            try: xp.wait(4)
            except Exception: xp.kill()
        xp = None
        cur = db_conn.execute("SELECT id, uri, port FROM configs WHERE enabled=1")
        configs = [dict(r) for r in cur.fetchall()]
        if not configs or not os.path.exists(XBIN):
            config_errors = {}
            return
        refresh_caps()
        good, errs = [], {}
        configs = [c for c in configs if engine_of(c) == "xray"]  # Feature: engines
        for c in configs:
            try:
                outbound_for(c)
                good.append(c)
            except Exception as e:
                errs[c["id"]] = str(e)[:200]
        # One link Xray refuses must not stop the checks of all the others:
        # validate, and if that fails find the culprits and leave them out.
        if good and not xray_test(gen_xray_config(good))[0]:
            mt = os.path.getmtime(XBIN)
            def one(c):
                k = (c["uri"], mt)
                if k not in _cfg_test_cache:
                    ok, msg = xray_test(gen_xray_config([c]))
                    _cfg_test_cache[k] = "" if ok else (msg or "rejected by Xray")
                return c, _cfg_test_cache[k]
            with ThreadPoolExecutor(max_workers=8) as ex:
                results = list(ex.map(one, good))
            good = [c for c, e in results if not e]
            for c, e in results:
                if e:
                    if c["uri"].startswith(("hysteria2://", "hy2://")) and not CAPS["hysteria"]:
                        e = f"Hysteria2 needs Xray 26.1.18 or newer ({e})"
                    errs[c["id"]] = "Xray rejected this config: " + e
        config_errors = errs
        if not good:
            return
        cfg = gen_xray_config(good)
        with open(XCFG, "w") as f:
            json.dump(cfg, f, indent=2)
        xp = subprocess.Popen([XBIN, "run", "-c", XCFG], stdout=open(D + "/xray.log", "ab"), stderr=subprocess.STDOUT)
    time.sleep(0.8)

# ---------- Health Checking ----------
def probe_one(c, timeout, intl_url, iran_url="https://aparat.com"):
    # Probe 1: International endpoint
    cmd1 = ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code} %{time_total}",
            "-x", f"socks5h://127.0.0.1:{c['port']}", "--max-time", str(timeout), intl_url]
    r1 = subprocess.run(cmd1, capture_output=True, text=True)
    out1 = r1.stdout.split()
    ok_intl, ms_intl, err_intl = False, None, ""
    if r1.returncode == 0 and out1 and out1[0][0] in "23":
        ok_intl = True
        ms_intl = int(float(out1[1]) * 1000)
    else:
        err_intl = (r1.stderr.strip() or ("HTTP " + (out1[0] if out1 else "none")))[:180]

    # Probe 2: Domestic Iran endpoint to detect National Intranet (ملی شدن)
    ok_iran = 0
    try:
        cmd2 = ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}",
                "-x", f"socks5h://127.0.0.1:{c['port']}", "--max-time", "4", iran_url]
        r2 = subprocess.run(cmd2, capture_output=True, text=True, timeout=5)
        code2 = r2.stdout.strip()
        if r2.returncode == 0 and code2 and code2[0] in "23":
            ok_iran = 1
    except Exception:
        ok_iran = 0

    return c["id"], ok_intl, ms_intl, err_intl, ok_iran

tg_rr_idx = 0

def send_telegram(text, reply_markup=None, record_trace=False):
    global tg_rr_idx
    s = get_settings()
    tok, chat = s.get("token", ""), s.get("chat", "")
    if not tok or not chat:
        return (False, None, [{"error": "token or chat_id missing"}]) if record_trace else False
    
    post_params = {"chat_id": chat, "text": text, "parse_mode": "HTML", "disable_web_page_preview": "true"}
    if reply_markup:
        post_params["reply_markup"] = json.dumps(reply_markup) if isinstance(reply_markup, dict) else str(reply_markup)
    body = up.urlencode(post_params)
    cfg = f'url = "https://api.telegram.org/bot{tok}/sendMessage"\ndata = "{body}"\n'

    with lock:
        # Most recent probe for each enabled config
        rows = db_conn.execute("""
            SELECT c.id, c.name, c.addr, c.port, s.name as sub_name FROM configs c
            LEFT JOIN subscriptions s ON s.id = c.sub_id
            JOIN (
                SELECT config_id, ok, MAX(checked_at) AS last_t
                FROM checks GROUP BY config_id
            ) ch ON ch.config_id = c.id
            WHERE c.enabled=1 AND ch.ok=1
            ORDER BY c.id ASC
        """).fetchall()
        healthy = [dict(r) for r in rows]

    attempts = []
    delivered = False
    used_cfg = None

    if healthy:
        # Round-robin starting point
        n = len(healthy)
        with lock:
            start = tg_rr_idx % n
        ordered = healthy[start:] + healthy[:start]

        for c in ordered:
            t0 = time.time()
            cmd = ["curl", "-sS", "--max-time", "12", "-K", "-", "-x", f"socks5h://127.0.0.1:{c['port']}"]
            try:
                r = subprocess.run(cmd, input=cfg, capture_output=True, text=True, timeout=15)
                ms = int((time.time() - t0) * 1000)
                if '"ok":true' in r.stdout:
                    delivered = True
                    used_cfg = c
                    with lock:
                        tg_rr_idx = (tg_rr_idx + 1) % 1000000
                    attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": True, "ms": ms})
                    break
                else:
                    err = (r.stderr.strip() or r.stdout.strip() or "rejected")[:120]
                    attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": False, "ms": ms, "error": err})
            except Exception as ex:
                attempts.append({"node": c["name"], "port": c["port"], "addr": c["addr"], "sub_name": c.get("sub_name"), "ok": False, "error": str(ex)[:120]})

    if not delivered:
        t0 = time.time()
        cmd = ["curl", "-sS", "--max-time", "10", "-K", "-"]
        try:
            r = subprocess.run(cmd, input=cfg, capture_output=True, text=True, timeout=12)
            ms = int((time.time() - t0) * 1000)
            if '"ok":true' in r.stdout:
                delivered = True
                used_cfg = {"name": "Host Direct", "addr": "Direct", "port": 0}
                attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": True, "ms": ms})
            else:
                err = (r.stderr.strip() or r.stdout.strip() or "failed")[:120]
                attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": False, "ms": ms, "error": err})
        except Exception as ex:
            attempts.append({"node": "Host Direct", "port": 0, "addr": "Direct", "ok": False, "error": str(ex)[:120]})

    if record_trace:
        return delivered, used_cfg, attempts
    return delivered


# ---------- Telegram Bot (2-Way Commands & Backups) ----------
# ---------- TOTP (RFC 6238) ----------
def generate_totp_secret():
    # 16-char base32 string (80 bits)
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    return "".join(secrets.choice(chars) for _ in range(16))

def totp_code(secret_b32, t=None):
    if t is None: t = time.time()
    counter = int(t // 30)
    key = base64.b32decode(secret_b32, casefold=True)
    msg = counter.to_bytes(8, "big")
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = int.from_bytes(h[offset:offset+4], "big") & 0x7FFFFFFF
    return f"{code % 1000000:06d}"

def verify_totp(secret_b32, code_str):
    code_str = str(code_str).strip()
    if len(code_str) != 6 or not code_str.isdigit():
        return False
    now = time.time()
    for delta in (-30, 0, 30):
        try:
            if totp_code(secret_b32, now + delta) == code_str:
                return True
        except Exception:
            pass
    return False

# ---------- SP-Test (Speed Test 100MB) ----------
speed_gate = threading.Lock()  # one download at a time: manual, "test all" and scheduled tests

def run_speed_test(cid, size_mb=100, source="manual"):
    """Download size_mb through the config. source "scheduled" means the caller already holds speed_gate."""
    with lock:
        c = db_conn.execute("SELECT id, name, uri, port FROM configs WHERE id=?", (cid,)).fetchone()
    if not c:
        return {"error": "config not found"}
    if engine_missing(c):  # Feature: engines: nothing listens on its port
        return {"ok": False, "error": sb_reason(engine_missing(c))}
    if source != "scheduled" and not speed_gate.acquire(timeout=90):
        return {"ok": False, "error": "Another speed test is running; try again in a minute"}
    try:
        return _speed_download(cid, c["port"], int(size_mb), source)
    finally:
        if source != "scheduled":
            speed_gate.release()

def _speed_download(cid, port, size_mb, source):
    url = f"https://speed.cloudflare.com/__down?bytes={size_mb * 1048576}"
    cmd = [
        "curl", "-sS", "-o", "/dev/null",
        "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "-H", "Referer: https://speed.cloudflare.com/",
        "-H", "Origin: https://speed.cloudflare.com",
        "-w", "%{http_code} %{speed_download} %{time_total} %{size_download}",
        "--max-time", "25",
        "-x", f"socks5h://127.0.0.1:{port}",
        url
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        parts = r.stdout.strip().split()
        if len(parts) >= 4 and parts[0] == "200":
            bps = float(parts[1])
            mbps = round((bps * 8) / 1000000, 1)
            now = int(time.time())
            with lock:
                db_conn.execute("UPDATE configs SET last_speed_mbps=?, last_speed_time=? WHERE id=?", (mbps, now, cid))
                db_conn.execute("INSERT INTO speed_tests (config_id, mbps, bytes, tested_at, source) VALUES (?, ?, ?, ?, ?)",
                                (cid, mbps, int(float(parts[3])), now, "scheduled" if source == "scheduled" else "manual"))
                db_conn.commit()
            return {"ok": True, "mbps": mbps, "time": now, "elapsed": round(float(parts[2]), 2)}
        err = r.stderr.strip() or f"HTTP {parts[0] if parts else 'fail'}"
        return {"ok": False, "error": err[:150]}
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:150]}

sp_testing_all = False

def run_speed_test_all_worker():
    global sp_testing_all
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT c.id FROM configs c
            JOIN (SELECT config_id, ok, MAX(checked_at) FROM checks GROUP BY config_id) ch ON ch.config_id=c.id
            WHERE c.enabled=1 AND ch.ok=1
        """).fetchall()]
    for r in rows:
        run_speed_test(r["id"])
        time.sleep(1)
    sp_testing_all = False

# ---------- Telegram bot: the whole panel from a chat ----------
# Every screen is one message that is edited in place as the admin taps its
# buttons. Text the bot asks for (a new name, a URL, a number) is the admin's
# next message. Links pasted at any time are imported.
import html as _html

H = lambda v: _html.escape(str(v if v is not None else ""), quote=False)
STATE_ICON = {"up": "🟢", "slow": "🐢", "down": "🔴", "iran_only": "🟡", "fail": "🟠", "no_engine": "🧩", "new": "⚪", "paused": "⏸"}
STATE_FA = {"up": "سالم", "slow": "کند", "down": "قطع", "iran_only": "فقط اینترنت ملی", "fail": "خطا در آخرین تست",
            "no_engine": "نیاز به sing-box", "new": "در انتظار تست", "paused": "متوقف"}
PAGE = 8
TG_BASE = "https://api.telegram.org"
tg_pending = {}            # user id -> what their next message answers
tg_pending_lock = threading.Lock()
tg_commands_set_for = None  # token setMyCommands ran for

def _curl_q(v):
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "").replace("\t", "\\t") + '"'

def tg_proxy_ports(limit=3):
    with lock:
        return [r["port"] for r in db_conn.execute("""
            SELECT c.port FROM configs c JOIN checks ch ON ch.config_id = c.id
            WHERE c.enabled=1 AND ch.ok=1 GROUP BY c.id ORDER BY MAX(ch.checked_at) DESC LIMIT ?""", (limit,)).fetchall()]

def tg_api(method, params=None, doc=None, timeout=25, token=None):
    """Call the Bot API through a healthy config, then directly. Returns the
    decoded reply, or None when nothing got through. The token travels on
    stdin (curl -K) so it never shows in the process list. doc = (path, filename[, field]);
    field is the upload's form name, "document" unless given (e.g. "photo" for sendPhoto)."""
    tok = token or get_settings().get("token", "")
    if not tok:
        return None
    lines = [f"url = {_curl_q(f'{TG_BASE}/bot{tok}/{method}')}"]
    for k, v in (params or {}).items():
        if v is None:
            continue
        if isinstance(v, (dict, list)):
            v = json.dumps(v, ensure_ascii=False)
        lines.append(f"form-string = {_curl_q(f'{k}={v}')}")
    if doc:
        lines.append(f"form = {_curl_q((doc[2] if len(doc) > 2 else 'document') + '=@' + doc[0] + ';filename=' + doc[1])}")
    cfg = "\n".join(lines) + "\n"
    for p in tg_proxy_ports() + [None]:
        cmd = ["curl", "-sS", "--max-time", str(timeout), "-K", "-"] + (["-x", f"socks5h://127.0.0.1:{p}"] if p else [])
        try:
            r = subprocess.run(cmd, input=cfg, capture_output=True, text=True, timeout=timeout + 5)
            res = json.loads(r.stdout)
            if res.get("ok") or res.get("error_code") in (400, 403):
                return res  # Telegram answered; a 400 will not get better on another route
        except Exception:
            pass
    return None

def kb(*rows):
    return {"inline_keyboard": [[{"text": t, "callback_data": d} for t, d in row] for row in rows if row]}

BACK = ("« منو", "m")

def tg_is_admin(uid, chat_id, s=None):
    """Admins listed in settings; with none listed, only the private chat set as Chat ID."""
    s = s or get_settings()
    admins = [x for x in s.get("tg_admins", "").split(",") if x]
    if admins:
        return str(uid) in admins
    chat = s.get("chat", "").strip()
    return bool(chat) and str(chat_id) == chat and str(uid) == chat

# ----- screens: each returns (text, keyboard) -----
def scr_main():
    cs = config_states()
    n = {k: sum(1 for c in cs if c["state"] == k) for k in STATE_ICON}
    lats = [c["latency"] for c in cs if c["state"] in ("up", "slow") and c["latency"]]
    avg = f"{round(sum(lats) / len(lats))}ms" if lats else "—"
    with lock:
        subs = db_conn.execute("SELECT COUNT(*) AS n FROM subscriptions").fetchone()["n"]
    problems = n["down"] + n["iran_only"] + n["fail"]
    text = (f"🛡️ <b>Sentinel</b>\n\n"
            f"🟢 سالم: <b>{n['up']}</b>   🔴 قطع: <b>{n['down']}</b>" + (f"   🐢 کند: <b>{n['slow']}</b>" if n["slow"] else "") + (f"   🟡 ملی: <b>{n['iran_only']}</b>" if n["iran_only"] else "") +
            (f"   🟠 خطا: <b>{n['fail']}</b>" if n["fail"] else "") + "\n"
            f"⏸ متوقف: {n['paused']}   📦 کل: {len(cs)}   🔗 ساب: {subs}\n"
            f"⚡ میانگین پینگ: <b>{avg}</b>")
    return text, kb(
        [("📋 کانفیگ‌ها", "cl:0:a"), (f"🔴 مشکل‌دارها ({problems})", "cl:0:d")],
        [("➕ افزودن کانفیگ", "add"), ("🔗 ساب‌ها", "sb")],
        [("⚡ تست سرعت", "sp"), ("📜 قطعی‌ها", "inc")],
        [("📡 ساب تمیز", "fd"), ("🔄 تست همه الان", "ck")],
        [("⚙️ تنظیمات", "set"), ("🔔 اعلان‌ها", "nt")],
        *TG_MAIN_ROWS,
        [("📦 بک‌آپ", "bk"), ("🔄 تازه‌سازی", "m")])

def scr_configs(page=0, flt="a"):
    cs = config_states()
    if flt == "d":
        cs = [c for c in cs if c["state"] in ("down", "iran_only", "fail")]
    elif flt == "p":
        cs = [c for c in cs if c["state"] == "paused"]
    pages = max(1, (len(cs) + PAGE - 1) // PAGE)
    page = min(max(0, page), pages - 1)
    title = {"a": "همه کانفیگ‌ها", "d": "کانفیگ‌های مشکل‌دار", "p": "کانفیگ‌های متوقف"}[flt]
    text = f"📋 <b>{title}</b> ({len(cs)})" + (f" — صفحه {page + 1} از {pages}" if pages > 1 else "")
    if not cs:
        text += "\n\n" + ("همه کانفیگ‌ها سالم‌اند ✅" if flt == "d" else "چیزی نیست.")
    rows = []
    for c in cs[page * PAGE:(page + 1) * PAGE]:
        extra = f" · {c['latency']}ms" if c["state"] in ("up", "slow") and c["latency"] else ""
        rows.append([(f"{STATE_ICON[c['state']]} {c['name'][:40]}{extra}", f"c:{c['id']}")])
    nav = []
    if page > 0:
        nav.append(("◀ قبلی", f"cl:{page - 1}:{flt}"))
    if page < pages - 1:
        nav.append(("بعدی ▶", f"cl:{page + 1}:{flt}"))
    rows.append(nav)
    rows.append([(("• " if flt == k else "") + lbl, f"cl:0:{k}") for k, lbl in (("a", "همه"), ("d", "مشکل‌دار"), ("p", "متوقف"))])
    rows.append([("➕ افزودن", "add"), BACK])
    return text, kb(*rows)

def scr_config(cid):
    c = next((x for x in config_states() if x["id"] == cid), None)
    if not c:
        return "این کانفیگ دیگر وجود ندارد.", kb([("« کانفیگ‌ها", "cl:0:a")])
    since = int(time.time()) - 86400
    with lock:
        st = db_conn.execute("SELECT COUNT(*) AS n, SUM(ok) AS up, AVG(CASE WHEN ok=1 THEN latency_ms END) AS avg FROM checks WHERE config_id=? AND checked_at>=?", (cid, since)).fetchone()
        incs = db_conn.execute("SELECT COUNT(*) AS n FROM incidents WHERE config_id=? AND started_at>=?", (cid, int(time.time()) - 7 * 86400)).fetchone()["n"]
    up24 = f"{round(100.0 * (st['up'] or 0) / st['n'], 1)}%" if st["n"] else "—"
    lines = [f"{STATE_ICON[c['state']]} <b>{H(c['name'])}</b>",
             f"<code>{H(c['addr'])}</code>",
             f"{H((c['protocol'] or 'vless').upper())} · {H(c['network'])}" + (f" · {H(c['security'])}" if c["security"] and c["security"] != "none" else ""),
             "",
             f"وضعیت: <b>{STATE_FA[c['state']]}</b>" + (f" ({format_dur(int(time.time()) - c['down_since'])})" if c["down_since"] else ""),
             f"پینگ: <b>{c['latency']}ms</b>" if c["latency"] and c["state"] in ("up", "slow") else "پینگ: —",
             f"آپتایم ۲۴ ساعت: <b>{up24}</b>" + (f" · میانگین {round(st['avg'])}ms" if st["avg"] else ""),
             f"سرعت: <b>{c['last_speed_mbps']} Mbps</b>" if c["last_speed_mbps"] else "سرعت: تست نشده",
             f"قطعی‌های ۷ روز: {incs}",
             f"منبع: {H(c['sub_name']) if c['sub_name'] else 'دستی'}"]
    if c["muted"]:
        lines.append("🔕 اعلان‌های این کانفیگ خاموش است")
    for f in TG_CONFIG_LINES:
        lines += f(c)
    if c["last_error"] and c["state"] in ("down", "iran_only", "fail"):
        lines += ["", f"⚠️ {H(human_err(c['last_error']))}", f"<code>{H(c['last_error'][:200])}</code>"]
    return "\n".join(lines), kb(
        [("⚡ تست سرعت", f"ca:sp:{cid}"), ("🔄 تست اتصال", f"ca:pr:{cid}")],
        [("▶ ادامه" if not c["enabled"] else "⏸ توقف", f"ca:tg:{cid}"), ("🔔 روشن کردن اعلان" if c["muted"] else "🔕 بی‌صدا", f"ca:mu:{cid}")],
        [("✏️ تغییر نام", f"ca:rn:{cid}"), ("🔗 لینک کانفیگ", f"ca:ln:{cid}")],
        *[row for f in TG_CONFIG_ROWS for row in f(c)],
        [("🗑 حذف", f"cx:{cid}"), ("« کانفیگ‌ها", "cl:0:a")])

def scr_subs():
    with lock:
        subs = [dict(r) for r in db_conn.execute("SELECT * FROM subscriptions ORDER BY created_at DESC")]
    text = "🔗 <b>ساب‌ها</b>\n\nلینک ساب‌هایی که Sentinel کانفیگ‌هایشان را خودکار می‌گیرد." if subs else "🔗 <b>ساب‌ها</b>\n\nهنوز ساب اضافه نشده."
    rows = [[(f"{'🟢' if s['enabled'] and s['last_ok'] else '⏸' if not s['enabled'] else '🔴'} {s['name'][:36]} ({s['config_count'] or 0})", f"s:{s['id']}")] for s in subs]
    rows += [[("➕ افزودن ساب", "sadd")], [BACK]]
    return text, kb(*rows)

def scr_sub(sid):
    with lock:
        s = db_conn.execute("SELECT * FROM subscriptions WHERE id=?", (sid,)).fetchone()
    if not s:
        return "این ساب دیگر وجود ندارد.", kb([("« ساب‌ها", "sb")])
    s = dict(s)
    text = (f"🔗 <b>{H(s['name'])}</b>\n<code>{H(s['url'][:300])}</code>\n\n"
            f"وضعیت: {'فعال' if s['enabled'] else 'غیرفعال'} · هر {s['interval_hours']} ساعت\n"
            f"کانفیگ‌ها: <b>{s['config_count'] or 0}</b>\n"
            f"آخرین همگام‌سازی: {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(s['last_sync'])) if s['last_sync'] else '—'}\n"
            f"نتیجه: {H(s['last_msg'] or '—')}")
    return text, kb(
        [("🔄 همگام‌سازی الان", f"sa:sy:{sid}"), ("⏸ غیرفعال" if s["enabled"] else "▶ فعال", f"sa:en:{sid}")],
        [(("• " if s["interval_hours"] == h else "") + f"{h}h", f"sa:i{h}:{sid}") for h in (1, 6, 12, 24)],
        [("🗑 حذف", f"sx:{sid}"), ("« ساب‌ها", "sb")])

def scr_incidents():
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT i.*, c.name FROM incidents i JOIN configs c ON c.id=i.config_id
            ORDER BY (i.resolved_at IS NULL) DESC, i.started_at DESC LIMIT 12""")]
    if not rows:
        return "📜 <b>قطعی‌ها</b>\n\nهیچ قطعی‌ای ثبت نشده ✅", kb([BACK])
    now = int(time.time())
    lines = ["📜 <b>قطعی‌ها</b> (جدیدترین‌ها)\n"]
    for r in rows:
        when_s = time.strftime("%m-%d %H:%M", time.gmtime(r["started_at"]))
        if r["resolved_at"]:
            lines.append(f"✅ <b>{H(r['name'])}</b> — {when_s} UTC، {format_dur(r['resolved_at'] - r['started_at'])}")
        else:
            lines.append(f"🔴 <b>{H(r['name'])}</b> — از {when_s} UTC، <b>{format_dur(now - r['started_at'])}</b>\n    {H(human_err(r['last_error']))}")
            d = dg_get(r["config_id"])   # Feature: diagnostics — the likely cause of this outage, in Persian
            if d and d.get("incident_id") == r["id"]:
                lines.append(f"    🔎 {H(dg_cause_text(d['cause'], d['args'], fa=True)[0])}")
    return "\n".join(lines), kb([("📄 فایل CSV همه", "incsv"), BACK])

def scr_feed():
    cs = config_states()
    healthy = sum(1 for c in cs if c["state"] in ("up", "slow"))
    protos = sorted({c["protocol"] for c in cs if c["enabled"] and c["protocol"]})
    text = (f"📡 <b>ساب تمیز</b>\n\nفقط کانفیگ‌های سالم در این لینک هستند ({healthy} از {len(cs)}). قطع‌شده‌ها خودکار حذف و بعد از وصل شدن برمی‌گردند.\n\n"
            f"<code>{H(feed_url())}</code>")
    rows = [[("⚡ کمترین پینگ", "fq:sort=ping"), ("🚀 بیشترین سرعت", "fq:sort=speed")],
            [("🏆 بهترین‌ها", "fq:sort=best"), ("🏆 ۵ تای برتر", "fq:sort=best&limit=5")]]
    rows += [[(p.upper(), f"fq:proto={p}") for p in protos[i:i + 3]] for i in range(0, len(protos), 3)]
    rows += [[("🔁 عوض کردن لینک", "frx"), BACK]]
    return text, kb(*rows)

def scr_speed():
    cs = [c for c in config_states() if c["last_speed_mbps"]]
    cs.sort(key=lambda c: -c["last_speed_mbps"])
    lines = ["⚡ <b>تست سرعت</b> (آخرین نتیجه هر کانفیگ؛ تست دستی ۱۰۰ مگابایت دانلود می‌کند)\n"]
    medals = ["🥇", "🥈", "🥉"]
    for i, c in enumerate(cs[:10]):
        lines.append(f"{medals[i] if i < 3 else f'{i + 1}.'} <b>{H(c['name'])}</b> — {c['last_speed_mbps']} Mbps")
    if not cs:
        lines.append("هنوز تستی انجام نشده.")
    lines.append("\nبرای تست یک کانفیگ، از صفحه همان کانفیگ «تست سرعت» را بزنید.")
    return "\n".join(lines), kb([("⚡ تست همه سالم‌ها", "spa")], [BACK])

SET_FIELDS = {"interval": ("فاصله تست (ثانیه)", 2, 86400), "threshold": ("تعداد خطا تا هشدار", 1, 20),
              "timeout": ("مهلت هر تست (ثانیه)", 1, 60), "url": ("آدرس تست", None, None)}

def scr_settings():
    s = get_settings()
    https = s.get("use_https") == "1"
    text = ("⚙️ <b>تنظیمات تست</b>\n\n" +
            "\n".join(f"{lbl}: <b>{H(s.get(k, ''))}</b>" for k, (lbl, _, _) in SET_FIELDS.items()) +
            f"\nHTTPS پنل: <b>{'روشن' if https else 'خاموش'}</b>")
    return text, kb(
        [("⏱ فاصله تست", "se:interval"), ("❌ تعداد خطا", "se:threshold")],
        [("⌛ مهلت تست", "se:timeout"), ("🌐 آدرس تست", "se:url")],
        [("🔒 خاموش کردن HTTPS" if https else "🔒 روشن کردن HTTPS", "hx")],
        *TG_SETTINGS_ROWS,
        [("🔐 امنیت پنل وب", "sec"), BACK])

def scr_security():
    totp = get_meta("totp_enabled") == "1"
    text = ("🔐 <b>امنیت پنل وب</b>\n\nاگر رمز پنل وب را فراموش کرده‌اید، اینجا یک رمز جدید بسازید. "
            f"احراز دومرحله‌ای: <b>{'روشن' if totp else 'خاموش'}</b>")
    rows = [[("🔑 ساختن رمز جدید", "pwx")]]
    if totp:
        rows.append([("🚫 خاموش کردن احراز دومرحله‌ای", "tfx")])
    rows.append([("« تنظیمات", "set")])
    return text, kb(*rows)

def scr_notify():
    s = get_settings()
    on = lambda k: s.get(k, DEF_SETTINGS[k]) == "1"
    mark = lambda k: "✅" if on(k) else "⬜"
    rh = s.get("remind_hours", "2")
    admins = [x for x in s.get("tg_admins", "").split(",") if x]
    text = ("🔔 <b>اعلان‌ها</b>\n\nروی هر مورد بزنید تا روشن یا خاموش شود.\n"
            f"تکرار قطعی ادامه‌دار: <b>{'هیچ‌وقت' if rh == '0' else f'هر {rh} ساعت'}</b>\n"
            f"ادمین‌های ربات: <b>{', '.join(admins) if admins else 'فقط همین چت خصوصی'}</b>\n"
            "بی‌صدا کردن یک کانفیگ از صفحه همان کانفیگ است.")
    return text, kb(
        [(f"{mark('notify_down')} هشدار قطعی", "nt:notify_down"), (f"{mark('notify_recover')} هشدار وصل شدن", "nt:notify_recover")],
        [(f"{mark('daily_backup')} بک‌آپ روزانه", "nt:daily_backup"), (f"{mark('daily_report')} گزارش روزانه", "nt:daily_report")],
        [(("• " if rh == h else "") + lbl, f"rm:{h}") for h, lbl in (("0", "تکرار نه"), ("1", "۱h"), ("2", "۲h"), ("6", "۶h"), ("24", "۲۴h"))],
        [("👤 ادمین‌ها", "adm"), ("📨 پیام آزمایشی", "tt")],
        [BACK])

def scr_prompt(text):
    return text, kb([("✖ لغو", "cancel")])

def scr_confirm(text, yes_data, no_data, yes="بله، انجام بده"):
    return text, kb([(f"⚠️ {yes}", yes_data), ("✖ نه", no_data)])

# ----- sending -----
def tg_show(chat_id, screen, msg_id=None):
    text, markup = screen
    p = {"chat_id": chat_id, "text": text[:4096], "parse_mode": "HTML", "disable_web_page_preview": "true", "reply_markup": markup}
    if msg_id:
        r = tg_api("editMessageText", {**p, "message_id": msg_id})
        if r and (r.get("ok") or "not modified" in str(r.get("description", ""))):
            return
    tg_api("sendMessage", p)

def tg_toast(cb_id, text="", alert=False):
    tg_api("answerCallbackQuery", {"callback_query_id": cb_id, "text": text[:190], "show_alert": "true" if alert else None}, timeout=8)

def tg_send_db(chat_id, caption):
    with lock:
        db_conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    return tg_api("sendDocument", {"chat_id": chat_id, "caption": caption}, doc=(DB_FILE, "sentinel.db"), timeout=60)

def set_pending(uid, kind, chat_id, msg_id):
    with tg_pending_lock:
        tg_pending[str(uid)] = {"kind": kind, "chat": chat_id, "msg": msg_id, "at": time.time()}

def pop_pending(uid):
    with tg_pending_lock:
        p = tg_pending.pop(str(uid), None)
    return p if p and time.time() - p["at"] < 900 else None

# ----- callbacks -----
def tg_callback(data, uid, chat_id, msg_id, cb_id):
    show = lambda scr: tg_show(chat_id, scr, msg_id)
    a = data.split(":")
    try:
        if a[0] in TG_ROUTES:
            return TG_ROUTES[a[0]](a[1:], uid, chat_id, msg_id, cb_id, show)
        if data in ("m", "st"):
            return show(scr_main())
        if a[0] == "cl":
            return show(scr_configs(int(a[1]), a[2]))
        if a[0] == "c":
            return show(scr_config(a[1]))
        if a[0] == "cx":
            name = next((c["name"] for c in config_states() if c["id"] == a[1]), "?")
            return show(scr_confirm(f"🗑 کانفیگ <b>{H(name)}</b> و تاریخچه‌اش حذف شود؟ این کار برگشت ندارد.", f"cd:{a[1]}", f"c:{a[1]}", "حذف کن"))
        if a[0] == "cd":
            svc_delete_config(a[1])
            tg_toast(cb_id, "حذف شد")
            return show(scr_configs(0, "a"))
        if a[0] == "ca":
            act, cid = a[1], a[2]
            if act == "tg":
                v = svc_toggle_config(cid)
                tg_toast(cb_id, "ادامه پیدا کرد" if v else "متوقف شد")
                return show(scr_config(cid))
            if act == "mu":
                v = svc_mute_config(cid)
                tg_toast(cb_id, "اعلان‌های این کانفیگ خاموش شد" if v else "اعلان‌ها روشن شد")
                return show(scr_config(cid))
            if act == "rn":
                set_pending(uid, f"rename:{cid}", chat_id, msg_id)
                return show(scr_prompt("✏️ اسم جدید این کانفیگ را بفرستید."))
            if act == "ln":
                with lock:
                    r = db_conn.execute("SELECT name, uri FROM configs WHERE id=?", (cid,)).fetchone()
                if r:
                    tg_api("sendMessage", {"chat_id": chat_id, "text": f"🔗 <b>{H(r['name'])}</b>\n<code>{H(r['uri'])}</code>", "parse_mode": "HTML"})
                return tg_toast(cb_id)
            if act == "sp":
                tg_toast(cb_id, "تست سرعت شروع شد (تا ۳۰ ثانیه)")
                tg_show(chat_id, ("⏳ در حال دانلود ۱۰۰ مگابایت…", kb()), msg_id)
                res = run_speed_test(cid)
                msg = f"⚡ سرعت: <b>{res['mbps']} Mbps</b> ({res['elapsed']} ثانیه)" if res.get("ok") else f"❌ تست سرعت نشد: {H(human_err(res.get('error')))}"
                text, markup = scr_config(cid)
                return show((msg + "\n\n" + text, markup))
            if act == "pr":
                tg_toast(cb_id, "در حال تست…")
                with lock:
                    r = db_conn.execute("SELECT id, port FROM configs WHERE id=?", (cid,)).fetchone()
                s = get_settings()
                if r and config_errors.get(cid):
                    msg = f"❌ {H(config_errors[cid])}"
                elif r:
                    _, ok, ms, err, ok_iran = probe_one(dict(r), int(s.get("timeout", 8)), s.get("url"))
                    msg = f"✅ وصل است: <b>{ms}ms</b>" if ok else f"❌ وصل نشد: {H(human_err(err))}" + (" (اینترنت ملی وصل است)" if ok_iran else "")
                else:
                    msg = "پیدا نشد."
                text, markup = scr_config(cid)
                return show((msg + "\n\n" + text, markup))
        if data == "add":
            set_pending(uid, "add", chat_id, msg_id)
            return show(scr_prompt("➕ لینک کانفیگ‌ها را بفرستید (هر چند تا، در یک پیام).\n"
                                   "vless، vmess، trojan، ss، hysteria2/hy2، wireguard، socks\n"
                                   "با sing-box: tuic، hysteria، anytls، naive، ssh و ShadowTLS\n\n"
                                   "بعداً هم هر وقت لینکی در این چت بفرستید، اضافه می‌شود."))
        if data == "sb":
            return show(scr_subs())
        if a[0] == "s":
            return show(scr_sub(a[1]))
        if data == "sadd":
            set_pending(uid, "sub", chat_id, msg_id)
            return show(scr_prompt("🔗 لینک ساب را بفرستید. اگر خواستید، اسمش را در خط دوم بنویسید."))
        if a[0] == "sa":
            act, sid = a[1], a[2]
            if act == "sy":
                tg_toast(cb_id, "در حال همگام‌سازی…")
                res = sync_sub(sid)
                msg = (f"✅ +{res['added']} جدید، -{res['removed']} حذف" if res.get("ok") else f"❌ {H(res.get('error', ''))}")
                text, markup = scr_sub(sid)
                return show((msg + "\n\n" + text, markup))
            if act == "en":
                with lock:
                    r = db_conn.execute("SELECT enabled FROM subscriptions WHERE id=?", (sid,)).fetchone()
                if r:
                    svc_update_sub(sid, enabled=not r["enabled"])
                return show(scr_sub(sid))
            if act.startswith("i"):
                svc_update_sub(sid, interval_hours=int(act[1:]))
                return show(scr_sub(sid))
        if a[0] == "sx":
            return show((f"🗑 این ساب حذف شود؟ کانفیگ‌هایش هم حذف شوند؟", kb(
                [("⚠️ حذف با کانفیگ‌ها", f"sd:1:{a[1]}")], [("حذف، کانفیگ‌ها بمانند", f"sd:0:{a[1]}")], [("✖ نه", f"s:{a[1]}")])))
        if a[0] == "sd":
            svc_delete_sub(a[2], a[1] == "1")
            tg_toast(cb_id, "حذف شد")
            return show(scr_subs())
        if data == "inc":
            return show(scr_incidents())
        if data == "incsv":
            path = f"{D}/incidents-{secrets.token_hex(3)}.csv"
            try:
                with open(path, "w") as f:
                    f.write(svc_incidents_csv())
                tg_api("sendDocument", {"chat_id": chat_id}, doc=(path, "sentinel-incidents.csv"), timeout=40)
            finally:
                try: os.remove(path)
                except OSError: pass
            return tg_toast(cb_id)
        if data == "fd":
            return show(scr_feed())
        if a[0] == "fq":
            q = data[3:]
            tg_api("sendMessage", {"chat_id": chat_id, "text": f"📡 <code>{H(feed_url(q))}</code>", "parse_mode": "HTML"})
            return tg_toast(cb_id)
        if data == "frx":
            return show(scr_confirm("🔁 لینک ساب تمیز عوض شود؟ لینک فعلی از کار می‌افتد و کاربران باید لینک جدید را وارد کنند.", "fr!", "fd", "عوض کن"))
        if data == "fr!":
            svc_rotate_feed()
            tg_toast(cb_id, "لینک عوض شد")
            return show(scr_feed())
        if data == "sp":
            return show(scr_speed())
        if data == "spa":
            started = svc_start_speed_all(on_done=lambda: tg_show(chat_id, scr_speed()))
            tg_toast(cb_id, "تست سرعت همه شروع شد؛ آخرش نتیجه را می‌فرستم" if started else "یک تست سرعت در حال اجراست", alert=not started)
            return
        if data == "ck":
            wake.set()
            return tg_toast(cb_id, "تست همه کانفیگ‌ها شروع شد")
        if data == "bk":
            tg_toast(cb_id, "در حال فرستادن بک‌آپ…")
            tg_send_db(chat_id, f"Sentinel backup ({time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime())})")
            return
        if data == "set":
            return show(scr_settings())
        if a[0] == "se":
            set_pending(uid, f"set:{a[1]}", chat_id, msg_id)
            lbl, lo, hi = SET_FIELDS[a[1]]
            return show(scr_prompt(f"✏️ مقدار جدید «{lbl}» را بفرستید" + (f" ({lo} تا {hi})." if lo else ".")))
        if data == "hx":
            on = get_settings().get("use_https") == "1"
            return show(scr_confirm(f"پنل وب {'با HTTP' if on else 'با HTTPS'} باز شود؟ Sentinel چند ثانیه ری‌استارت می‌شود.", "hx!", "set", "ری‌استارت کن"))
        if data == "hx!":
            err = svc_apply_settings({"use_https": "0" if get_settings().get("use_https") == "1" else "1"})
            tg_toast(cb_id, err or "ذخیره شد؛ Sentinel ری‌استارت می‌شود", alert=bool(err))
            return show(scr_settings())
        if data == "sec":
            return show(scr_security())
        if data == "pwx":
            return show(scr_confirm("🔑 یک رمز جدید برای پنل وب ساخته شود؟ رمز فعلی دیگر کار نمی‌کند.", "pw!", "sec", "بساز"))
        if data == "pw!":
            pw = svc_reset_password()
            tg_api("sendMessage", {"chat_id": chat_id, "text": f"🔑 رمز جدید پنل وب:\n<code>{H(pw)}</code>\n\nبعد از ورود این پیام را پاک کنید.", "parse_mode": "HTML"})
            return show(scr_security())
        if data == "tfx":
            return show(scr_confirm("🚫 احراز دومرحله‌ای پنل وب خاموش شود؟", "tf!", "sec", "خاموش کن"))
        if data == "tf!":
            svc_disable_2fa()
            tg_toast(cb_id, "احراز دومرحله‌ای خاموش شد")
            return show(scr_security())
        if data == "nt":
            return show(scr_notify())
        if a[0] == "nt" and a[1] in NOTIFY_FLAGS:
            cur = get_settings().get(a[1], DEF_SETTINGS[a[1]]) == "1"
            svc_apply_settings({a[1]: "0" if cur else "1"})
            return show(scr_notify())
        if a[0] == "rm":
            svc_apply_settings({"remind_hours": a[1]})
            return show(scr_notify())
        if data == "adm":
            set_pending(uid, "admins", chat_id, msg_id)
            return show(scr_prompt(f"👤 آیدی عددی ادمین‌ها را بفرستید (با کاما یا فاصله جدا).\nآیدی شما: <code>{uid}</code>\n"
                                   "برای برگشتن به «فقط این چت خصوصی»، عدد 0 بفرستید."))
        if data == "tt":
            ok = send_telegram("✅ <b>پیام آزمایشی Sentinel</b>\nهشدارها به این چت می‌رسند.")
            return tg_toast(cb_id, "فرستاده شد" if ok else "نرسید؛ Chat ID را چک کنید", alert=not ok)
        if data == "cancel":
            pop_pending(uid)
            return show(scr_main())
    except Exception as e:
        print("bot callback error:", data, e, flush=True)
        return tg_toast(cb_id, "خطا: " + str(e)[:150], alert=True)
    return tg_toast(cb_id)

# ----- text messages -----
COMMANDS = [("start", "منوی اصلی"), ("status", "وضعیت کلی"), ("configs", "لیست کانفیگ‌ها"), ("down", "کانفیگ‌های مشکل‌دار"),
            ("add", "افزودن کانفیگ"), ("subs", "ساب‌ها"), ("speed", "تست سرعت"), ("incidents", "قطعی‌ها"),
            ("sub", "لینک ساب تمیز"), ("check", "تست همه الان"), ("settings", "تنظیمات"), ("notify", "اعلان‌ها"),
            ("backup", "بک‌آپ دیتابیس"), ("id", "آیدی شما"), ("cancel", "لغو")]

def tg_text(text, uid, chat_id):
    t = (text or "").strip()
    cmd = t.split()[0].lower().split("@")[0] if t.startswith("/") else ""
    p = None if cmd else pop_pending(uid)
    if cmd == "/cancel":
        pop_pending(uid)
        return tg_show(chat_id, scr_main())
    if p:
        kind = p["kind"]
        back = lambda scr: tg_show(p["chat"], scr, p["msg"])
        if kind.split(":")[0] in TG_PENDING:
            return TG_PENDING[kind.split(":")[0]](t, uid, chat_id, p)
        if kind == "add":
            added, errs = svc_add_configs(t)
            msg = f"✅ {added} کانفیگ اضافه شد." + ("\n\n❌ " + "\n❌ ".join(H(e) for e in errs[:8]) if errs else "")
            return tg_show(chat_id, (msg, kb([("📋 کانفیگ‌ها", "cl:0:a"), BACK])))
        if kind.startswith("rename:"):
            cid = kind.split(":", 1)[1]
            svc_rename_config(cid, t)
            return back(scr_config(cid))
        if kind == "sub":
            parts = t.splitlines()
            ok, res = svc_add_sub(parts[0].strip(), parts[1].strip() if len(parts) > 1 else "")
            msg = (f"✅ ساب اضافه شد: +{res['added']} کانفیگ" + (f" ({res['skipped']} رد شد)" if res.get("skipped") else "")) if ok else f"❌ {H(res)}"
            return tg_show(chat_id, (msg, kb([("🔗 ساب‌ها", "sb"), BACK])))
        if kind.startswith("set:"):
            key = kind.split(":", 1)[1]
            _, lo, hi = SET_FIELDS[key]
            if lo is not None and (not t.isdigit() or not lo <= int(t) <= hi):
                set_pending(uid, kind, p["chat"], p["msg"])
                return tg_api("sendMessage", {"chat_id": chat_id, "text": f"عددی بین {lo} و {hi} بفرستید."})
            err = svc_apply_settings({key: t})
            if err:
                set_pending(uid, kind, p["chat"], p["msg"])
                return tg_api("sendMessage", {"chat_id": chat_id, "text": f"❌ {err}"})
            return back(scr_settings())
        if kind == "admins":
            err = svc_apply_settings({"tg_admins": "" if t.strip() == "0" else t})
            return back(scr_notify())
    if cmd in ("/start", "/menu", "/status", "/help"):
        return tg_show(chat_id, scr_main())
    if cmd in ("/configs", "/list"):
        return tg_show(chat_id, scr_configs(0, "a"))
    if cmd == "/down":
        return tg_show(chat_id, scr_configs(0, "d"))
    if cmd == "/add":
        rest = t[len(t.split()[0]):]
        if LINK_RE.search(rest):
            return tg_text(rest, uid, chat_id)
        m = tg_api("sendMessage", {"chat_id": chat_id, "text": "…"})
        mid = (m or {}).get("result", {}).get("message_id")
        return tg_callback("add", uid, chat_id, mid, None)
    if cmd == "/subs":
        return tg_show(chat_id, scr_subs())
    if cmd in ("/speed", "/top"):
        return tg_show(chat_id, scr_speed())
    if cmd == "/incidents":
        return tg_show(chat_id, scr_incidents())
    if cmd in ("/sub", "/feed"):
        return tg_show(chat_id, scr_feed())
    if cmd in ("/check", "/ping"):
        wake.set()
        return tg_api("sendMessage", {"chat_id": chat_id, "text": "🔄 تست همه کانفیگ‌ها شروع شد."})
    if cmd == "/settings":
        return tg_show(chat_id, scr_settings())
    if cmd == "/notify":
        return tg_show(chat_id, scr_notify())
    if cmd == "/backup":
        return tg_send_db(chat_id, f"Sentinel backup ({time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime())})")
    if cmd == "/id":
        return tg_api("sendMessage", {"chat_id": chat_id, "text": f"آیدی شما: <code>{uid}</code>", "parse_mode": "HTML"})
    if LINK_RE.search(t):
        added, errs = svc_add_configs(t)
        msg = f"✅ {added} کانفیگ اضافه شد." + ("\n\n❌ " + "\n❌ ".join(H(e) for e in errs[:8]) if errs else "")
        return tg_show(chat_id, (msg, kb([("📋 کانفیگ‌ها", "cl:0:a"), BACK])))
    if cmd:
        return tg_show(chat_id, scr_main())

def tg_handle_update(item, s):
    cb, msg = item.get("callback_query"), item.get("message")
    if cb:
        uid = cb.get("from", {}).get("id")
        m = cb.get("message") or {}
        chat_id = m.get("chat", {}).get("id")
        if not tg_is_admin(uid, chat_id, s):
            return tg_toast(cb.get("id"), "⛔ دسترسی ندارید", alert=True)
        tg_callback(cb.get("data", ""), uid, chat_id, m.get("message_id"), cb.get("id"))
    elif msg:
        uid = msg.get("from", {}).get("id")
        chat = msg.get("chat", {})
        if not tg_is_admin(uid, chat.get("id"), s):
            # Only a private chat learns why; groups and strangers get nothing.
            if chat.get("type") == "private" and (msg.get("text") or "").startswith("/"):
                tg_api("sendMessage", {"chat_id": chat.get("id"), "parse_mode": "HTML",
                                       "text": f"⛔ شما ادمین این ربات نیستید.\nآیدی شما: <code>{uid}</code>\nدر پنل Sentinel، تنظیمات ← اعلان‌ها ← ادمین‌های ربات اضافه‌اش کنید."})
            return
        tg_text(msg.get("text") or msg.get("caption") or "", uid, chat.get("id"))

last_backup_day = None

def tg_daily(s):
    """Backup and report at 00:00 UTC, once a day, to the alert chat."""
    global last_backup_day
    run_hooks([report_weekly_due], s)  # Feature: reports (Monday 00:00 UTC, once per ISO week)
    day = time.strftime("%Y-%m-%d", time.gmtime())
    if time.gmtime().tm_hour != 0 or last_backup_day == day or not s.get("chat"):
        return
    last_backup_day = day
    if s.get("daily_report", "0") == "1":
        rep = scr_main()[0].replace("🛡️ <b>Sentinel</b>", f"🗓 <b>گزارش روزانه Sentinel</b> ({day})")
        if not send_telegram(rep):
            al_daily_fallback(report=rep)   # Bale / webhook, when set up
    if s.get("daily_backup", "1") == "1":
        cap = f"Automated Daily Backup ({day} 00:00 UTC)"
        if not (tg_send_db(s.get("chat"), cap) or {}).get("ok"):
            al_daily_fallback(caption=cap)

def telegram_bot_worker():
    global tg_commands_set_for
    offset = 0
    while True:
        try:
            s = get_settings()
            tok = s.get("token", "")
            if not tok:
                time.sleep(10)
                continue
            if tg_commands_set_for != tok:
                if tg_api("setMyCommands", {"commands": [{"command": c, "description": d} for c, d in COMMANDS]}):
                    tg_commands_set_for = tok
            tg_daily(s)
            res = tg_api("getUpdates", {"offset": offset, "timeout": 20, "allowed_updates": ["message", "callback_query"]}, timeout=30)
            items = (res or {}).get("result") or []
            for item in items:
                offset = item["update_id"] + 1
                threading.Thread(target=tg_handle_update, args=(item, s), daemon=True).start()
            if not items:
                time.sleep(1 if res else 5)
        except Exception as e:
            print("bot error:", e, flush=True)
            time.sleep(5)

def flush_alerts():
    # Telegram plus the alert channels (Bale, webhook); see "Feature: alert channels".
    al_flush()

def format_dur(sec):
    s = int(sec)
    if s < 60: return f"{s}s"
    if s < 3600: return f"{s//60}m {s%60}s"
    return f"{s//3600}h {(s%3600)//60}m"

def tick():
    s = get_settings()
    threshold = int(s.get("threshold", 3))
    timeout = int(s.get("timeout", 8))
    probe_url = s.get("url", "http://cp.cloudflare.com/generate_204")
    want_down = s.get("notify_down", "1") == "1"
    want_recover = s.get("notify_recover", "1") == "1"
    try:
        remind_after = int(s.get("remind_hours", "2")) * 3600
    except ValueError:
        remind_after = 7200

    with lock:
        cur = db_conn.execute("""
            SELECT c.id, c.name, c.uri, c.addr, c.port, c.sub_id, c.muted, s.name as sub_name, s.url as sub_url
            FROM configs c
            LEFT JOIN subscriptions s ON s.id = c.sub_id
            WHERE c.enabled=1
        """)
        configs = [dict(r) for r in cur.fetchall()]
    # Feature: engines: a config whose engine is not installed is not probed (no incident, no alert).
    configs = [c for c in configs if not engine_missing(c)]

    if not configs:
        flush_alerts()
        return

    # Randomize test order to prevent synchronized bursts or hotspotting
    random.shuffle(configs)

    # Staggered testing one-by-one with 500ms pacing pause
    for idx, cfg in enumerate(configs):
        bad = config_errors.get(cfg["id"])
        if bad:
            # Xray refused this config, so it has no proxy to probe through.
            cid, ok, ms, err, ok_iran = cfg["id"], False, None, bad, 0
        else:
            cid, ok, ms, err, ok_iran = probe_one(cfg, timeout, probe_url)
            if not ok and insecure_dropped(cfg["uri"]):
                err = ("This Xray no longer allows insecure=1, so the certificate was verified; "
                       "add pinSHA256 (Hysteria2) or pcs (VLESS/Trojan) to the link. " + (err or ""))[:300]
        now = int(time.time())

        with lock:
            db_conn.execute(
                "INSERT INTO checks (config_id, ok, latency_ms, error, checked_at, ok_iran) VALUES (?, ?, ?, ?, ?, ?)",
                (cid, 1 if ok else 0, ms, err, now, ok_iran)
            )
            sub_info = f"<b>{H(cfg['sub_name'])}</b>" if cfg.get("sub_name") else "<i>دستی (Manual)</i>"
            time_str = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(now))

            cur = db_conn.execute("SELECT * FROM incidents WHERE config_id=? AND resolved_at IS NULL ORDER BY id DESC LIMIT 1", (cid,))
            inc = cur.fetchone()
            if ok:
                if inc:
                    db_conn.execute("UPDATE incidents SET resolved_at=?, resolved_alert_sent=1 WHERE id=?", (now, inc["id"]))
                    dur = format_dur(now - inc["started_at"])
                    msg = (
                        f"🟢 <b>اتصال مجدد نود | Node Restored</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n"
                        f"📡 <b>نام نود:</b> <code>{H(cfg['name'])}</code>\n"
                        f"🌐 <b>آدرس:</b> <code>{H(cfg['addr'])}</code>\n"
                        f"📦 <b>اشتراک:</b> {sub_info}\n"
                        f"⏱ <b>مدت زمان قطعی:</b> <b>{dur}</b>\n"
                        f"⚡ <b>تاخیر پینگ:</b> <b>{ms}ms</b>\n"
                        f"🕒 <b>زمان بازگشت:</b> <code>{time_str}</code>\n"
                        f"━━━━━━━━━━━━━━━━━━━━━\n"
                        f"<i>نود مجدداً به لینک سابسکریپشن کاربران اضافه شد.</i>"
                    )
                    if want_recover and not cfg.get("muted"):
                        db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))
            else:
                cur = db_conn.execute("SELECT ok FROM checks WHERE config_id=? ORDER BY id DESC LIMIT ?", (cid, threshold))
                recent = [r["ok"] for r in cur.fetchall()]
                if len(recent) >= threshold and all(v == 0 for v in recent):
                    if not inc:
                        db_conn.execute(
                            "INSERT INTO incidents (config_id, started_at, last_error, alert_sent, last_reminder_at) VALUES (?, ?, ?, 1, ?)",
                            (cid, now, err, now)
                        )
                        net_tag = "\n🟡 <b>وضعیت: اینترنت ملی (Intranet Only)</b>\n" if ok_iran == 1 else ""
                        msg = (
                            f"🔴 <b>هشدار قطعی نود | Node Outage Alert</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"📡 <b>نام نود:</b> <code>{H(cfg['name'])}</code>\n"
                            f"🌐 <b>آدرس:</b> <code>{H(cfg['addr'])}</code>\n"
                            f"📦 <b>اشتراک:</b> {sub_info}\n"
                            f"❌ <b>تعداد تست ناموفق:</b> {threshold}\n"
                            f"⚠️ <b>علت خطا:</b> <code>{H(err)}</code>"
                            f"{net_tag}\n"
                            f"🕒 <b>زمان رخداد:</b> <code>{time_str}</code>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"<i>نود موقتاً از لینک سابسکریپشن کاربران حذف شد.</i>"
                        )
                        if want_down and not cfg.get("muted"):
                            db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))
                    else:
                        db_conn.execute("UPDATE incidents SET last_error=? WHERE id=?", (err, inc["id"]))
                        inc_dict = dict(inc)
                        last_rem = inc_dict.get("last_reminder_at") or inc_dict.get("started_at") or now
                        if remind_after and want_down and not cfg.get("muted") and (now - last_rem) >= remind_after:
                            db_conn.execute("UPDATE incidents SET last_reminder_at=? WHERE id=?", (now, inc["id"]))
                            dur = format_dur(now - inc_dict["started_at"])
                            msg = (
                                f"⏳ <b>یادآوری: قطعی ادامه‌دار | Ongoing Outage</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━\n"
                                f"📡 <b>نام نود:</b> <code>{H(cfg['name'])}</code>\n"
                                f"🌐 <b>آدرس:</b> <code>{H(cfg['addr'])}</code>\n"
                                f"📦 <b>اشتراک:</b> {sub_info}\n"
                                f"⌛ <b>مدت کل قطعی:</b> <b>{dur}</b>\n"
                                f"⚠️ <b>آخرین خطا:</b> <code>{H(err)}</code>\n"
                                f"🕒 <b>زمان پایش:</b> <code>{time_str}</code>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━\n"
                                f"<i>این نود همچنان قطع است و از سابسکریپشن کاربران خارج می‌باشد.</i>"
                            )
                            db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, now))

            db_conn.commit()

        if idx < len(configs) - 1:
            time.sleep(0.5)

    with lock:
        cutoff = int(time.time()) - (30 * 86400)
        db_conn.execute("DELETE FROM checks WHERE checked_at < ?", (cutoff,))
        db_conn.commit()

    flush_alerts()

# ---------- Subscriptions ----------
def _curl_text(url, proxy_port=None, timeout=20):
    cmd = ["curl", "-sSL", "--max-time", str(timeout), "--max-filesize", "5000000",
           "-A", "v2rayN/6.0", "-w", "\n%{http_code}"]
    if proxy_port:
        cmd += ["-x", f"socks5h://127.0.0.1:{proxy_port}"]
    r = subprocess.run(cmd + [url], capture_output=True, text=True, timeout=timeout + 5)
    body, _, code = r.stdout.rpartition("\n")
    if r.returncode != 0 or not code.startswith("2"):
        raise RuntimeError((r.stderr.strip() or f"HTTP {code or 'none'}")[:120])
    return body

SUB_SCHEMES = ("vless://", "trojan://", "ss://", "vmess://", "hysteria2://", "hy2://",
               "wireguard://", "wg://", "socks://", "socks5://") + tuple(x + "://" for x in NEEDS_SINGBOX)

def decode_sub(text):
    """Subscription body: plain proxy URIs, or (urlsafe) base64 of them.
    Links Xray cannot test (tuic, ...) are kept so sync_sub can count them as skipped."""
    t = text.strip()
    schemes = SUB_SCHEMES
    if not any(s in t for s in schemes):
        try:
            raw = re.sub(r"\s+", "", t)
            alt = b"-_" if ("-" in raw or "_" in raw) else None  # urlsafe or standard base64
            t = base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=alt).decode("utf-8", "replace")
        except Exception:
            raise ValueError("Not a base64/plain subscription")
    uris, seen = [], set()
    for line in t.splitlines():
        line = line.strip()
        if any(line.startswith(s) for s in schemes) and line not in seen:
            seen.add(line); uris.append(line)
    if not uris:
        raise ValueError("No proxy links found in subscription")
    return uris

def fetch_sub(url):
    if not re.fullmatch(r"https?://[^\s\"']+", url):
        raise ValueError("Subscription URL must start with http:// or https://")
    errs = []
    try:
        return decode_sub(_curl_text(url))
    except Exception as e:
        errs.append(f"direct: {e}")
    with lock:
        ports = [r["port"] for r in db_conn.execute("""SELECT c.port FROM configs c JOIN checks ch ON ch.config_id=c.id
            WHERE c.enabled=1 AND ch.ok=1 GROUP BY c.id ORDER BY MAX(ch.checked_at) DESC LIMIT 3""").fetchall()]
    for p in ports:
        try:
            return decode_sub(_curl_text(url, p))
        except Exception as e:
            errs.append(f"via :{p}: {e}")
    raise RuntimeError("; ".join(errs)[:300])

def sync_sub(sid):
    """Fetch a subscription and make its configs match exactly (strict prune)."""
    with lock:
        sub = db_conn.execute("SELECT * FROM subscriptions WHERE id=?", (sid,)).fetchone()
    if not sub:
        return {"error": "not found"}
    now = int(time.time())
    try:
        uris = fetch_sub(sub["url"])
    except Exception as e:
        with lock:
            db_conn.execute("UPDATE subscriptions SET last_sync=?, last_ok=0, last_msg=? WHERE id=?", (now, str(e)[:300], sid))
            db_conn.commit()
        return {"ok": False, "error": str(e)}
    added = removed = skipped = 0
    unsupported = {}
    with lock:
        existing = {r["uri"]: r["id"] for r in db_conn.execute("SELECT id, uri FROM configs WHERE sub_id=?", (sid,))}
        others = {r["uri"] for r in db_conn.execute("SELECT uri FROM configs WHERE sub_id IS NULL OR sub_id != ?", (sid,))}
        next_port = db_conn.execute("SELECT COALESCE(MAX(port), ?) AS m FROM configs", (BASE_PORT,)).fetchone()["m"] + 1
        for uri in uris:
            if uri in existing:
                continue
            if uri in others:          # already added manually or by another sub: leave it alone
                skipped += 1
                continue
            try:
                info = parse_proxy_uri(uri)
                cid = secrets.token_hex(4)
                c = {"id": cid, "uri": uri}
                outbound_for(c)
                cc, cn = resolve_country(info["host"], info["name"])
                db_conn.execute(
                    "INSERT INTO configs (id, name, uri, addr, port, protocol, network, security, created_at, sub_id, country_code, country_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (cid, info["name"], uri, info["addr"], next_port, info["protocol"], info.get("network", "tcp"), info.get("security", "none"), now, sid, cc, cn))
                next_port += 1; added += 1
            except Exception:
                skipped += 1
                sch = uri.split("://", 1)[0].lower()
                unsupported[sch] = unsupported.get(sch, 0) + 1
        gone = [cid for uri, cid in existing.items() if uri not in set(uris)]
        for cid in gone:
            for t, col in (("configs", "id"), ("checks", "config_id"), ("incidents", "config_id")):
                db_conn.execute(f"DELETE FROM {t} WHERE {col}=?", (cid,))
            removed += 1
        total = db_conn.execute("SELECT COUNT(*) AS n FROM configs WHERE sub_id=?", (sid,)).fetchone()["n"]
        msg = f"+{added} new, -{removed} removed" + (f", {skipped} skipped" if skipped else "")
        if unsupported:
            msg += " (could not use: " + ", ".join(f"{k}×{n}" for k, n in sorted(unsupported.items())) + ")"
        db_conn.execute("UPDATE subscriptions SET last_sync=?, last_ok=1, last_msg=?, config_count=? WHERE id=?", (now, msg, total, sid))
        db_conn.commit()
    if added or removed:
        restart_xray()
        wake.set()
    return {"ok": True, "added": added, "removed": removed, "skipped": skipped, "total": total}

def sync_due_subs():
    now = int(time.time())
    with lock:
        due = [r["id"] for r in db_conn.execute(
            "SELECT id FROM subscriptions WHERE enabled=1 AND (last_sync IS NULL OR ? - last_sync >= interval_hours*3600)", (now,))]
    for sid in due:
        try:
            sync_sub(sid)
        except Exception as e:
            print("sub sync error:", e, flush=True)

def worker_loop():
    while True:
        try:
            with lock:
                has_cfgs = db_conn.execute("SELECT COUNT(*) AS c FROM configs WHERE enabled=1").fetchone()["c"] > 0
            if has_cfgs and (xp is None or xp.poll() is not None):
                restart_xray()
            sync_due_subs()
            tick()
        except Exception as e:
            print("worker error:", e, flush=True)
        s = get_settings()
        run_hooks(TICK_HOOKS, s)
        interval = max(2, int(s.get("interval", 30)))
        wake.wait(interval)
        wake.clear()

# ---------- Actions shared by the web panel and the Telegram bot ----------
# A link inside other text ends at whitespace; "ss://" must not match inside "wss://".
LINK_RE = re.compile(r"(?<![A-Za-z0-9+/])(?:" + "|".join(re.escape(x) for x in SUB_SCHEMES) + r")\S+")

def extract_links(text):
    """A line that starts with a link is taken whole (names may hold spaces);
    links inside other text, as in a chat message, end at whitespace."""
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        if line.startswith(SUB_SCHEMES):
            out.append(line)
        else:
            out += LINK_RE.findall(line)
    return list(dict.fromkeys(out))

def svc_add_configs(text):
    """Import every proxy link found in text: (added, errors)."""
    links = extract_links(text)
    if not links:
        return 0, ["No supported links found"]
    added, errs, new_ids = 0, [], []
    with lock:
        next_port = db_conn.execute("SELECT COALESCE(MAX(port), ?) AS maxp FROM configs", (BASE_PORT,)).fetchone()["maxp"] + 1
        known = {r["uri"] for r in db_conn.execute("SELECT uri FROM configs")}
        for line in links:
            if line in known:
                errs.append(f"{line[:30]}…: already added")
                continue
            try:
                info = parse_proxy_uri(line)
                cid = secrets.token_hex(4)
                c = {"id": cid, "uri": line}
                outbound_for(c)
                cc, cn = resolve_country(info["host"], info["name"])
                db_conn.execute(
                    "INSERT INTO configs (id, name, uri, addr, port, protocol, network, security, created_at, country_code, country_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (cid, info["name"][:80], line, info["addr"], next_port, info["protocol"], info.get("network", "tcp"),
                     info.get("security", "none"), int(time.time()), cc, cn))
                next_port += 1
                added += 1
                new_ids.append((cid, info["name"]))
                known.add(line)
            except Exception as ex:
                errs.append(f"{line[:30]}…: {ex}")
        db_conn.commit()
    if added:
        restart_xray()
        wake.set()
        for cid, nm in new_ids:
            if cid in config_errors:
                errs.append(f"{nm}: {config_errors[cid]}")
            elif engine_add_note(cid):  # Feature: engines: why a new link waits, even when no restart ran
                errs.append(f"{nm}: {engine_add_note(cid)}")
    return added, errs

def svc_delete_config(cid):
    with lock:
        db_conn.execute("DELETE FROM configs WHERE id=?", (cid,))
        db_conn.execute("DELETE FROM checks WHERE config_id=?", (cid,))
        db_conn.execute("DELETE FROM incidents WHERE config_id=?", (cid,))
        db_conn.commit()
    restart_xray()

def svc_toggle_config(cid):
    """Pause or resume; returns the new enabled value, or None if not found."""
    with lock:
        r = db_conn.execute("SELECT enabled FROM configs WHERE id=?", (cid,)).fetchone()
        if not r:
            return None
        new_state = 0 if r["enabled"] else 1
        db_conn.execute("UPDATE configs SET enabled=? WHERE id=?", (new_state, cid))
        db_conn.commit()
    restart_xray()
    wake.set()
    return new_state

def svc_mute_config(cid):
    """Mute or unmute Telegram alerts of one config; returns the new value or None."""
    with lock:
        r = db_conn.execute("SELECT muted FROM configs WHERE id=?", (cid,)).fetchone()
        if not r:
            return None
        db_conn.execute("UPDATE configs SET muted=? WHERE id=?", (0 if r["muted"] else 1, cid))
        db_conn.commit()
    return 0 if r["muted"] else 1

def svc_rename_config(cid, name):
    name = str(name or "").strip()[:80]
    if not name:
        return False
    with lock:
        db_conn.execute("UPDATE configs SET name=? WHERE id=?", (name, cid))
        db_conn.commit()
    return True

def svc_add_sub(url, name="", hrs=6):
    """Add and sync a subscription: (ok, result dict or error text)."""
    url, name = str(url or "").strip(), str(name or "").strip()[:60]
    if int(hrs) not in (1, 6, 12, 24):
        return False, "Interval must be 1, 6, 12 or 24 hours"
    if not re.fullmatch(r"https?://[^\s\"']+", url):
        return False, "URL must start with http:// or https://"
    sid = secrets.token_hex(4)
    with lock:
        if db_conn.execute("SELECT 1 FROM subscriptions WHERE url=?", (url,)).fetchone():
            return False, "This subscription is already added"
        db_conn.execute("INSERT INTO subscriptions (id, name, url, interval_hours, created_at) VALUES (?,?,?,?,?)",
                        (sid, name or up.urlparse(url).hostname or "Subscription", url, int(hrs), int(time.time())))
        db_conn.commit()
    res = sync_sub(sid)
    if not res.get("ok"):
        with lock:
            db_conn.execute("DELETE FROM subscriptions WHERE id=?", (sid,))
            db_conn.commit()
        return False, "Could not fetch subscription: " + res.get("error", "unknown")
    return True, {"id": sid, **res}

def svc_update_sub(sid, interval_hours=None, enabled=None, name=None):
    with lock:
        if not db_conn.execute("SELECT 1 FROM subscriptions WHERE id=?", (sid,)).fetchone():
            return "not found"
        if interval_hours is not None:
            if int(interval_hours) not in (1, 6, 12, 24):
                return "Interval must be 1, 6, 12 or 24 hours"
            db_conn.execute("UPDATE subscriptions SET interval_hours=? WHERE id=?", (int(interval_hours), sid))
        if enabled is not None:
            db_conn.execute("UPDATE subscriptions SET enabled=? WHERE id=?", (1 if enabled else 0, sid))
        if str(name or "").strip():
            db_conn.execute("UPDATE subscriptions SET name=? WHERE id=?", (str(name).strip()[:60], sid))
        db_conn.commit()
    return None

def svc_delete_sub(sid, delete_configs):
    with lock:
        if delete_configs:
            for r in db_conn.execute("SELECT id FROM configs WHERE sub_id=?", (sid,)).fetchall():
                for t, col in (("configs", "id"), ("checks", "config_id"), ("incidents", "config_id")):
                    db_conn.execute(f"DELETE FROM {t} WHERE {col}=?", (r["id"],))
        else:
            db_conn.execute("UPDATE configs SET sub_id=NULL WHERE sub_id=?", (sid,))
        db_conn.execute("DELETE FROM subscriptions WHERE id=?", (sid,))
        db_conn.commit()
    restart_xray()

def svc_rotate_feed():
    tok = secrets.token_hex(8)
    with lock:
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sub_token', ?)", (tok,))
        db_conn.commit()
    return tok

def svc_incidents_csv():
    with lock:
        rows = db_conn.execute(
            "SELECT c.name, c.addr, i.started_at, i.resolved_at, i.last_error FROM incidents i "
            "JOIN configs c ON c.id=i.config_id ORDER BY i.started_at DESC").fetchall()
    def q(v): return '"' + str(v if v is not None else "").replace('"', '""') + '"'
    iso = lambda t: time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(t)) if t else ""
    return "name,address,started_utc,resolved_utc,duration_s,error\n" + "".join(
        ",".join([q(r["name"]), q(r["addr"]), q(iso(r["started_at"])), q(iso(r["resolved_at"])),
                  q((r["resolved_at"] - r["started_at"]) if r["resolved_at"] else ""), q(r["last_error"])]) + "\n" for r in rows)

def svc_apply_settings(b):
    """Validate and store settings; returns an error text or None."""
    restart = False
    with lock:
        for k, v in b.items():
            if k not in DEF_SETTINGS or v is None:
                continue
            try:
                if k in ("interval", "threshold", "timeout"):
                    v = str(max(1, int(v)))
                if k == "remind_hours":
                    v = str(min(48, max(0, int(v))))
                if k in SETTING_RULES and not (k in SECRET_SETTINGS and str(v) in ("", "-")):
                    v = SETTING_RULES[k](v)
            except ValueError as e:
                return str(e) if k in SETTING_RULES else f"{k} must be a number"
            except TypeError:
                return f"{k} must be a number"
            if k in NOTIFY_FLAGS or k == "use_https":
                v = "1" if str(v) in ("1", "true", "True") else "0"
            if k == "tg_admins":
                v = ",".join(dict.fromkeys(re.findall(r"\d+", str(v))))
            if k == "url" and not re.fullmatch(r"https?://[^\s\"']+", str(v)):
                return "Probe URL must start with http:// or https://"
            if k in SECRET_SETTINGS and not v:
                continue
            if k in SECRET_SETTINGS - {"token", "chat"} and v == "-":
                v = ""
            if k == "token" and not re.fullmatch(r"\d+:[A-Za-z0-9_-]+", str(v)):
                return "Invalid Telegram bot token format"
            if k == "chat" and not re.fullmatch(r"-?\d+|@\w+", str(v)):
                return "Invalid chat ID format"
            if k == "use_https" and get_settings().get("use_https", "0") != str(v):
                restart = True
            db_conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))
        db_conn.commit()
    wake.set()
    if restart:
        # HTTPS is chosen at start; systemd (Restart=always) starts Sentinel again.
        threading.Timer(1.5, lambda: os._exit(0)).start()
    return None

def svc_reset_password():
    """Set a new random web password and return it."""
    pw = secrets.token_urlsafe(12)
    salt = secrets.token_hex(8)
    with lock:
        for k, v in (("salt", salt), ("pw", hashpw(pw, salt))):
            db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (k, v))
        db_conn.commit()
    try:
        write_credentials(pw, get_meta("path"), get_meta("port"))
    except OSError:
        pass
    return pw

def svc_disable_2fa():
    with lock:
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_enabled', '0')")
        db_conn.commit()

def svc_start_speed_all(on_done=None):
    """Start the speed test of every healthy config; False if one is running."""
    global sp_testing_all
    with lock:
        if sp_testing_all:
            return False
        sp_testing_all = True
    def run():
        run_speed_test_all_worker()
        if on_done:
            on_done()
    threading.Thread(target=run, daemon=True).start()
    return True

def feed_url(query=""):
    return f"{share_public()['base']}/sub/{get_meta('sub_token')}" + (f"?{query}" if query else "")

def _base_state(c):
    if not c.get("enabled"):
        return "paused"
    if c.get("down_since"):
        return "iran_only" if c.get("ok_iran") == 1 else "down"
    if c.get("last_ok") == 1:
        return "up"
    if c.get("last_ok") == 0:
        return "fail"
    return "new"

def config_state(c):
    """up / slow / down / iran_only / fail / no_engine / new / paused. Features refine it via STATE_RULES."""
    st = _base_state(c)
    for rule in STATE_RULES:
        st = rule(c, st) or st
    return st

STATE_ORDER = {"down": 0, "iran_only": 1, "fail": 2, "no_engine": 3, "slow": 4, "up": 5, "new": 6, "paused": 7}

def config_states():
    """Every config with its latest check and open incident, worst first."""
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT c.id, c.name, c.uri, c.addr, c.port, c.protocol, c.network, c.security, c.enabled, c.muted,
                   c.sub_id, c.last_speed_mbps, c.last_speed_time, c.created_at, s.name AS sub_name,
                   (SELECT ok FROM checks WHERE config_id=c.id ORDER BY checked_at DESC LIMIT 1) AS last_ok,
                   (SELECT latency_ms FROM checks WHERE config_id=c.id ORDER BY checked_at DESC LIMIT 1) AS latency,
                   (SELECT error FROM checks WHERE config_id=c.id ORDER BY checked_at DESC LIMIT 1) AS last_error,
                   (SELECT ok_iran FROM checks WHERE config_id=c.id ORDER BY checked_at DESC LIMIT 1) AS ok_iran,
                   (SELECT checked_at FROM checks WHERE config_id=c.id ORDER BY checked_at DESC LIMIT 1) AS last_check,
                   (SELECT started_at FROM incidents WHERE config_id=c.id AND resolved_at IS NULL ORDER BY id DESC LIMIT 1) AS down_since
            FROM configs c LEFT JOIN subscriptions s ON s.id = c.sub_id
            ORDER BY c.created_at DESC""")]
    run_hooks(ROW_HOOKS, rows)
    for c in rows:
        c["state"] = config_state(c)
    rows.sort(key=lambda c: STATE_ORDER[c["state"]])
    return rows

def human_err(e):
    """A probe error in plain words (the raw curl text is kept elsewhere)."""
    t = str(e or "")
    for pat, msg in ((r"\(28\)|timed out", "No answer before the timeout"),
                     (r"\(56\)|reset by peer", "The server closed the connection"),
                     (r"\(7\)|Couldn't connect|Failed to connect", "Could not connect to the local proxy"),
                     (r"\(97\)|SOCKS", "The proxy could not reach the server"),
                     (r"\(35\)|SSL|TLS", "TLS handshake failed"),
                     (r"\(6\)|resolve", "Could not resolve the address")):
        if not t.startswith(("Xray rejected", "This Xray", "Hysteria2 needs", "sing-box rejected", "Needs ")) and re.search(pat, t, re.I):
            return msg
    return t

# ---------- Feature: diagnostics ----------
# Why a config is down, checked directly from this box (not through the proxy):
# DNS -> TCP (or UDP) -> TLS with the link's SNI and a neutral one -> the latest
# proxy probe, then one *likely* cause in plain words. Runs in background
# threads, a few at a time; automatically once when an incident opens.
# Also certificate pinning for TCP TLS links that rely on insecure=1, which new
# Xray refuses: the pin is kept in configs.cert_pin and CERT_PINS (see outbound_for).
import ipaddress, ssl

DG_STEP = 4                  # seconds per network step
DG_PARALLEL = 3              # diagnoses at the same time
DG_NEUTRAL_SNI = "www.google.com"
DG_POISON = {"10.10.34.34", "10.10.34.35", "10.10.34.36", "d0::11"}  # Iranian DNS filtering answers
DG_ALERT_WINDOW = 1800       # follow-up alerts only for outages that opened this recently
DG_DOH = "https://1.1.1.1/dns-query"
DEF_SETTINGS.update({"auto_pin": "0"})
SETTING_RULES["auto_pin"] = lambda v: "1" if str(v).strip().lower() in ("1", "true", "on", "yes") else "0"

# key -> (English title, English action, Persian title, Persian action); {x} come from the cause args.
DG_CAUSES = {
    "healthy": ("Works now: the latest proxy check passed", "No action needed.",
                "الان کار می‌کند: آخرین تست پروکسی موفق بود", "کاری لازم نیست."),
    "rejected": ("Xray can't run this link", "Fix the link or update Xray.",
                 "Xray این لینک را قبول نمی‌کند", "لینک را درست کنید یا Xray را به‌روز کنید."),
    "net_limited": ("This server's own international internet looks limited: it can't reach {probe} directly either",
                    "The outage is likely on this server's side, not the config. Wait or check this server's network.",
                    "اینترنت بین‌الملل خود این سرور محدود به نظر می‌رسد: به {probe} هم مستقیم وصل نمی‌شود",
                    "مشکل احتمالاً از سمت همین سرور است، نه کانفیگ. صبر کنید یا شبکه سرور را بررسی کنید."),
    "dns_poisoned": ("DNS is likely poisoned: {host} resolves to {ip} here",
                     "Put the server's IP in the link or use another domain.",
                     "DNS احتمالاً مسموم است: {host} اینجا به {ip} می‌رسد",
                     "آی‌پی سرور را در لینک بگذارید یا از دامنه دیگری استفاده کنید."),
    "dns_local": ("This server's DNS can't resolve {host}, but 1.1.1.1 can",
                  "Fix the DNS resolver of this server, or put the IP in the link.",
                  "DNS این سرور {host} را پیدا نمی‌کند ولی 1.1.1.1 پیدا می‌کند",
                  "DNS سرور را درست کنید یا آی‌پی را در لینک بگذارید."),
    "dns_none": ("The domain {host} doesn't resolve", "Check the address in the link and the domain's DNS records.",
                 "دامنه {host} به هیچ آی‌پی‌ای نمی‌رسد", "آدرس لینک و رکوردهای DNS دامنه را بررسی کنید."),
    "port_closed": ("Server reachable, but port {port} refuses connections",
                    "Check that the service is running and listens on that port.",
                    "سرور در دسترس است ولی پورت {port} اتصال را رد می‌کند",
                    "مطمئن شوید سرویس روشن است و روی همین پورت گوش می‌دهد."),
    "ip_blocked": ("IP or port looks blocked: the server answers ping, but TCP to port {port} gets no answer",
                   "Try a CDN or another IP or port.",
                   "آی‌پی یا پورت مسدود به نظر می‌رسد: سرور به پینگ جواب می‌دهد ولی TCP پورت {port} جوابی ندارد",
                   "از CDN یا آی‌پی یا پورت دیگری استفاده کنید."),
    "no_answer": ("Server not answering: TCP to {addr} gets no reply",
                  "The server may be down or its IP blocked. Check it from outside Iran; if it is up, try a CDN or another IP.",
                  "سرور جواب نمی‌دهد: اتصال TCP به {addr} بی‌جواب می‌ماند",
                  "شاید سرور خاموش یا آی‌پی‌اش مسدود باشد. از خارج ایران چک کنید؛ اگر روشن است CDN یا آی‌پی دیگری امتحان کنید."),
    "sni_blocked": ("SNI likely filtered: the handshake with {sni} is cut, but a neutral name works",
                    "Try another SNI.",
                    "SNI احتمالاً فیلتر است: دست‌دهی با {sni} قطع می‌شود ولی با یک نام بی‌طرف کار می‌کند",
                    "SNI دیگری امتحان کنید."),
    "tls_blocked": ("TLS looks blocked on this IP: TCP connects, but every handshake is cut",
                    "Try a CDN or another IP.",
                    "TLS روی این آی‌پی مسدود به نظر می‌رسد: TCP وصل می‌شود ولی هر دست‌دهی قطع می‌شود",
                    "از CDN یا آی‌پی دیگری استفاده کنید."),
    "tls_rejected": ("The server refuses the TLS handshake for {sni}",
                     "Check that the SNI matches the server's certificate or REALITY server names.",
                     "سرور دست‌دهی TLS با {sni} را رد می‌کند",
                     "SNI را با گواهی سرور یا serverNames ریالیتی مقایسه کنید."),
    "cert_changed": ("The server's certificate changed since it was pinned",
                     "If you replaced it, pin it again. If not, someone may be intercepting the connection.",
                     "گواهی سرور از زمان پین عوض شده",
                     "اگر خودتان عوضش کردید دوباره پین کنید؛ وگرنه ممکن است کسی وسط راه باشد."),
    "cert_untrusted": ("Certificate likely rejected: the link relies on insecure=1, which this Xray no longer allows",
                       "Pin the certificate the server presents.",
                       "گواهی احتمالاً رد می‌شود: لینک به insecure=1 تکیه دارد که این Xray دیگر قبول نمی‌کند",
                       "گواهی سرور را پین کنید."),
    "hy2_cert": ("Certificate likely rejected: the link relies on insecure=1, which this Xray no longer allows",
                 "Add pinSHA256 (the SHA-256 of the server's certificate) to the link.",
                 "گواهی احتمالاً رد می‌شود: لینک به insecure=1 تکیه دارد که این Xray دیگر قبول نمی‌کند",
                 "pinSHA256 (هش SHA-256 گواهی سرور) را به لینک اضافه کنید."),
    "udp_closed": ("UDP port {port} is closed: the server says nothing listens there",
                   "Check that the service is running and listens on that port.",
                   "پورت UDP {port} بسته است: سرور می‌گوید چیزی روی آن نیست",
                   "مطمئن شوید سرویس روشن است و روی همین پورت گوش می‌دهد."),
    "udp_unknown": ("Can't be confirmed directly: the {proto} server gives no answer over UDP from here",
                    "The proxy check fails. UDP/QUIC may be filtered on this network, or check the config and the server.",
                    "مستقیم قابل تأیید نیست: سرور {proto} از اینجا روی UDP جوابی نمی‌دهد",
                    "تست پروکسی ناموفق است. شاید UDP/QUIC در این شبکه محدود باشد، یا کانفیگ و سرور را بررسی کنید."),
    "iran_only": ("Only the domestic network works through this config: the server likely has no international access",
                  "Check the server's own internet connection.",
                  "از این کانفیگ فقط اینترنت داخلی باز می‌شود: سرور احتمالاً به اینترنت بین‌الملل دسترسی ندارد",
                  "اتصال اینترنت خود سرور را بررسی کنید."),
    "proxy_fails": ("Server reachable, the proxy protocol fails",
                    "Check the config (UUID or password, path, flow) or the server logs.",
                    "سرور در دسترس است ولی پروتکل پروکسی کار نمی‌کند",
                    "کانفیگ (UUID یا رمز، path، flow) یا لاگ سرور را بررسی کنید."),
    "not_probed": ("Server reachable; there is no proxy check yet", "Wait for the next check.",
                   "سرور در دسترس است؛ هنوز تست پروکسی انجام نشده", "منتظر تست بعدی بمانید."),
    "unknown": ("No clear cause found", "Run the diagnosis again in a minute.",
                "علت روشنی پیدا نشد", "یک دقیقه بعد دوباره عیب‌یابی کنید."),
}
DG_STAGE_NAMES = {"dns": ("DNS", "DNS"), "tcp": ("Connection", "اتصال"), "udp": ("Connection (UDP)", "اتصال (UDP)"),
                  "tls": ("TLS", "TLS"), "proxy": ("Proxy", "پروکسی")}

_dg_lock = threading.Lock()
_dg_running = {}          # config id -> start time (memory only: a restart forgets it)
_dg_sem = threading.BoundedSemaphore(DG_PARALLEL)
_dg_tried_inc = set()     # incident ids an automatic diagnosis was started for
_dg_pin_jobs = {}         # config id -> {"running", "error", "note", "at"}
_dg_autopin_tried = {}    # config id -> last attempt
_dg_control = {"at": 0, "ok": True, "host": ""}


def _dg_migrate(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS diagnoses (
        config_id TEXT PRIMARY KEY, ran_at INTEGER NOT NULL, cause TEXT NOT NULL,
        args TEXT NOT NULL DEFAULT '{}', stages TEXT NOT NULL DEFAULT '[]',
        auto INTEGER DEFAULT 0, incident_id INTEGER)""")
    cols = [r[1] for r in conn.execute("PRAGMA table_info(configs)")]
    if "cert_pin" not in cols:
        conn.execute("ALTER TABLE configs ADD COLUMN cert_pin TEXT DEFAULT ''")
    if "cert_pin_at" not in cols:
        conn.execute("ALTER TABLE configs ADD COLUMN cert_pin_at INTEGER")
    if "diag_verdict" not in [r[1] for r in conn.execute("PRAGMA table_info(incidents)")]:
        conn.execute("ALTER TABLE incidents ADD COLUMN diag_verdict TEXT")
    CERT_PINS.clear()
    CERT_PINS.update({r[0]: r[1] for r in conn.execute("SELECT uri, cert_pin FROM configs WHERE cert_pin != ''")})
MIGRATIONS.append(_dg_migrate)


def _dg_timed(fn, t=DG_STEP):
    """Run fn in a thread and give up after t seconds (getaddrinfo has no timeout)."""
    box = {}
    def run():
        try: box["v"] = fn()
        except Exception as e: box["e"] = e
    th = threading.Thread(target=run, daemon=True)
    th.start(); th.join(t)
    if th.is_alive():
        raise TimeoutError("timed out")
    if "e" in box:
        raise box["e"]
    return box["v"]


def _dg_bogon(a):
    try:
        ip = ipaddress.ip_address(a)
    except ValueError:
        return False
    return a in DG_POISON or ip.is_private or ip.is_reserved or ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast


def _dg_is_ip(h):
    try:
        ipaddress.ip_address(h); return True
    except ValueError:
        return False


def dg_target(uri):
    """What can be checked directly for one link: host, port, transport, TLS mode, SNI, insecure."""
    info = parse_proxy_uri(uri)
    proto, q = info["protocol"], info.get("q", {})
    t = {"proto": proto, "host": info["host"], "port": info["port"],
         "transport": "udp" if proto in ("hysteria2", "wireguard") else "tcp",
         "tls": None, "sni": "", "insecure": False, "own_pin": "", "obfs": bool(q.get("obfs"))}
    if proto in ("vless", "trojan", "vmess") and info["security"] in ("tls", "reality"):
        t["tls"] = info["security"]
        t["sni"] = q.get("sni") or ("" if t["tls"] == "reality" else (q.get("host") or info["host"]))
        if proto == "vmess":
            raw = uri.strip()[8:]
            try:
                data = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4), altchars=b"-_").decode("utf-8"))
            except Exception:
                data = {}
            t["insecure"] = any(_truthy(data.get(k)) for k in ("allowInsecure", "insecure", "skip-cert-verify"))
            t["own_pin"] = str(data.get("pcs") or "")
        else:
            t["insecure"] = _truthy(q.get("allowInsecure")) or _truthy(q.get("insecure"))
            t["own_pin"] = q.get("pcs", "")
    return t


def dg_pin_eligible(t):
    return bool(t and t["tls"] == "tls" and t["insecure"] and not t["own_pin"])


# ----- stages: each returns {"key", "status": ok|fail|unknown, "kind", "en", "fa", ...} -----
def _st(key, status, kind, en, fa, **kw):
    d = {"key": key, "status": status, "kind": kind, "en": en, "fa": fa}
    d.update(kw)
    return d


def _dg_doh(host):
    """A records from 1.1.1.1 over HTTPS (plain UDP 53 is answered by the same filter): list, [] for no name, None if unreachable."""
    try:
        r = subprocess.run(["curl", "-sS", "--max-time", str(DG_STEP), "-H", "accept: application/dns-json",
                            "--get", "--data-urlencode", "name=" + host, "--data", "type=A", DG_DOH],
                           capture_output=True, text=True, timeout=DG_STEP + 2)
        d = json.loads(r.stdout)
    except Exception:
        return None
    if d.get("Status") == 3:
        return []
    if d.get("Status") != 0:
        return None
    return [a["data"] for a in d.get("Answer") or [] if a.get("type") == 1]


def dg_stage_dns(host, port):
    """(stage, addresses to use for the next steps)."""
    if _dg_is_ip(host):
        return _st("dns", "ok", "ip", "IP address, no lookup needed", "آی‌پی است، نیازی به DNS نیست"), [host]
    box = {}
    th = threading.Thread(target=lambda: box.update(doh=_dg_doh(host)), daemon=True)
    th.start()
    sys_ips, sys_err = None, ""
    try:
        res = _dg_timed(lambda: socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM))
        sys_ips = list(dict.fromkeys(r[4][0] for r in sorted(res, key=lambda r: r[0] != socket.AF_INET)))
    except TimeoutError:
        sys_err = "no answer from this server's resolver"
    except Exception:
        sys_err = "no such name here"
    th.join(DG_STEP + 3)
    doh = box.get("doh")
    doh_pub = [a for a in (doh or []) if not _dg_bogon(a)]
    second = ""
    if doh is not None:
        second = ", 1.1.1.1 agrees" if sys_ips and set(doh) & set(sys_ips) else (f", 1.1.1.1 says {doh[0]}" if doh else ", 1.1.1.1 has no record")
    second_fa = second.replace(", 1.1.1.1 agrees", "، 1.1.1.1 هم همین را می‌گوید").replace(", 1.1.1.1 says", "، 1.1.1.1 می‌گوید").replace(", 1.1.1.1 has no record", "، 1.1.1.1 رکوردی ندارد")
    if not sys_ips:
        if doh_pub:
            return _st("dns", "fail", "local", f"This server's resolver failed ({sys_err}), 1.1.1.1 says {doh_pub[0]}",
                       f"DNS این سرور جواب نداد، 1.1.1.1 می‌گوید {doh_pub[0]}"), doh_pub
        return _st("dns", "fail", "none", f"{host} doesn't resolve ({sys_err}){second}",
                   f"{host} به آی‌پی نمی‌رسد{second_fa}"), []
    poisoned = [a for a in sys_ips if a in DG_POISON]
    bogon = [a for a in sys_ips if _dg_bogon(a)]
    if poisoned or (bogon and doh_pub):
        bad = (poisoned or bogon)[0]
        why = "a known filtering address" if poisoned else "a private address"
        why_fa = "آدرس شناخته‌شده فیلترینگ" if poisoned else "آدرس خصوصی"
        return _st("dns", "fail", "poisoned", f"Resolves to {bad}, {why}" + (f"; 1.1.1.1 says {doh_pub[0]}" if doh_pub else ""),
                   f"به {bad} می‌رسد ({why_fa})" + (f"؛ 1.1.1.1 می‌گوید {doh_pub[0]}" if doh_pub else ""), ip=bad), (doh_pub or sys_ips)
    if bogon:
        return _st("dns", "ok", "private", f"Resolves to {bogon[0]}, a private address{second}",
                   f"به {bogon[0]} می‌رسد (آدرس خصوصی){second_fa}"), sys_ips
    return _st("dns", "ok", "ok", f"Resolves to {sys_ips[0]}{second}", f"به {sys_ips[0]} می‌رسد{second_fa}"), sys_ips


def _dg_ping(ip):
    """True / False, or None when ping is not available."""
    try:
        wait = "2" if sys.platform.startswith("linux") else "2000"
        r = subprocess.run(["ping", "-c", "1", "-W", wait, ip], capture_output=True, timeout=DG_STEP)
        return r.returncode == 0
    except subprocess.TimeoutExpired:
        return False
    except Exception:
        return None


def dg_stage_tcp(ip, port):
    t0 = time.time()
    try:
        s = socket.create_connection((ip, port), timeout=DG_STEP)
        s.close()
        ms = int((time.time() - t0) * 1000)
        return _st("tcp", "ok", "ok", f"TCP to {_addr(ip, port)} connects in {ms}ms", f"TCP به {_addr(ip, port)} در {ms}ms وصل شد")
    except ConnectionRefusedError:
        return _st("tcp", "fail", "refused", f"TCP to {_addr(ip, port)}: connection refused", f"TCP به {_addr(ip, port)}: اتصال رد شد")
    except Exception as e:
        ping = _dg_ping(ip)
        note = {True: "; the host answers ping", False: "; no ping reply either", None: ""}[ping]
        note_fa = {True: "؛ ولی به پینگ جواب می‌دهد", False: "؛ پینگ هم جواب نمی‌دهد", None: ""}[ping]
        kind = "timeout" if isinstance(e, (socket.timeout, TimeoutError)) else "error"
        what = "no answer" if kind == "timeout" else (str(e)[:60] or "failed")
        return _st("tcp", "fail", kind, f"TCP to {_addr(ip, port)}: {what}{note}",
                   f"TCP به {_addr(ip, port)}: {'بی‌جواب' if kind == 'timeout' else what}{note_fa}", ping=ping)


def _dg_quic_vn_probe():
    """A QUIC Initial-sized packet with an unknown version: a QUIC server must answer with a
    Version Negotiation packet (RFC 9000 6.1); no crypto needed. Salamander servers answer too."""
    pkt = bytes([0xC3]) + bytes.fromhex("1a2a3a4a") + b"\x08" + secrets.token_bytes(8) + b"\x08" + secrets.token_bytes(8)
    return pkt + b"\x00" * (1200 - len(pkt))


def dg_stage_udp(ip, port, proto, obfs=False):
    """Hysteria2 gets a QUIC version-negotiation probe; WireGuard ignores unknown packets, so a
    connected UDP socket only learns 'port closed' (ICMP unreachable). Silence proves nothing."""
    fam = socket.AF_INET6 if ":" in ip else socket.AF_INET
    s = socket.socket(fam, socket.SOCK_DGRAM)
    s.settimeout(0.7)
    try:
        s.connect((ip, port))
        d = b""
        for _ in range(3):  # a few tries: UDP gets lost, and salamander answers only some probes
            s.send(_dg_quic_vn_probe() if proto == "Hysteria2" else secrets.token_bytes(32))
            try:
                d = s.recv(2048)
                break
            except socket.timeout:
                continue
        if not d:
            raise socket.timeout()
        if len(d) > 5 and d[0] & 0x80 and d[1:5] == b"\0\0\0\0":
            return _st("udp", "ok", "answer", f"A QUIC server answers on UDP {_addr(ip, port)}",
                       f"یک سرور QUIC روی UDP {_addr(ip, port)} جواب می‌دهد")
        return _st("udp", "ok", "answer", f"The server answers on UDP {_addr(ip, port)}",
                   f"سرور روی UDP {_addr(ip, port)} جواب می‌دهد")
    except ConnectionRefusedError:
        return _st("udp", "fail", "closed", f"UDP {_addr(ip, port)}: port unreachable", f"UDP {_addr(ip, port)}: پورت بسته است")
    except Exception:
        ping = _dg_ping(ip)
        note = {True: " The host answers ping.", False: " No ping reply either.", None: ""}[ping]
        note_fa = {True: " سرور به پینگ جواب می‌دهد.", False: " پینگ هم جواب نمی‌دهد.", None: ""}[ping]
        if obfs:
            return _st("udp", "unknown", "silent", f"Can't be checked directly: salamander obfuscation hides the server from probes.{note}",
                       f"مستقیم قابل بررسی نیست: مبهم‌سازی salamander سرور را از تست پنهان می‌کند.{note_fa}", ping=ping)
        if proto == "Hysteria2":
            return _st("udp", "unknown", "silent", f"No answer to a QUIC probe on UDP {_addr(ip, port)}: QUIC may be filtered, or nothing listens.{note}",
                       f"به تست QUIC روی UDP {_addr(ip, port)} جوابی نیامد: شاید QUIC فیلتر باشد یا چیزی گوش ندهد.{note_fa}", ping=ping)
        return _st("udp", "unknown", "silent", f"Can't be checked directly: {proto} servers don't answer unknown packets.{note}",
                   f"مستقیم قابل بررسی نیست: سرور {proto} به بسته ناشناس جواب نمی‌دهد.{note_fa}", ping=ping)
    finally:
        s.close()


def dg_handshake(ip, port, sni, verify=False):
    """One TLS handshake: (result, info). result: ok | untrusted | alert | other (all mean the
    server answered) or reset | timeout | eof | tcp (cut or never reached)."""
    if verify:
        ctx = ssl.create_default_context()
    else:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    try:
        raw = socket.create_connection((ip, port), timeout=DG_STEP)
    except Exception as e:
        return "tcp", str(e)[:80]
    try:
        raw.settimeout(DG_STEP)
        with ctx.wrap_socket(raw, server_hostname=sni or None) as tls:
            der = tls.getpeercert(binary_form=True) or b""
            return "ok", hashlib.sha256(der).hexdigest().upper()
    except ssl.SSLCertVerificationError as e:
        return "untrusted", str(getattr(e, "verify_message", "") or e)[:80]
    except (ssl.SSLEOFError, ssl.SSLZeroReturnError) as e:
        return "eof", "closed during the handshake"
    except ssl.SSLError as e:
        msg = str(getattr(e, "reason", "") or e)
        if "EOF" in msg.upper():
            return "eof", "closed during the handshake"
        return ("alert" if "ALERT" in msg.upper() or "HANDSHAKE_FAILURE" in msg.upper() else "other"), msg[:80]
    except ConnectionResetError:
        return "reset", "connection reset"
    except (socket.timeout, TimeoutError):
        return "timeout", "no answer"
    except OSError as e:
        return "reset", str(e)[:80]
    except Exception as e:
        return "other", str(e)[:80]
    finally:
        try: raw.close()
        except Exception: pass

DG_REACHED = ("ok", "untrusted", "alert", "other")


def dg_stage_tls(ip, port, t, pin=""):
    sni = t["sni"]
    shown = sni or "(none)"
    r, info = dg_handshake(ip, port, sni)
    if r in ("ok", "untrusted"):
        extra = {}
        en, fa = f"Handshake with sni {shown} works", f"دست‌دهی با sni {shown} کار می‌کند"
        if t["tls"] == "tls":
            extra["sha"] = info
            if pin and re.sub(r"[^0-9A-F]", "", pin.upper()) != info:
                return _st("tls", "fail", "cert_changed", en + ", but the certificate differs from the pinned one",
                           fa + " ولی گواهی با گواهی پین‌شده فرق دارد", **extra)
            if t["insecure"] and not (pin or t["own_pin"]):
                v, _ = dg_handshake(ip, port, sni, verify=True)
                if v == "untrusted":
                    return _st("tls", "ok", "untrusted", en + "; the certificate is not publicly trusted",
                               fa + "؛ گواهی معتبر عمومی نیست", **extra)
        return _st("tls", "ok", "ok", en, fa, **extra)
    if r in ("alert", "other"):
        return _st("tls", "fail", "rejected", f"The server refused the handshake for sni {shown} ({info})",
                   f"سرور دست‌دهی با sni {shown} را رد کرد ({info})")
    if r == "tcp":
        return _st("tls", "unknown", "tcp", f"Couldn't connect again ({info})", f"اتصال دوباره برقرار نشد ({info})")
    cut = {"reset": "reset", "timeout": "no answer", "eof": "closed"}[r]
    if sni != DG_NEUTRAL_SNI:
        r2, _ = dg_handshake(ip, port, DG_NEUTRAL_SNI)
        if r2 in DG_REACHED:
            return _st("tls", "fail", "sni_blocked", f"Handshake with sni {shown}: {cut}; with {DG_NEUTRAL_SNI} the server answers",
                       f"دست‌دهی با sni {shown} قطع شد ولی با {DG_NEUTRAL_SNI} سرور جواب می‌دهد")
    return _st("tls", "fail", "blocked", f"Handshake with sni {shown}: {cut}, and with a neutral name too",
               f"دست‌دهی با sni {shown} قطع شد، با نام بی‌طرف هم همین‌طور")


def dg_stage_proxy(cid):
    if cid in config_errors:
        return _st("proxy", "fail", "rejected", config_errors[cid][:200], config_errors[cid][:200])
    with lock:
        r = db_conn.execute("SELECT ok, latency_ms, error, checked_at, ok_iran FROM checks WHERE config_id=? ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
        en_r = db_conn.execute("SELECT enabled FROM configs WHERE id=?", (cid,)).fetchone()
    if en_r is not None and not en_r["enabled"]:
        return _st("proxy", "unknown", "paused", "Paused: not probed", "متوقف است؛ تست نمی‌شود")
    if not r:
        return _st("proxy", "unknown", "none", "Not probed yet", "هنوز تست نشده")
    when_s = format_dur(max(0, int(time.time()) - r["checked_at"]))
    if r["ok"]:
        return _st("proxy", "ok", "ok", f"Last check passed {when_s} ago ({r['latency_ms']}ms)",
                   f"آخرین تست {when_s} پیش موفق بود ({r['latency_ms']}ms)")
    kind = "iran_only" if r["ok_iran"] == 1 else "fail"
    tail = "; the domestic test works" if kind == "iran_only" else ""
    return _st("proxy", "fail", kind, f"Last check failed {when_s} ago: {human_err(r['error'])}{tail}",
               f"آخرین تست {when_s} پیش ناموفق بود: {human_err(r['error'])}" + ("؛ تست داخلی کار می‌کند" if tail else ""))


def dg_control():
    """Can this box reach the probe URL's host directly? Cached for a minute. (ok, host)"""
    now = time.time()
    if now - _dg_control["at"] < 60:
        return _dg_control["ok"], _dg_control["host"]
    u = up.urlparse(get_settings().get("url") or DEF_SETTINGS["url"])
    host = u.hostname or "cp.cloudflare.com"
    port = u.port or (443 if u.scheme == "https" else 80)
    try:
        ip = _dg_timed(lambda: socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM))[0][4][0]
        socket.create_connection((ip, port), timeout=DG_STEP).close()
        ok = True
    except Exception:
        ok = False
    _dg_control.update(at=now, ok=ok, host=host)
    return ok, host


# ----- the verdict: a pure function of the stages, so it can be tested offline -----
def dg_verdict(stages, t, control_ok=True, probe_host="", caps_insecure=True, cert_dropped=False):
    """(cause key, args) for the stages of one diagnosis."""
    S = {s["key"]: s for s in stages}
    a = {"host": t["host"], "port": t["port"], "addr": _addr(t["host"], t["port"]), "sni": t["sni"] or "(none)",
         "proto": {"hysteria2": "Hysteria2", "wireguard": "WireGuard"}.get(t["proto"], t["proto"]), "probe": probe_host}
    k = lambda key: S.get(key, {}).get("kind")
    px = S.get("proxy", {})
    if k("proxy") == "rejected":
        return "rejected", a
    if px.get("status") == "ok":
        return "healthy", a
    direct_bad = any(S.get(x, {}).get("status") == "fail" for x in ("dns", "tcp", "tls")) or k("udp") == "silent"
    if direct_bad and not control_ok:
        return "net_limited", a
    if k("dns") == "poisoned":
        return "dns_poisoned", dict(a, ip=S["dns"].get("ip", ""))
    if k("dns") == "local":
        return "dns_local", a
    if k("dns") == "none":
        return "dns_none", a
    if k("tcp") == "refused":
        return "port_closed", a
    if k("tcp") in ("timeout", "error"):
        return ("ip_blocked" if S["tcp"].get("ping") else "no_answer"), a
    if k("tls") == "sni_blocked":
        return "sni_blocked", a
    if k("tls") == "blocked":
        return "tls_blocked", a
    if k("tls") == "rejected":
        return "tls_rejected", a
    if k("tls") == "cert_changed":
        return "cert_changed", a
    if k("udp") == "closed":
        return "udp_closed", a
    if k("proxy") == "iran_only":
        return "iran_only", a
    if k("tls") == "untrusted" and not caps_insecure:
        return "cert_untrusted", a
    if t["proto"] == "hysteria2" and cert_dropped and px.get("status") == "fail":
        return "hy2_cert", a
    if k("udp") == "silent" and px.get("status") == "fail":
        return "udp_unknown", a
    if px.get("status") == "fail":
        return "proxy_fails", a
    if k("proxy") == "none":
        return "not_probed", a
    return "unknown", a


def dg_cause_text(key, args, fa=False):
    c = DG_CAUSES.get(key, DG_CAUSES["unknown"])
    class _D(dict):
        def __missing__(self, k): return ""
    title, action = (c[2], c[3]) if fa else (c[0], c[1])
    return title.format_map(_D(args)), action.format_map(_D(args))


def diagnose(cid):
    """Run every stage for one config. Returns the stored record."""
    with lock:
        r = db_conn.execute("SELECT id, uri, cert_pin FROM configs WHERE id=?", (cid,)).fetchone()
    if not r:
        raise ValueError("config not found")
    stages = []
    try:
        t = dg_target(r["uri"])
    except Exception as e:
        t = None
        stages.append(_st("dns", "unknown", "parse", f"Can't read the link: {e}", f"لینک خوانده نشد: {e}"))
    if t:
        dns, ips = dg_stage_dns(t["host"], t["port"])
        stages.append(dns)
        if ips:
            ip = ips[0]
            if t["transport"] == "udp":
                stages.append(dg_stage_udp(ip, t["port"], {"hysteria2": "Hysteria2", "wireguard": "WireGuard"}[t["proto"]], t["obfs"]))
            else:
                tcp = dg_stage_tcp(ip, t["port"])
                stages.append(tcp)
                if t["tls"] and tcp["status"] == "ok":
                    stages.append(dg_stage_tls(ip, t["port"], t, r["cert_pin"] or ""))
    stages.append(dg_stage_proxy(cid))
    ctl_ok, ctl_host = True, ""
    if t and any(s["status"] != "ok" for s in stages[:-1]) and stages[-1]["status"] != "ok":
        ctl_ok, ctl_host = dg_control()
    if t:
        cause, args = dg_verdict(stages, t, ctl_ok, ctl_host, CAPS["insecure"], insecure_dropped(r["uri"]))
    else:
        cause, args = ("rejected" if stages[-1]["kind"] == "rejected" else "unknown"), {}
    return {"config_id": cid, "ran_at": int(time.time()), "cause": cause, "args": args, "stages": stages}


def dg_store(rec, auto=False):
    """Save the latest diagnosis and put its verdict on the open incident. Returns that incident or None."""
    en, _ = dg_cause_text(rec["cause"], rec["args"])
    with lock:
        inc = db_conn.execute("SELECT id, started_at FROM incidents WHERE config_id=? AND resolved_at IS NULL ORDER BY id DESC LIMIT 1",
                              (rec["config_id"],)).fetchone()
        db_conn.execute("INSERT OR REPLACE INTO diagnoses (config_id, ran_at, cause, args, stages, auto, incident_id) VALUES (?,?,?,?,?,?,?)",
                        (rec["config_id"], rec["ran_at"], rec["cause"], json.dumps(rec["args"], ensure_ascii=False),
                         json.dumps(rec["stages"], ensure_ascii=False), 1 if auto else 0, inc["id"] if inc else None))
        if inc:
            db_conn.execute("UPDATE incidents SET diag_verdict=? WHERE id=?", ("Likely: " + en, inc["id"]))
        db_conn.commit()
    return dict(inc) if inc else None


def dg_get(cid):
    with lock:
        r = db_conn.execute("SELECT * FROM diagnoses WHERE config_id=?", (cid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["args"] = json.loads(d["args"] or "{}")
    d["stages"] = json.loads(d["stages"] or "[]")
    return d


def dg_alert(rec, inc):
    """Queue a short follow-up to the outage alert (same rules as the outage alert itself)."""
    s = get_settings()
    with lock:
        c = db_conn.execute("SELECT name, addr, muted FROM configs WHERE id=?", (rec["config_id"],)).fetchone()
        still = db_conn.execute("SELECT 1 FROM incidents WHERE id=? AND resolved_at IS NULL", (inc["id"],)).fetchone()
    if (not c or not still or c["muted"] or s.get("notify_down", "1") != "1" or rec["cause"] in ("healthy", "net_limited")
            or rec["ran_at"] - inc["started_at"] > DG_ALERT_WINDOW):
        return False
    title, action = dg_cause_text(rec["cause"], rec["args"], fa=True)
    msg = (f"🔎 <b>عیب‌یابی قطعی | Diagnosis</b>\n"
           f"📡 <b>نام نود:</b> <code>{H(c['name'])}</code>\n"
           f"🧭 <b>علت احتمالی:</b> {H(title)}\n"
           f"💡 <b>پیشنهاد:</b> {H(action)}\n"
           f"<i>نتیجه تخمینی است و از همین سرور، بدون پروکسی، بررسی شده.</i>")
    with lock:
        db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (msg, int(time.time())))
        db_conn.commit()
    return True


def dg_running(cid):
    with _dg_lock:
        return cid in _dg_running


def dg_start(cid, auto=False, on_done=None):
    """Diagnose one config in the background. False when one is already running for it."""
    with _dg_lock:
        if cid in _dg_running:
            return False
        _dg_running[cid] = time.time()
    def job():
        rec = None
        try:
            with _dg_sem:
                rec = diagnose(cid)
                inc = dg_store(rec, auto)
            if auto and inc:
                dg_alert(rec, inc)
        except Exception as e:
            print(f"diagnosis {cid} failed: {e}", flush=True)
        finally:
            with _dg_lock:
                _dg_running.pop(cid, None)
            if on_done:
                try: on_done(rec)
                except Exception as e: print("diagnosis callback failed:", e, flush=True)
    threading.Thread(target=job, daemon=True).start()
    return True


# ----- certificate pinning -----
def fetch_cert_sha256(host, port, sni):
    """SHA-256 of the certificate the server presents now (no verification), uppercase hex, and
    whether it is publicly trusted."""
    ip = host if _dg_is_ip(host) else _dg_timed(lambda: socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM))[0][4][0]
    if ip != host and _dg_bogon(ip):
        # A filter's answer (e.g. 10.10.34.35) may well speak TLS: pinning it would trust the filter.
        raise ValueError(f"{host} resolves to {ip}, which looks poisoned or private; fix DNS first")
    r, info = dg_handshake(ip, port, sni)
    if r != "ok":
        raise ValueError({"tcp": "can't connect", "reset": "connection reset during the handshake",
                          "timeout": "no answer to the handshake", "eof": "closed during the handshake"}.get(r, info))
    trusted = dg_handshake(ip, port, sni, verify=True)[0] == "ok"
    return info, trusted


def dg_set_pin(cid, sha):
    with lock:
        r = db_conn.execute("SELECT uri FROM configs WHERE id=?", (cid,)).fetchone()
        if not r:
            return False
        db_conn.execute("UPDATE configs SET cert_pin=?, cert_pin_at=? WHERE id=?", (sha, int(time.time()) if sha else None, cid))
        db_conn.commit()
        if sha:
            CERT_PINS[r["uri"]] = sha
        else:
            CERT_PINS.pop(r["uri"], None)
    return True


def dg_pin_now(cid):
    """Fetch and store the pin for one config (blocking). Returns (ok, message)."""
    with lock:
        r = db_conn.execute("SELECT uri FROM configs WHERE id=?", (cid,)).fetchone()
    if not r:
        return False, "Config not found"
    t = dg_target(r["uri"])
    if not dg_pin_eligible(t):
        return False, "Only TLS links with insecure=1 and no pin of their own can be pinned"
    sha, trusted = fetch_cert_sha256(t["host"], t["port"], t["sni"])
    dg_set_pin(cid, sha)
    return True, ("trusted" if trusted else "")


def dg_pin_start(cid, on_done=None):
    with _dg_lock:
        if (_dg_pin_jobs.get(cid) or {}).get("running"):
            return False
        _dg_pin_jobs[cid] = {"running": True, "error": "", "note": "", "at": int(time.time())}
    def job():
        res = {"running": False, "error": "", "note": "", "at": int(time.time())}
        try:
            ok, msg = dg_pin_now(cid)
            if ok:
                res["note"] = msg
                restart_xray()
                wake.set()
            else:
                res["error"] = msg
        except Exception as e:
            res["error"] = f"Couldn't fetch the certificate: {e}"[:200]
        with _dg_lock:
            _dg_pin_jobs[cid] = res
        if on_done:
            try: on_done(res)
            except Exception as e: print("pin callback failed:", e, flush=True)
    threading.Thread(target=job, daemon=True).start()
    return True


def dg_unpin(cid):
    if not dg_set_pin(cid, ""):
        return False
    with _dg_lock:
        _dg_pin_jobs.pop(cid, None)
    restart_xray()
    wake.set()
    return True


def dg_auto_pin(cfgs):
    """Pin certificates of links that need it (Xray refuses insecure=1 and the certificate is not
    publicly trusted). Runs in its own thread; one Xray restart for the whole batch."""
    pinned = 0
    for c in cfgs:
        try:
            t = dg_target(c["uri"])
            sha, trusted = fetch_cert_sha256(t["host"], t["port"], t["sni"])
            if not trusted:
                dg_set_pin(c["id"], sha)
                pinned += 1
        except Exception as e:
            print(f"auto pin {c['id']}: {e}", flush=True)
    if pinned:
        print(f"auto pin: pinned {pinned} certificate(s)", flush=True)
        restart_xray()
        wake.set()


def _dg_tick(s):
    """After a probe round: diagnose new outages once, and pin certificates if asked to."""
    now = time.time()
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT i.id, i.config_id FROM incidents i JOIN configs c ON c.id = i.config_id
            WHERE i.resolved_at IS NULL AND i.diag_verdict IS NULL AND c.enabled = 1
            ORDER BY i.started_at DESC LIMIT 30""")]
    with _dg_lock:
        free = DG_PARALLEL - len(_dg_running)
    for r in rows:
        if free <= 0:
            break
        if r["id"] in _dg_tried_inc:
            continue
        _dg_tried_inc.add(r["id"])
        if dg_start(r["config_id"], auto=True):
            free -= 1
    if s.get("auto_pin") == "1" and not CAPS["insecure"]:
        with lock:
            cfgs = [dict(r) for r in db_conn.execute("SELECT id, uri FROM configs WHERE enabled=1 AND (cert_pin IS NULL OR cert_pin='')")]
        todo = []
        for c in cfgs:
            try:
                ok = dg_pin_eligible(dg_target(c["uri"]))
            except Exception:
                ok = False
            if ok and now - _dg_autopin_tried.get(c["id"], 0) > 6 * 3600:
                _dg_autopin_tried[c["id"]] = now
                todo.append(c)
                if len(todo) >= 5:
                    break
        if todo:
            threading.Thread(target=dg_auto_pin, args=(todo,), daemon=True).start()
    if int(now) % 3600 < max(2, int(s.get("interval", 30))):
        with lock:
            db_conn.execute("DELETE FROM diagnoses WHERE config_id NOT IN (SELECT id FROM configs)")
            db_conn.commit()
TICK_HOOKS.append(_dg_tick)


def dg_pin_info(cid):
    with lock:
        r = db_conn.execute("SELECT uri, cert_pin, cert_pin_at FROM configs WHERE id=?", (cid,)).fetchone()
    if not r:
        return None
    try:
        t = dg_target(r["uri"])
    except Exception:
        t = None
    with _dg_lock:
        job = dict(_dg_pin_jobs.get(cid) or {})
    return {"eligible": dg_pin_eligible(t), "own_pin": bool(t and t["own_pin"]), "sha": r["cert_pin"] or "",
            "at": r["cert_pin_at"], "running": bool(job.get("running")), "error": job.get("error", ""),
            "note": job.get("note", ""), "xray_insecure": CAPS["insecure"]}


# ----- web API -----
def dg_reply(cid):
    d = dg_get(cid)
    if d:
        d["title"], d["action"] = dg_cause_text(d["cause"], d["args"])
        d["stages"] = [{"key": s["key"], "name": DG_STAGE_NAMES.get(s["key"], (s["key"],))[0], "status": s["status"], "detail": s["en"]}
                       for s in d["stages"]]
        d.pop("args", None)
    return {"config_id": cid, "running": dg_running(cid), "diag": d, "pin": dg_pin_info(cid)}


def _dg_id(h, b, qs):
    cid = str(b.get("id", "") or qs.get("id", [""])[0])
    with lock:
        ok = db_conn.execute("SELECT 1 FROM configs WHERE id=?", (cid,)).fetchone()
    return cid if ok else None


def api_diag(h, method, b, qs):
    cid = _dg_id(h, b, qs)
    if not cid:
        return h.out(404, {"error": "Config not found"})
    return h.out(200, dg_reply(cid))


def api_diag_run(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    cid = _dg_id(h, b, qs)
    if not cid:
        return h.out(404, {"error": "Config not found"})
    dg_start(cid)
    return h.out(200, dg_reply(cid))


def api_diag_pin(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    cid = _dg_id(h, b, qs)
    if not cid:
        return h.out(404, {"error": "Config not found"})
    if str(b.get("remove", "")) in ("1", "true", "True"):
        dg_unpin(cid)
        return h.out(200, dg_reply(cid))
    info = dg_pin_info(cid)
    if not info["eligible"]:
        return h.out(400, {"error": "Only TLS links with insecure=1 and no pin of their own can be pinned"})
    dg_pin_start(cid)
    return h.out(200, dg_reply(cid))

API_ROUTES.update({"diag": api_diag, "diag/run": api_diag_run, "diag/pin": api_diag_pin})


# ----- Telegram bot -----
DG_ICON = {"ok": "✅", "fail": "❌", "unknown": "❔"}


def _dg_ago(ts):
    return format_dur(max(0, int(time.time()) - int(ts or 0))) + " پیش"


def scr_diag(cid, head=""):
    with lock:
        c = db_conn.execute("SELECT name FROM configs WHERE id=?", (cid,)).fetchone()
    if not c:
        return "این کانفیگ دیگر وجود ندارد.", kb([("« کانفیگ‌ها", "cl:0:a")])
    d, pin, running = dg_get(cid), dg_pin_info(cid), dg_running(cid)
    lines = ([head, ""] if head else []) + [f"🔎 <b>عیب‌یابی {H(c['name'])}</b>", ""]
    if running:
        lines.append("⏳ در حال بررسی… (تا حدود ۲۰ ثانیه)")
    if d:
        title, action = dg_cause_text(d["cause"], d["args"], fa=True)
        lines += [f"🧭 علت احتمالی: <b>{H(title)}</b>", f"💡 {H(action)}", ""]
        for s in d["stages"]:
            lines.append(f"{DG_ICON.get(s['status'], '❔')} {DG_STAGE_NAMES.get(s['key'], (s['key'], s['key']))[1]}: {H(s['fa'])}")
        lines += ["", f"🕒 {_dg_ago(d['ran_at'])}" + (" · خودکار" if d.get("auto") else "") + " · از همین سرور، بدون پروکسی"]
    elif not running:
        lines.append("هنوز عیب‌یابی نشده.")
    rows = [[("🔄 اجرای دوباره" if d else "🔎 شروع عیب‌یابی", f"dg:r:{cid}")]]
    if pin and pin["eligible"]:
        if pin["sha"]:
            lines.append(f"\n📌 گواهی پین شده: <code>{H(pin['sha'][:16])}…</code>")
            rows.append([("🔁 پین دوباره", f"dg:p:{cid}"), ("✖ حذف پین", f"dg:u:{cid}")])
        else:
            lines.append("\n📌 این لینک insecure=1 دارد" + ("؛ Xray نصب‌شده این را قبول نمی‌کند و گواهی خودامضا رد می‌شود." if not pin["xray_insecure"] else "."))
            rows.append([("📌 پین گواهی", f"dg:p:{cid}")])
        if pin["error"]:
            lines.append(f"⚠️ {H(pin['error'])}")
    rows.append([("« کانفیگ", f"c:{cid}")])
    return "\n".join(lines), kb(*rows)


def scr_autopin():
    on = get_settings().get("auto_pin", "0") == "1"
    text = ("📌 <b>پین خودکار گواهی</b>\n\n"
            f"وضعیت: <b>{'روشن' if on else 'خاموش'}</b>\n\n"
            "Xray جدید insecure=1 را قبول نمی‌کند. با روشن کردن این گزینه، Sentinel گواهی‌ای را که سرورِ لینک‌های "
            "TLS با insecure=1 همین الان نشان می‌دهد پین می‌کند (فقط اگر گواهی معتبر عمومی نباشد).\n\n"
            "⚠️ ریسک: به اولین گواهی‌ای که می‌بیند اعتماد می‌کند. اگر همان لحظه کسی وسط راه باشد، گواهی او پین می‌شود. "
            "اگر گواهی سرور عوض شود، تست‌ها خطا می‌دهند تا دوباره پین کنید.")
    return text, kb([("🔕 خاموش کن" if on else "✅ روشن کن", "dg:at")], [("« تنظیمات", "set")])


def tg_dg(args, uid, chat_id, msg_id, cb_id, show):
    act = args[0] if args else ""
    cid = args[1] if len(args) > 1 else ""
    if act == "as":
        return show(scr_autopin())
    if act == "at":
        on = get_settings().get("auto_pin", "0") == "1"
        svc_apply_settings({"auto_pin": "0" if on else "1"})
        tg_toast(cb_id, "خاموش شد" if on else "روشن شد")
        return show(scr_autopin())
    done = lambda _r=None: tg_show(chat_id, scr_diag(cid), msg_id)
    if act == "v":
        if not dg_get(cid) and dg_start(cid, on_done=done):
            tg_toast(cb_id, "عیب‌یابی شروع شد")
        return show(scr_diag(cid))
    if act == "r":
        started = dg_start(cid, on_done=done)
        tg_toast(cb_id, "عیب‌یابی شروع شد" if started else "در حال اجراست…")
        return show(scr_diag(cid))
    if act == "p":
        info = dg_pin_info(cid)
        if not info or not info["eligible"]:
            return tg_toast(cb_id, "این لینک قابل پین نیست", alert=True)
        def pinned(res):
            head = ("❌ پین نشد: " + H(res["error"])) if res["error"] else ("📌 گواهی پین شد." + (
                " توجه: این گواهی معتبر عمومی است و با تمدید، پین از کار می‌افتد." if res["note"] == "trusted" else ""))
            tg_show(chat_id, scr_diag(cid, head), msg_id)
        dg_pin_start(cid, on_done=pinned)
        tg_toast(cb_id, "در حال گرفتن گواهی…")
        return show(scr_diag(cid, "⏳ در حال گرفتن گواهی سرور…"))
    if act == "u":
        dg_unpin(cid)
        tg_toast(cb_id, "پین حذف شد")
        return show(scr_diag(cid))
    return tg_toast(cb_id)

TG_ROUTES["dg"] = tg_dg
TG_SETTINGS_ROWS.append([("📌 پین خودکار گواهی", "dg:as")])


def _dg_lines(c):
    d = dg_get(c["id"])
    out = []
    if d and (c["state"] in ("down", "iran_only", "fail") or time.time() - d["ran_at"] < 3600):
        title, _ = dg_cause_text(d["cause"], d["args"], fa=True)
        out.append(f"🔎 علت احتمالی: <b>{H(title)}</b> ({_dg_ago(d['ran_at'])})")
    if c.get("uri") in CERT_PINS:
        out.append("📌 گواهی پین شده")
    return out


def _dg_rows(c):
    return [[("🔎 عیب‌یابی", f"dg:v:{c['id']}")]]

TG_CONFIG_LINES.append(_dg_lines)
TG_CONFIG_ROWS.append(_dg_rows)


# ----- selftest (offline) -----
def _dg_selftest():
    tv = dg_target("vless://11111111-1111-1111-1111-111111111111@1.2.3.4:443?type=ws&security=tls&sni=a.example&allowInsecure=1#v")
    assert tv["transport"] == "tcp" and tv["tls"] == "tls" and tv["sni"] == "a.example" and dg_pin_eligible(tv)
    assert not dg_pin_eligible(dg_target("trojan://pw@t.example:443?security=tls&sni=t.example&allowInsecure=1&pcs=AB#t"))
    assert dg_target("hy2://pw@h.example:443?sni=h.example#h")["transport"] == "udp"
    vm = "vmess://" + base64.b64encode(json.dumps({"add": "v.example", "port": 443, "id": "11111111-1111-1111-1111-111111111111",
                                                   "net": "ws", "tls": "tls", "sni": "s.example", "allowInsecure": True}).encode()).decode()
    tvm = dg_target(vm)
    assert tvm["sni"] == "s.example" and dg_pin_eligible(tvm)
    assert dg_target("vless://11111111-1111-1111-1111-111111111111@r.example:443?security=reality&sni=www.apple.com&pbk=x#r")["tls"] == "reality"
    assert _dg_bogon("10.10.34.35") and _dg_bogon("192.168.1.1") and not _dg_bogon("8.8.8.8")
    T = dg_target("trojan://pw@t.example:443?security=tls&sni=t.example#t")
    ok = lambda k, kind="ok", **kw: _st(k, "ok", kind, "", "", **kw)
    bad = lambda k, kind, **kw: _st(k, "fail", kind, "", "", **kw)
    pfail = bad("proxy", "fail")
    V = lambda *st, **kw: dg_verdict(list(st), T, **kw)[0]
    assert V(ok("dns"), ok("tcp"), ok("tls"), ok("proxy")) == "healthy"
    assert V(bad("dns", "poisoned", ip="10.10.34.35"), ok("tcp"), pfail) == "dns_poisoned"
    assert V(bad("dns", "none"), pfail) == "dns_none"
    assert V(ok("dns"), bad("tcp", "refused"), pfail) == "port_closed"
    assert V(ok("dns"), bad("tcp", "timeout", ping=True), pfail) == "ip_blocked"
    assert V(ok("dns"), bad("tcp", "timeout", ping=False), pfail) == "no_answer"
    assert V(ok("dns"), bad("tcp", "timeout", ping=False), pfail, control_ok=False) == "net_limited"
    assert V(ok("dns"), ok("tcp"), bad("tls", "sni_blocked"), pfail) == "sni_blocked"
    assert V(ok("dns"), ok("tcp"), bad("tls", "blocked"), pfail) == "tls_blocked"
    assert V(ok("dns"), ok("tcp"), bad("tls", "cert_changed"), pfail) == "cert_changed"
    assert V(ok("dns"), ok("tcp"), ok("tls", "untrusted"), pfail, caps_insecure=False) == "cert_untrusted"
    assert V(ok("dns"), ok("tcp"), ok("tls"), pfail) == "proxy_fails"
    assert V(ok("dns"), ok("tcp"), ok("tls"), bad("proxy", "iran_only")) == "iran_only"
    assert V(ok("dns"), bad("proxy", "rejected")) == "rejected"
    assert V(ok("dns"), _st("udp", "unknown", "silent", "", ""), pfail) == "udp_unknown"
    assert V(ok("dns"), bad("udp", "closed"), pfail) == "udp_closed"
    H2 = dg_target("hy2://pw@h.example:443?sni=h.example&insecure=1#h")
    silent = _st("udp", "unknown", "silent", "", "")
    assert dg_verdict([ok("dns"), silent, pfail], H2, cert_dropped=True)[0] == "hy2_cert"
    assert dg_verdict([ok("dns"), silent, pfail], H2)[0] == "udp_unknown"
    assert dg_verdict([ok("dns"), silent, ok("proxy")], H2, cert_dropped=True)[0] == "healthy"
    for k in DG_CAUSES:
        en, fa = dg_cause_text(k, {"host": "h", "port": 1}), dg_cause_text(k, {}, fa=True)
        assert en[0] and en[1] and fa[0] and fa[1], k
    # A stored pin goes into the outbound as pinnedPeerCertSha256 and silences the insecure hint.
    u = "trojan://pw@t.example:443?security=tls&sni=t.example&allowInsecure=1#pin"
    CERT_PINS[u] = "AB" * 32
    try:
        caps = CAPS["insecure"]; CAPS["insecure"] = False
        ts = outbound_for({"id": "p", "uri": u})["streamSettings"]["tlsSettings"]
        assert ts["pinnedPeerCertSha256"] == "AB" * 32 and "allowInsecure" not in ts
        assert not insecure_dropped(u)
        own = u.replace("#pin", "&pcs=CD#pin")
        CERT_PINS[own] = "AB" * 32
        assert outbound_for({"id": "p", "uri": own})["streamSettings"]["tlsSettings"]["pinnedPeerCertSha256"] == "CD"
    finally:
        CAPS["insecure"] = caps
        CERT_PINS.pop(u, None); CERT_PINS.pop(u.replace("#pin", "&pcs=CD#pin"), None)
    assert all(len(f"dg:{a}:{'f' * 8}".encode()) <= 64 for a in ("v", "r", "p", "u"))
SELFTESTS.append(_dg_selftest)



# ---------- Feature: alert channels ----------
# Telegram is blocked in Iran and reached only through a healthy config, so when every config is down
# no Telegram alert gets out. Bale (an Iranian messenger with a Telegram-like Bot API) and a webhook are
# sent straight from this server instead. Each channel has a mode:
#   off       never used
#   fallback  an alert goes there only when Telegram delivery failed (no token, or every route failed)
#   always    every alert also goes there
# The "everything is down" alert goes to every channel that is not off, whatever Telegram did.
# Bale Bot API, from https://docs.bale.ai/ : https://tapi.bale.ai/bot<token>/METHOD; sendMessage has no
# parse_mode (text is read as Markdown), so Bale gets plain text; sendDocument takes a multipart
# "document" upload of up to 50 MB.
import urllib.request as _ur, urllib.error as _ue

BALE_BASE = "https://tapi.bale.ai"   # tests point this at a local fake server
AL_CHANNELS = ("bale", "webhook")
AL_MODES = ("off", "fallback", "always")
AL_TIMEOUT = 8                 # seconds per send; channels are direct, so they answer fast or not at all
AL_QUEUE_MAX = 200             # pending alerts kept at most (the newest)
AL_QUEUE_TTL = 3 * 86400       # an alert nobody took in 3 days is dropped
AL_DOC_MAX = 50 * 1024 * 1024  # Bale's sendDocument limit
DEF_SETTINGS.update({"bale_token": "", "bale_chat": "", "bale_mode": "fallback",
                     "webhook_url": "", "webhook_secret": "", "webhook_mode": "fallback",
                     "notify_all_down": "1",
                     # The database holds every config link, the password hash and all tokens, so it
                     # only goes to Bale when the user turns this on.
                     "bale_backup": "0"})
SECRET_SETTINGS.update({"bale_token", "webhook_url", "webhook_secret"})
NOTIFY_FLAGS = NOTIFY_FLAGS + ("notify_all_down", "bale_backup")   # 0/1 handling and the bot's nt: toggle


def _al_rule_bale_token(v):
    v = str(v).strip()
    if not re.fullmatch(r"[A-Za-z0-9:_-]{10,200}", v):
        raise ValueError("Invalid Bale bot token format")
    return v

def _al_rule_bale_chat(v):
    v = str(v).strip()
    if v in ("", "-"):
        return ""
    if not re.fullmatch(r"-?\d{1,20}|@\w{3,64}", v):
        raise ValueError("Bale chat ID must be a number or @channel")
    return v

def _al_rule_webhook_url(v):
    v = str(v).strip()
    try:
        p = up.urlparse(v)
        ok = p.scheme in ("http", "https") and bool(p.hostname)
    except ValueError:
        ok = False
    if not ok or len(v) > 1000 or re.search(r"[\s\"'<>]", v):
        raise ValueError("Webhook URL must start with http:// or https://")
    return v

def _al_rule_webhook_secret(v):
    v = str(v).strip()
    if len(v) > 256 or re.search(r"[\r\n]", v):
        raise ValueError("Webhook secret must be one line of at most 256 characters")
    return v

def _al_rule_mode(v):
    v = str(v).strip().lower()
    if v not in AL_MODES:
        raise ValueError("Mode must be off, fallback or always")
    return v

SETTING_RULES.update({"bale_token": _al_rule_bale_token, "bale_chat": _al_rule_bale_chat,
                      "webhook_url": _al_rule_webhook_url, "webhook_secret": _al_rule_webhook_secret,
                      "bale_mode": _al_rule_mode, "webhook_mode": _al_rule_mode})


def _al_migrate(conn):
    cols = [r[1] for r in conn.execute("PRAGMA table_info(pending_alerts)")]
    if "al_event" not in cols:
        conn.execute("ALTER TABLE pending_alerts ADD COLUMN al_event TEXT DEFAULT ''")
    if "al_cfg" not in cols:
        conn.execute("ALTER TABLE pending_alerts ADD COLUMN al_cfg TEXT DEFAULT ''")
    if "al_direct" not in cols:   # 1 = goes to every channel that is not off, even when Telegram took it
        conn.execute("ALTER TABLE pending_alerts ADD COLUMN al_direct INTEGER DEFAULT 0")

MIGRATIONS.append(_al_migrate)


def _al_meta_set(k, v):
    with lock:
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (k, str(v)))
        db_conn.commit()

def al_configured(ch, s):
    if ch == "bale":
        return bool(s.get("bale_token") and s.get("bale_chat"))
    return bool(s.get("webhook_url"))

def al_mode(ch, s):
    m = s.get(ch + "_mode", "fallback")
    return m if m in AL_MODES else "fallback"

def al_status(ch):
    """The last send to this channel: {"ok", "error", "at"}, or {} when nothing was sent yet."""
    try:
        return json.loads(get_meta("al_status_" + ch) or "{}")
    except ValueError:
        return {}

def _al_set_status(ch, ok, err=""):
    _al_meta_set("al_status_" + ch, json.dumps({"ok": bool(ok), "error": "" if ok else str(err)[:200], "at": int(time.time())}))

def _al_scrub(text, *hide):
    t = str(text or "")
    for x in hide:
        if x and len(x) > 2:
            t = t.replace(x, "…")
    return t[:200]

def al_plain(html_text):
    """Bot HTML to plain text: drop the tags first, then unescape, so an escaped <b> in a name stays text."""
    t = re.sub(r"<br\s*/?>", "\n", str(html_text or ""))
    t = re.sub(r"</?[A-Za-z][^<>]*>", "", t)
    return _html.unescape(t).strip()


# ----- Bale -----
def _al_curl_err(err):
    t = str(err or "").strip()
    for pat, msg in ((r"\(28\)|timed out", "No answer before the timeout"),
                     (r"\(6\)|resolve", "Could not resolve the address"),
                     (r"\(7\)|Couldn't connect|Failed to connect", "Could not connect"),
                     (r"\(35\)|\(60\)|SSL|TLS|certificate", "TLS handshake failed"),
                     (r"\(56\)|reset by peer", "The server closed the connection")):
        if re.search(pat, t, re.I):
            return msg
    return t

def bale_api(method, params, doc=None, s=None, timeout=AL_TIMEOUT):
    """Call the Bale Bot API directly (no proxy). Returns (reply or None, error text).
    The token travels on stdin (curl -K) so it never shows in the process list."""
    s = s or get_settings()
    tok = s.get("bale_token", "")
    if not tok:
        return None, "No Bale bot token"
    lines = [f"url = {_curl_q(f'{BALE_BASE}/bot{tok}/{method}')}"]
    for k, v in (params or {}).items():
        lines.append(f"form-string = {_curl_q(f'{k}={v}')}")
    if doc:
        lines.append(f"form = {_curl_q('document=@' + doc[0] + ';filename=' + doc[1])}")
    cmd = ["curl", "-sS", "--connect-timeout", "5", "--max-time", str(timeout), "-K", "-"]
    try:
        r = subprocess.run(cmd, input="\n".join(lines) + "\n", capture_output=True, text=True, timeout=timeout + 5)
    except Exception as e:
        return None, _al_scrub(f"Could not run curl: {e}", tok)
    try:
        res = json.loads(r.stdout)
    except ValueError:
        return None, _al_scrub(_al_curl_err(r.stderr) or "No answer from Bale", tok)
    if not isinstance(res, dict):
        return None, "Bale sent an answer Sentinel does not understand"
    if res.get("ok"):
        return res, ""
    return res, _al_scrub(f"Bale refused it: {res.get('description') or res.get('error_code') or 'no reason given'}", tok)

def al_send_bale(text_html, s):
    res, err = bale_api("sendMessage", {"chat_id": s.get("bale_chat", ""), "text": al_plain(text_html)[:4096]}, s=s)
    return bool(res and res.get("ok")), err

def al_bale_send_db(caption, s=None):
    s = s or get_settings()
    with lock:
        db_conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    try:
        size = os.path.getsize(DB_FILE)
    except OSError:
        size = 0
    if size > AL_DOC_MAX:
        ok, err = False, "The database is larger than Bale's 50 MB file limit"
    else:
        res, err = bale_api("sendDocument", {"chat_id": s.get("bale_chat", ""), "caption": caption},
                            doc=(DB_FILE, "sentinel.db"), s=s, timeout=60)
        ok = bool(res and res.get("ok"))
    _al_set_status("bale", ok, err)
    return ok, err


# ----- webhook -----
class _AlNoRedirect(_ur.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None   # a redirect counts as a failure; the body is never re-sent elsewhere

def al_webhook_body(event, text_html, config=None, at=None):
    payload = {"event": event, "text": al_plain(text_html), "html": text_html, "at": int(at or time.time())}
    if config:
        payload["config"] = config
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")

def al_signature(secret, body):
    return "sha256=" + hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()

def al_send_webhook(event, text_html, s, config=None):
    url = s.get("webhook_url", "")
    if not url:
        return False, "No webhook URL"
    body = al_webhook_body(event, text_html, config)
    headers = {"Content-Type": "application/json; charset=utf-8", "User-Agent": "Sentinel", "X-Sentinel-Event": event}
    if s.get("webhook_secret"):
        headers["X-Sentinel-Signature"] = al_signature(s["webhook_secret"], body)
    try:
        p = up.urlparse(url)
        hide = (url, p.netloc, p.hostname or "", p.path, p.query)
    except ValueError:
        hide = (url,)
    try:
        with _ur.build_opener(_AlNoRedirect).open(_ur.Request(url, data=body, headers=headers, method="POST"), timeout=AL_TIMEOUT) as r:
            code = r.status
    except _ue.HTTPError as e:
        code = e.code
    except Exception as e:
        reason = getattr(e, "reason", e)
        msg = "No answer before the timeout" if "timed out" in str(reason) else f"Could not reach the webhook: {reason}"
        return False, _al_scrub(msg, *hide)
    if 200 <= code < 300:
        return True, ""
    return False, f"The webhook answered HTTP {code}"


# ----- delivery -----
def al_send(ch, event, text_html, s=None, config=None):
    """Send one message to one channel and remember how it went."""
    s = s or get_settings()
    try:
        ok, err = al_send_bale(text_html, s) if ch == "bale" else al_send_webhook(event, text_html, s, config)
    except Exception as e:
        ok, err = False, _al_scrub(str(e), s.get("bale_token", ""), s.get("webhook_url", ""))
    _al_set_status(ch, ok, err)
    return ok, err

AL_EVENT_BY_ICON = (("🔴", "down"), ("🟢", "recover"), ("⏳", "reminder"))

def _al_row_meta(r):
    """Event name and config for a queued alert. tick() queues plain text, so read them from it."""
    text = r["text"]
    event = r.get("al_event") or next((e for ic, e in AL_EVENT_BY_ICON if text.startswith(ic)), "alert")
    if r.get("al_cfg"):
        try:
            return event, json.loads(r["al_cfg"])
        except ValueError:
            pass
    m = re.search(r"<code>(.*?)</code>", text)
    if event in ("down", "recover", "reminder") and m:
        with lock:
            rows = db_conn.execute("SELECT id, name FROM configs WHERE name=?", (_html.unescape(m.group(1)),)).fetchall()
        if len(rows) == 1:
            st = "up" if event == "recover" else ("iran_only" if "Intranet Only" in text else "down")
            return event, {"id": rows[0]["id"], "name": rows[0]["name"], "state": st}
    return event, None

def al_deliver(text, s, dead, event="alert", config=None, direct=False):
    """Try Telegram, then the channels its mode allows. A channel that failed is put in `dead` and
    skipped for the rest of this round, so one dead channel costs one timeout, not one per alert.
    Returns the channels that took it."""
    took = []
    tg = False
    if "telegram" not in dead:
        tg = bool(send_telegram(text))
        if tg:
            took.append("telegram")
        else:
            dead.add("telegram")
    for ch in AL_CHANNELS:
        if ch in dead or not al_configured(ch, s):
            continue
        mode = al_mode(ch, s)
        if mode == "off" or (mode == "fallback" and tg and not direct):
            continue
        ok, _ = al_send(ch, event, text, s, config)
        if ok:
            took.append(ch)
        else:
            dead.add(ch)
    return took

_al_flush_lock = threading.Lock()

def al_flush():
    """flush_alerts(): send queued alerts oldest first ("everything is down" ones first). An alert is
    done once any channel took it. When none did, stop and retry on the next round."""
    with _al_flush_lock:
        s = get_settings()
        now = int(time.time())
        with lock:
            db_conn.execute("DELETE FROM pending_alerts WHERE created_at < ?", (now - AL_QUEUE_TTL,))
            db_conn.execute("DELETE FROM pending_alerts WHERE id NOT IN (SELECT MIN(id) FROM pending_alerts GROUP BY text)")
            db_conn.execute("DELETE FROM pending_alerts WHERE id NOT IN (SELECT id FROM pending_alerts ORDER BY id DESC LIMIT ?)", (AL_QUEUE_MAX,))
            rows = [dict(r) for r in db_conn.execute(
                "SELECT * FROM pending_alerts ORDER BY COALESCE(al_direct, 0) DESC, id ASC LIMIT 10").fetchall()]
            db_conn.commit()
        dead = set()
        for r in rows:
            event, cfg = _al_row_meta(r)
            if not al_deliver(r["text"], s, dead, event, cfg, bool(r.get("al_direct"))):
                break
            with lock:
                db_conn.execute("DELETE FROM pending_alerts WHERE id=?", (r["id"],))
                db_conn.commit()

def al_queue(text, event, direct=False, config=None):
    with lock:
        db_conn.execute("INSERT INTO pending_alerts (text, created_at, al_event, al_cfg, al_direct) VALUES (?, ?, ?, ?, ?)",
                        (text, int(time.time()), event, json.dumps(config) if config else "", 1 if direct else 0))
        db_conn.commit()

def _al_kick():
    threading.Thread(target=flush_alerts, daemon=True).start()


# ----- "everything is down" -----
def al_all_down_hook(s):
    """One alert when every enabled config is down or intranet-only, one when any works again.
    Configs that need sing-box (never tested) don't count. The state is kept in meta so a restart
    does not send it again."""
    cs = [c for c in config_states() if c["state"] not in ("paused", "no_engine")]
    was = get_meta("al_all_down") == "1"
    now = int(time.time())
    if not cs:
        if was:
            _al_meta_set("al_all_down", "0")
        return
    want = s.get("notify_all_down", "1") == "1"
    ts = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(now))
    if not was and all(c["state"] in ("down", "iran_only") for c in cs):
        _al_meta_set("al_all_down", "1")
        _al_meta_set("al_all_down_since", now)
        if want:
            n_ir = sum(1 for c in cs if c["state"] == "iran_only")
            al_queue(f"🚨 <b>همه کانفیگ‌ها قطع‌اند | All configs down</b>\n"
                     f"━━━━━━━━━━━━━━━━━━━━━\n"
                     f"❌ هیچ‌کدام از <b>{len(cs)}</b> کانفیگ فعال وصل نیست." +
                     (f"\n🟡 <b>{n_ir}</b> کانفیگ فقط به اینترنت ملی وصل است." if n_ir else "") + "\n"
                     f"🕒 <b>زمان:</b> <code>{ts}</code>\n"
                     f"━━━━━━━━━━━━━━━━━━━━━\n"
                     f"<i>کاربران الان هیچ کانفیگ سالمی ندارند. تلگرام فقط از راه کانفیگ سالم می‌رسد، "
                     f"پس این پیام مستقیم به بله و وب‌هوک هم فرستاده شد.</i>", "all_down", direct=True)
            _al_kick()
    elif was and any(c["state"] in ("up", "slow") for c in cs):
        _al_meta_set("al_all_down", "0")
        if want:
            try:
                since = int(get_meta("al_all_down_since") or now)
            except ValueError:
                since = now
            n_up = sum(1 for c in cs if c["state"] in ("up", "slow"))
            al_queue(f"✅ <b>سرویس برگشت | Service is back</b>\n"
                     f"━━━━━━━━━━━━━━━━━━━━━\n"
                     f"🟢 <b>{n_up}</b> از <b>{len(cs)}</b> کانفیگ دوباره وصل است.\n"
                     f"⏱ <b>مدت قطعی کامل:</b> <b>{format_dur(now - since)}</b>\n"
                     f"🕒 <b>زمان:</b> <code>{ts}</code>", "all_back", direct=True)
            _al_kick()

TICK_HOOKS.append(al_all_down_hook)


# ----- daily report and backup when Telegram can't take them -----
def al_daily_fallback(report=None, caption=None, s=None):
    """Called by tg_daily when Telegram did not take the report or the backup, and by
    al_daily_hook when Telegram is not set up. The webhook gets the report text only."""
    s = s or get_settings()
    for ch in AL_CHANNELS:
        if not al_configured(ch, s) or al_mode(ch, s) == "off":
            continue
        if report:
            al_send(ch, "daily_report", report, s)
        if caption and ch == "bale" and s.get("bale_backup", "0") == "1":
            al_bale_send_db(caption, s)

def al_daily_hook(s):
    """tg_daily only runs when a Telegram token and chat are set; without them, send the daily
    report and backup to the channels once per UTC day."""
    day = time.strftime("%Y-%m-%d", time.gmtime())
    last = get_meta("al_daily_day")
    if last == day:
        return
    _al_meta_set("al_daily_day", day)
    if last is None or (s.get("token") and s.get("chat")):
        return   # first run counts from tomorrow; with Telegram set up, tg_daily handles it
    if not any(al_configured(ch, s) and al_mode(ch, s) != "off" for ch in AL_CHANNELS):
        return
    report = scr_main()[0].replace("🛡️ <b>Sentinel</b>", f"🗓 <b>گزارش روزانه Sentinel</b> ({day})") if s.get("daily_report", "0") == "1" else None
    caption = (f"Automated Daily Backup ({day} 00:00 UTC)"
               if s.get("daily_backup", "1") == "1" and s.get("bale_backup", "0") == "1" else None)
    if report or caption:
        threading.Thread(target=al_daily_fallback, args=(report, caption, s), daemon=True).start()

TICK_HOOKS.append(al_daily_hook)


# ----- tests from the web panel and the bot -----
AL_NAMES = {"bale": "Bale", "webhook": "Webhook"}
_al_jobs = {}
_al_jobs_lock = threading.Lock()

def al_test(ch):
    s = get_settings()
    if not al_configured(ch, s):
        return False, ("Add the bot token and chat ID first" if ch == "bale" else "Add the webhook URL first")
    return al_send(ch, "test", "✅ <b>پیام آزمایشی Sentinel</b>\nهشدارها به این کانال می‌رسند. | Sentinel test: alerts reach this channel.", s)

def _al_run_test(ch):
    ok, err = al_test(ch)
    with _al_jobs_lock:
        _al_jobs[ch] = {"running": False, "ok": ok, "error": err, "at": int(time.time())}

def api_al_test(h, method, b, qs):
    """POST {channel} starts a test send in a thread; GET ?channel= reads how it went."""
    ch = (b.get("channel") if method == "POST" else qs.get("channel", [""])[0]) or ""
    if ch not in AL_CHANNELS:
        return h.out(400, {"error": "Unknown channel"})
    with _al_jobs_lock:
        job = dict(_al_jobs.get(ch) or {"running": False})
        if method == "POST" and not job.get("running"):
            _al_jobs[ch] = job = {"running": True, "started": int(time.time())}
            threading.Thread(target=_al_run_test, args=(ch,), daemon=True).start()
    return h.out(200, job)

API_ROUTES["al-test"] = api_al_test

def al_state_extra(reply):
    s = get_settings()
    reply["alert_channels"] = {ch: {"configured": al_configured(ch, s), "mode": al_mode(ch, s), "status": al_status(ch)}
                               for ch in AL_CHANNELS}
    reply["alert_channels"]["all_down"] = get_meta("al_all_down") == "1"

STATE_EXTRAS.append(al_state_extra)


# ----- bot -----
AL_SHORT = {"b": "bale", "w": "webhook"}
AL_MODE_FA = {"off": "خاموش", "fallback": "فقط وقتی تلگرام نرسد", "always": "همیشه، همراه تلگرام"}
AL_FIELDS = {   # pending-reply code -> (setting, prompt)
    "bt": ("bale_token", "🔑 توکن ربات بله را بفرستید (از @BotFather در بله).\n"
                         "بعد از ذخیره، پیامی را که توکن در آن است از این چت پاک کنید.\nبرای حذف، - بفرستید."),
    "bc": ("bale_chat", "💬 آیدی عددی چت بله را بفرستید (آیدی خودتان، یا @کانال که ربات در آن ادمین است).\nبرای حذف، - بفرستید."),
    "wu": ("webhook_url", "🔗 آدرس وب‌هوک را بفرستید (با http:// یا https://).\n"
                          "بعد از ذخیره، پیامتان را از این چت پاک کنید.\nبرای حذف، - بفرستید."),
    "ws": ("webhook_secret", "🔏 کلید امضای وب‌هوک را بفرستید. هر هشدار با هدر X-Sentinel-Signature "
                             "(sha256=HMAC-SHA256 بدنه) امضا می‌شود.\nبرای حذف، - بفرستید."),
}

def _al_status_fa(ch, s):
    if not al_configured(ch, s):
        return "⚪ تنظیم نشده"
    if al_mode(ch, s) == "off":
        return "⏸ خاموش"
    st = al_status(ch)
    if not st:
        return "🔵 هنوز چیزی فرستاده نشده"
    return "🟢 وصل" if st.get("ok") else f"🔴 خطا: {H(st.get('error') or '?')}"

def scr_alert_channels(note=""):
    s = get_settings()
    saved = lambda k: "ذخیره شده" if s.get(k) else "ندارد"
    on = s.get("notify_all_down", "1") == "1"
    text = ((note + "\n\n" if note else "") +
            "📣 <b>کانال‌های هشدار</b>\n\n"
            "تلگرام فقط از راه کانفیگ‌های سالم می‌رسد. بله و وب‌هوک مستقیم از خود سرور فرستاده می‌شوند، "
            "پس وقتی همه کانفیگ‌ها قطع‌اند هم هشدار می‌رسد.\n\n"
            f"🟦 <b>بله</b>: {_al_status_fa('bale', s)}\n"
            f"توکن: <b>{saved('bale_token')}</b> | چت: <b>{H(s.get('bale_chat') or 'ندارد')}</b>\n"
            f"حالت: <b>{AL_MODE_FA[al_mode('bale', s)]}</b>\n\n"
            f"🔗 <b>وب‌هوک</b>: {_al_status_fa('webhook', s)}\n"
            f"آدرس: <b>{saved('webhook_url')}</b> | کلید امضا: <b>{saved('webhook_secret')}</b>\n"
            f"حالت: <b>{AL_MODE_FA[al_mode('webhook', s)]}</b>\n\n"
            "«فقط وقتی تلگرام نرسد»: هشدار فقط وقتی به تلگرام نرسید اینجا می‌آید. «همیشه»: هر هشدار اینجا هم می‌آید. "
            "هشدار «همه کانفیگ‌ها قطع‌اند» به هر کانالی که خاموش نیست می‌رود.\n"
            f"هشدار همه قطع‌اند: <b>{'روشن' if on else 'خاموش'}</b>\n"
            f"بک‌آپ روزانه به بله: <b>{'روشن' if s.get('bale_backup', '0') == '1' else 'خاموش'}</b>"
            " (فایل بک‌آپ همه لینک‌ها و توکن‌ها را دارد)")
    mode_row = lambda c: [(("• " if al_mode(AL_SHORT[c], s) == m else "") + lbl, f"al:m:{c}:{m}")
                          for m, lbl in (("off", "خاموش"), ("fallback", "پشتیبان"), ("always", "همیشه"))]
    return text, kb(
        [("🔑 توکن بله", "al:e:bt"), ("💬 چت بله", "al:e:bc")],
        mode_row("b"),
        [("📨 تست بله", "al:t:b"), ("🗑 حذف بله", "al:x:b")],
        [("🔗 آدرس وب‌هوک", "al:e:wu"), ("🔏 کلید امضا", "al:e:ws")],
        mode_row("w"),
        [("📨 تست وب‌هوک", "al:t:w"), ("🗑 حذف وب‌هوک", "al:x:w")],
        [(f"{'✅' if on else '⬜'} هشدار همه قطع‌اند", "al:ad"),
         (f"{'✅' if s.get('bale_backup', '0') == '1' else '⬜'} بک‌آپ به بله", "al:bk")],
        [("« تنظیمات", "set"), BACK])

def al_tg_route(a, uid, chat_id, msg_id, cb_id, show):
    act = a[0] if a else ""
    if act == "m" and len(a) == 3 and a[1] in AL_SHORT:
        svc_apply_settings({AL_SHORT[a[1]] + "_mode": a[2]})
        return show(scr_alert_channels())
    if act == "e" and len(a) == 2 and a[1] in AL_FIELDS:
        set_pending(uid, f"al:{a[1]}", chat_id, msg_id)
        return show(scr_prompt(AL_FIELDS[a[1]][1]))
    if act == "t" and len(a) == 2 and a[1] in AL_SHORT:
        ch = AL_SHORT[a[1]]
        tg_toast(cb_id, "در حال فرستادن…")
        ok, err = al_test(ch)
        name = "بله" if ch == "bale" else "وب‌هوک"
        return show(scr_alert_channels(f"✅ پیام آزمایشی به {name} رسید." if ok else f"❌ به {name} نرسید: {H(err)}"))
    if act == "x" and len(a) == 2 and a[1] in AL_SHORT:
        name = "بله (توکن و چت)" if a[1] == "b" else "وب‌هوک (آدرس و کلید امضا)"
        return show(scr_confirm(f"🗑 تنظیمات {name} پاک شود؟", f"al:xx:{a[1]}", "al", "پاک کن"))
    if act == "xx" and len(a) == 2 and a[1] in AL_SHORT:
        ch = AL_SHORT[a[1]]
        svc_apply_settings({"bale_token": "-", "bale_chat": ""} if ch == "bale" else {"webhook_url": "-", "webhook_secret": "-"})
        with lock:
            db_conn.execute("DELETE FROM meta WHERE key=?", ("al_status_" + ch,))
            db_conn.commit()
        tg_toast(cb_id, "پاک شد")
        return show(scr_alert_channels())
    if act == "ad":
        svc_apply_settings({"notify_all_down": "0" if get_settings().get("notify_all_down", "1") == "1" else "1"})
        return show(scr_alert_channels())
    if act == "bk":
        svc_apply_settings({"bale_backup": "0" if get_settings().get("bale_backup", "0") == "1" else "1"})
        return show(scr_alert_channels())
    return show(scr_alert_channels())

def al_tg_reply(t, uid, chat_id, p):
    code = p["kind"].split(":", 1)[1] if ":" in p["kind"] else ""
    if code not in AL_FIELDS:
        return tg_show(chat_id, scr_alert_channels())
    key = AL_FIELDS[code][0]
    if not t.strip():
        set_pending(uid, p["kind"], p["chat"], p["msg"])
        return tg_api("sendMessage", {"chat_id": chat_id, "text": "متن بفرستید، یا /cancel برای لغو."})
    err = svc_apply_settings({key: t.strip()})
    if err:
        set_pending(uid, p["kind"], p["chat"], p["msg"])
        return tg_api("sendMessage", {"chat_id": chat_id, "text": f"❌ {err}\nدوباره بفرستید، یا /cancel برای لغو."})
    return tg_show(p["chat"], scr_alert_channels("✅ ذخیره شد."), p["msg"])

TG_ROUTES["al"] = al_tg_route
TG_PENDING["al"] = al_tg_reply
TG_SETTINGS_ROWS.append([("📣 کانال‌های هشدار", "al")])


def _al_selftest():
    assert al_plain("<b>a &lt;b&gt; &amp; c</b>\n<i>x</i>") == "a <b> & c\nx"
    for bad in ("ftp://x", "http://", "javascript:alert(1)", "http://a b"):
        try:
            _al_rule_webhook_url(bad); assert False, bad
        except ValueError:
            pass
    assert _al_rule_webhook_url(" https://hooks.example.net/x?a=1 ") == "https://hooks.example.net/x?a=1"
    assert _al_rule_bale_chat("-") == "" and _al_rule_bale_chat("@my_channel") == "@my_channel"
    for bad in ("hello world", "12 34"):
        try:
            _al_rule_bale_chat(bad); assert False, bad
        except ValueError:
            pass
    assert _al_rule_mode("Always") == "always"
    body = al_webhook_body("down", "<b>x</b>", {"id": "a", "name": "n", "state": "down"}, at=5)
    assert json.loads(body) == {"event": "down", "text": "x", "html": "<b>x</b>", "at": 5, "config": {"id": "a", "name": "n", "state": "down"}}
    assert al_signature("k", b"{}") == "sha256=" + hmac.new(b"k", b"{}", hashlib.sha256).hexdigest()
    assert _al_scrub("Could not resolve host: hook.example.net", "hook.example.net") == "Could not resolve host: …"
    assert al_mode("bale", {"bale_mode": "junk"}) == "fallback"
    assert not al_configured("bale", {"bale_token": "x"}) and al_configured("webhook", {"webhook_url": "http://x"})
    assert all(len(d.encode()) <= 64 for row in scr_alert_channels()[1]["inline_keyboard"] for d in [b["callback_data"] for b in row])
    assert "notify_all_down" in NOTIFY_FLAGS and "webhook_url" in SECRET_SETTINGS

SELFTESTS.append(_al_selftest)



# ---------- Feature: engines ----------
# Xray runs every link it can. Links it cannot carry (TUIC, Hysteria v1, AnyTLS,
# NaiveProxy, SSH, Shadowsocks over ShadowTLS, and Hysteria2 links Xray would
# break) run in ONE sing-box process next to it. Every such config gets a local
# SOCKS inbound on its own port from the same range, so probes, speed tests and
# the Telegram routing work exactly as with Xray. install.sh downloads sing-box;
# the Engines section (web) and the bot's engines screen can install it too.
import atexit, platform, shutil, signal, tarfile

SBBIN = D + "/sing-box"
SBCFG = D + "/sing-box.json"
SBLOG = D + "/sing-box.log"
SBPID = D + "/sing-box.pid"
SB_PROTOCOLS = ("tuic", "hysteria", "anytls", "naive", "ssh", "shadowtls")


def _install_sh_vars():
    """install.sh is the one place that names the engine versions; read them from it."""
    out = {}
    try:
        with open(D + "/install.sh") as f:
            for m in re.finditer(r'^([A-Z][A-Z0-9_]*)="([0-9A-Za-z._-]*)"', f.read(), re.M):
                out[m.group(1)] = m.group(2)
    except OSError:
        pass
    return out

_ISH = _install_sh_vars()
MIN_XRAY = _ISH.get("MIN_XRAY", "26.1.18")
MIN_SINGBOX = _ISH.get("MIN_SINGBOX", "1.13.0")
SINGBOX_VERSION = _ISH.get("SINGBOX_VERSION", "1.14.4")
# sha256 of the official release archives (published by GitHub for v1.14.4).
SINGBOX_SHA256 = {
    "linux-amd64": _ISH.get("SINGBOX_SHA256_AMD64", "699a1b510aa4396b2176d32d1181920399ebf1e267835da6f3b598d0f7c24968"),
    "linux-arm64": _ISH.get("SINGBOX_SHA256_ARM64", "436441f76ee2f7fe21b5b2d426d3cb261a480455a704865789ad533e4273ec26"),
}
SINGBOX_URL = "https://github.com/SagerNet/sing-box/releases/download/v{v}/{name}"
SB_MIRRORS = ("https://ghproxy.net/", "https://mirror.ghproxy.com/", "https://gh-proxy.com/")


def _vt(v):
    """'1.14.4-beta.1' -> (1, 14, 4) for comparing versions."""
    n = [int(x) for x in re.findall(r"\d+", str(v or ""))[:3]]
    return tuple(n + [0] * (3 - len(n)))

_bin_cache = {}

def bin_info(path):
    """(version, build tags) of an engine binary, cached by its mtime; ("", "") if missing or broken."""
    try:
        st = os.stat(path)
    except OSError:
        return "", ""
    key = (path, st.st_mtime, st.st_size)
    if key not in _bin_cache:
        v, tags = "", ""
        try:
            r = subprocess.run([path, "version"], capture_output=True, text=True, timeout=10)
            out = r.stdout + "\n" + r.stderr
            m = re.search(r"(?:sing-box version|Xray)\s+v?(\d[\w.+-]*)", out)
            v = m.group(1) if m else ""
            m = re.search(r"Tags:\s*(\S+)", out)
            tags = m.group(1) if m else ""
        except Exception:
            pass
        _bin_cache[key] = (v, tags)
    return _bin_cache[key]

def _libcronet():
    # The Linux release is a "purego" build: NaiveProxy loads libcronet.so from
    # sing-box's folder or the system library path. macOS builds link it in.
    if sys.platform == "darwin":
        return True
    return any(os.path.exists(p + "/libcronet.so") for p in (D, "/usr/lib", "/usr/local/lib", "/usr/lib64", "/lib"))

def singbox_state():
    """What the installed sing-box can do: present, version, ok, reason (missing/broken/old), naive."""
    v, tags = bin_info(SBBIN)
    present = os.path.exists(SBBIN)
    reason = "missing" if not present else "broken" if not v else "old" if _vt(v) < _vt(MIN_SINGBOX) else ""
    return {"present": present, "version": v, "min": MIN_SINGBOX, "ok": not reason, "reason": reason,
            "naive": not reason and "with_naive_outbound" in tags and _libcronet()}

# Why a config cannot run, in English (web) and Persian (bot).
SB_REASONS = {
    "missing": ("Needs sing-box, which is not installed. Install it under Settings → Engines.",
                "sing-box نصب نیست. از تنظیمات ← موتورها نصبش کنید."),
    "broken": ("Needs sing-box, but the installed sing-box does not run. Install it again under Settings → Engines.",
               "sing-box نصب شده ولی اجرا نمی‌شود. از تنظیمات ← موتورها دوباره نصبش کنید."),
    "old": ("Needs sing-box {min} or newer (this server has {v}). Update it under Settings → Engines.",
            "به sing-box نسخه {min} یا جدیدتر نیاز دارد (نسخه فعلی {v}). از تنظیمات ← موتورها به‌روزش کنید."),
    "naive": ("Needs a sing-box with NaiveProxy: the official release with libcronet.so next to sing-box.",
              "به sing-box با NaiveProxy نیاز دارد (نسخه رسمی همراه libcronet.so کنار sing-box)."),
}

def sb_reason(code, fa=False):
    st = singbox_state()
    return SB_REASONS[code][1 if fa else 0].format(min=MIN_SINGBOX, v=st["version"] or "?")

# ----- share links -----
def _nq(q):
    """Query keys the way Hiddify reads them: allow_insecure, allowInsecure and allow-insecure are one key."""
    return {re.sub(r"[_-]", "", k.lower()): v for k, v in q.items()}

def _is_ip(h):
    return bool(re.fullmatch(r"[\d.]+|[0-9a-fA-F:]+", h or "")) and ("." in h or ":" in h)

def _sb_tls(nq, host, alpn=None, utls=True, sni_keys=("sni", "peer", "servername")):
    sni = next((nq[k] for k in sni_keys if nq.get(k)), "") or ("" if _is_ip(host) else host)
    t = {"enabled": True}
    if _truthy(nq.get("disablesni")):
        t["disable_sni"] = True
    if sni:
        t["server_name"] = sni
    if _truthy(nq.get("insecure")) or _truthy(nq.get("allowinsecure")) or _truthy(nq.get("skipcertverify")):
        t["insecure"] = True
    if nq.get("alpn"):
        t["alpn"] = [a.strip() for a in nq["alpn"].split(",") if a.strip()]
    elif alpn:
        t["alpn"] = alpn
    if utls and nq.get("fp") and nq["fp"] != "none":
        t["utls"] = {"enabled": True, "fingerprint": nq["fp"]}
    return t

def _mbps(v, default):
    m = re.match(r"\d+", str(v or "").strip())
    return int(m.group()) if m and int(m.group()) > 0 else default

def _raw_userinfo(s):
    rest = s.split("://", 1)[1].split("#", 1)[0].split("?", 1)[0]
    return rest.rpartition("@")[0]

def _ss_shadowtls(s):
    """ss:// over ShadowTLS, in the two forms clients share:
    SIP002 plugin   ss://...@host:port?plugin=shadow-tls;host=sni;password=pw;version=3#name
    Shadowrocket    ss://...@host:port?shadow-tls=<base64 {"host","password","version"[,"address","port"]}>#name
    Returns (inner ss link without the plugin, plugin options) or None."""
    if not s.startswith("ss://") or "shadow-tls" not in s:
        return None
    head, _, frag = s.partition("#")
    base, _, query = head.partition("?")
    opts, keep = None, []
    for part in query.split("&"):
        k, _, v = part.partition("=")
        v = up.unquote_plus(v)
        if k == "plugin" and v.split(";", 1)[0] in ("shadow-tls", "shadowtls"):
            opts = {}
            for item in v.split(";")[1:]:
                a, _, b = item.partition("=")
                opts[a.strip()] = b.strip()
        elif k == "shadow-tls":
            try:
                opts = json.loads(base64.b64decode(v + "=" * (-len(v) % 4), altchars=b"-_").decode())
            except Exception:
                raise ValueError("Could not read the shadow-tls part of this link")
        elif part:
            keep.append(part)
    if opts is None:
        return None
    inner = base + ("?" + "&".join(keep) if keep else "") + ("#" + frag if frag else "")
    return inner, opts

def parse_singbox_uri(s):
    """Links only sing-box can run. Returns the same shape as parse_proxy_uri plus "sb":
    the sing-box outbounds (the first is the one the config's inbound uses)."""
    st = _ss_shadowtls(s)
    if st:
        inner, o = st
        info = parse_proxy_uri(inner)
        host, port = info["host"], info["port"]
        if o.get("address"):
            host = str(o["address"])
        if str(o.get("port", "")).isdigit():
            port = int(o["port"])
        pw = str(o.get("password") or "")
        ver = int(o["version"]) if str(o.get("version", "")).isdigit() else (3 if pw else 1)
        tls = {"enabled": True, "server_name": str(o.get("host") or host)}
        tls["utls"] = {"enabled": True, "fingerprint": str(o.get("fp") or "chrome")}
        shadowtls = {"type": "shadowtls", "server": host, "server_port": port, "version": ver, "tls": tls}
        if pw:
            shadowtls["password"] = pw
        ss = {"type": "shadowsocks", "method": info["method"], "password": info["password"]}
        return {"protocol": "shadowtls", "name": info["name"], "addr": _addr(host, port), "host": host, "port": port,
                "network": "tcp", "security": "tls", "q": info.get("q", {}), "sb": [ss, shadowtls]}

    scheme, ui, hp, q, name = _split_uri(s)
    nq = _nq(q)
    if scheme == "shadowtls":
        raise ValueError("A shadowtls:// link has no inner protocol; share it as ss://…?plugin=shadow-tls;host=…;password=…;version=3")
    if scheme == "tuic":
        # tuic://uuid:password@host:port?congestion_control=bbr&udp_relay_mode=native&alpn=h3&sni=…&allow_insecure=1
        # (v2rayN, Hiddify, NekoBox; Sub-Store also reads reduce_rtt and disable_sni)
        host, port = _split_hostport(hp, 443)
        uuid, _, pw = ui.partition(":")
        ob = {"type": "tuic", "server": host, "server_port": port, "uuid": uuid, "password": pw or nq.get("password", ""),
              "tls": _sb_tls(nq, host, ["h3"], utls=False)}
        cc = (nq.get("congestioncontrol") or nq.get("congestioncontroller") or "").lower().replace("newreno", "new_reno")
        if cc in ("cubic", "new_reno", "bbr"):
            ob["congestion_control"] = cc
        if nq.get("udprelaymode") in ("native", "quic"):
            ob["udp_relay_mode"] = nq["udprelaymode"]
        if _truthy(nq.get("reducertt")) or _truthy(nq.get("zerortthandshake")):
            ob["zero_rtt_handshake"] = True
        proto, net = "tuic", "quic"
    elif scheme == "hysteria":
        # Hysteria v1, its own spec: hysteria://host:port?protocol=udp&auth=…&peer=sni&insecure=1
        #   &upmbps=100&downmbps=100&alpn=hysteria&obfs=xplus&obfsParam=…
        host, port = _split_hostport(hp, 443)
        mode = (nq.get("protocol") or "udp").lower()
        if mode != "udp":
            raise ValueError(f"Hysteria protocol={mode} is not supported (sing-box runs Hysteria over UDP only)")
        ob = {"type": "hysteria", "server": host, "server_port": port,
              # Both are required by sing-box; links often leave them out.
              "up_mbps": _mbps(nq.get("upmbps") or nq.get("up"), 50),
              "down_mbps": _mbps(nq.get("downmbps") or nq.get("down"), 100),
              "tls": _sb_tls(nq, host, ["hysteria"], utls=False, sni_keys=("peer", "sni"))}
        auth = nq.get("auth") or nq.get("authstr") or ui
        if auth:
            ob["auth_str"] = auth
        obfs = nq.get("obfsparam") or nq.get("obfspassword")
        if not obfs and nq.get("obfs", "") not in ("", "xplus", "none", "plain"):
            obfs = nq["obfs"]  # Hiddify puts the password itself in obfs=
        if obfs:
            ob["obfs"] = obfs
        proto, net = "hysteria", "quic"
    elif scheme == "anytls":
        # anytls://password@host:port/?sni=…&insecure=1  (github.com/anytls/anytls-go docs/uri_scheme.md)
        host, port = _split_hostport(hp, 443)
        ob = {"type": "anytls", "server": host, "server_port": port, "password": ui, "tls": _sb_tls(nq, host)}
        proto, net = "anytls", "tcp"
    elif scheme in ("naive+https", "naive+quic"):
        # naive+https://user:pass@host:443#name (DuckSoft's NaiveProxy URI, used by v2rayN and NekoBox).
        # sing-box's naive TLS takes only server_name, so insecure=1 cannot be honoured.
        host, port = _split_hostport(hp, 443)
        raw = _raw_userinfo(s)
        user, _, pw = raw.partition(":") if ":" in raw else ("", "", raw)
        ob = {"type": "naive", "server": host, "server_port": port, "username": up.unquote(user), "password": up.unquote(pw),
              "tls": {"enabled": True, "server_name": nq.get("sni") or host}}
        if scheme == "naive+quic":
            ob["quic"] = True
        proto, net = "naive", "quic" if scheme == "naive+quic" else "tcp"
    elif scheme == "ssh":
        # ssh:// has no single standard. The most common form is Hiddify's (ray2sing):
        #   ssh://user:password@host:22?pk=<private key>&hk=<host key>[,<host key>]#name
        # Also accepted: "user:password" base64 in the userinfo, user=/password= in the query,
        # private_key=/privateKey=/key= for the key (a full PEM, or just its base64 body),
        # passphrase=/private_key_passphrase= and host_key=/hostKey=. No host key = accept any.
        host, port = _split_hostport(hp, 22)
        if ui and ":" not in ui and re.fullmatch(r"[A-Za-z0-9+/=_-]+", ui):
            try:
                dec = base64.b64decode(ui + "=" * (-len(ui) % 4), altchars=b"-_").decode("utf-8")
                if ":" in dec and dec.isprintable():
                    ui = dec
            except Exception:
                pass
        user, _, pw = ui.partition(":")
        user, pw = user or nq.get("user") or nq.get("username") or "root", pw or nq.get("password", "")
        ob = {"type": "ssh", "server": host, "server_port": port, "user": user}
        if pw:
            ob["password"] = pw
        pk = nq.get("pk") or nq.get("privatekey") or nq.get("key") or ""
        if pk:
            # A full PEM or only its base64 body; an unescaped "+" arrives as a space.
            m = re.search(r"-----BEGIN ([A-Z0-9 ]+)-----(.*?)-----END \1-----", pk, re.S)
            kind, body = (m.group(1), m.group(2)) if m else ("OPENSSH PRIVATE KEY", pk.split(",")[0])
            body = re.sub(r"\s+", "", body.strip().replace(" ", "+"))
            ob["private_key"] = (f"-----BEGIN {kind}-----\n" + "\n".join(body[i:i + 70] for i in range(0, len(body), 70)) +
                                 f"\n-----END {kind}-----\n")
        pkp = nq.get("passphrase") or nq.get("privatekeypassphrase") or nq.get("pkp")
        if pkp:
            ob["private_key_passphrase"] = pkp
        hk = [h.strip() for h in (nq.get("hk") or nq.get("hostkey") or "").split(",") if h.strip()]
        if hk:
            ob["host_key"] = hk
        if not pw and not pk:
            raise ValueError("SSH link needs a password or a private key (pk=)")
        proto, net = "ssh", "tcp"
    else:
        raise ValueError(f"Unsupported URI scheme: {scheme}")
    return {"protocol": proto, "name": name or _addr(host, port), "addr": _addr(host, port), "host": host, "port": port,
            "network": net, "security": "none" if proto == "ssh" else "tls", "q": q, "sb": [ob]}

def needs_singbox_parser(s):
    scheme = s.split("://", 1)[0].lower() if "://" in s else ""
    return scheme in NEEDS_SINGBOX or bool(_ss_shadowtls(s))

def _hy2_to_singbox(info):
    """Hysteria2 runs in sing-box when this Xray cannot run the link: no Hysteria2 at
    all, or insecure=1 without a pin on an Xray that refuses allowInsecure."""
    if info.get("protocol") != "hysteria2" or not singbox_state()["ok"]:
        return False
    q = info.get("q", {})
    return not CAPS["hysteria"] or (not CAPS["insecure"] and _truthy(q.get("insecure")) and not q.get("pinSHA256"))

def _info(c):
    try:
        return parse_proxy_uri(c["uri"])
    except Exception:
        return None

def engine_of(c, info=None):
    """Which engine runs this config: "sing-box" or "xray"."""
    info = info or _info(c)
    if not info:
        return "xray"
    return "sing-box" if info["protocol"] in SB_PROTOCOLS or _hy2_to_singbox(info) else "xray"

def engine_missing(c, info=None):
    """Reason code when the config needs an engine this server cannot run, else ""."""
    info = info or _info(c)
    if not info or info["protocol"] not in SB_PROTOCOLS:
        return ""
    st = singbox_state()
    if not st["ok"]:
        return st["reason"]
    if info["protocol"] == "naive" and not st["naive"]:
        return "naive"
    return ""

def singbox_outbounds(c, info=None):
    """sing-box outbounds of one config: the first is tagged o_<id>, a ShadowTLS hop d_<id>."""
    info = info or parse_proxy_uri(c["uri"])
    if info["protocol"] == "hysteria2":
        q = info.get("q", {})
        # Like Xray, probe the first port of a port-hopping list.
        ob = {"type": "hysteria2", "server": info["host"], "server_port": info["port"], "password": info["password"],
              "tls": _sb_tls(_nq(q), info["host"], ["h3"], utls=False)}
        if q.get("obfs") == "salamander":
            ob["obfs"] = {"type": "salamander", "password": q.get("obfs-password", "")}
        obs = [ob]
    else:
        obs = json.loads(json.dumps(info["sb"]))
    obs[0]["tag"] = "o_" + c["id"]
    if len(obs) > 1:
        obs[1]["tag"] = obs[0]["detour"] = "d_" + c["id"]
    return obs

def gen_singbox_config(configs):
    inbounds, outbounds, rules = [], [], []
    for c in configs:
        inbounds.append({"type": "socks", "tag": "i_" + c["id"], "listen": "127.0.0.1", "listen_port": c["port"]})
        outbounds += singbox_outbounds(c)
        rules.append({"inbound": ["i_" + c["id"]], "outbound": "o_" + c["id"]})
    return {"log": {"level": "warn", "timestamp": True}, "inbounds": inbounds, "outbounds": outbounds, "route": {"rules": rules}}

# ----- the sing-box process -----
sbp = None             # the running sing-box
sb_errors = {}         # config id -> why it does not run in sing-box (merged into config_errors)
sb_running = None      # (config JSON, binary mtime) sbp was started with
sb_last_error = ""     # why sing-box last failed to start or stopped
sb_started_at = 0
_sb_test_cache = {}    # (uri, sing-box mtime) -> error or ""
_sb_stale_checked = False
_sb_candidates = None  # (config JSON before isolation, binary mtime) of the running sbp

def _strip_ansi(t):
    return re.sub(r"\x1b\[[0-9;]*m", "", t or "")

def _log_tail(path, fatal_only=False, since=0):
    """Last line of a log (sing-box: the last FATAL line written after offset since), without colours or time."""
    try:
        with open(path, "rb") as f:
            f.seek(max(since, os.path.getsize(path) - 8192))
            lines = [l for l in _strip_ansi(f.read().decode("utf-8", "replace")).splitlines() if l.strip()]
    except OSError:
        return ""
    if fatal_only:
        lines = [l for l in lines if "FATAL" in l]
    if not lines:
        return ""
    t = re.sub(r"^[+-]\d{4} [\d-]+ [\d:.]+\s+", "", lines[-1])          # sing-box with timestamps
    t = re.sub(r"^\s*(?:FATAL|ERROR|WARN|INFO)(?:\[\d+\])?\s*", "", t)  # sing-box level tag
    return t.strip()[:200]

_sb_log_start = 0  # size of sing-box.log when sbp started, so old lines are not reported

def singbox_check(cfg):
    """Ask sing-box to validate cfg without starting it: (ok, error)."""
    path = f"{SBCFG[:-5]}.test.{threading.get_ident()}.json"
    try:
        with open(path, "w") as f:
            json.dump(cfg, f)
        r = subprocess.run([SBBIN, "check", "--disable-color", "-c", path], capture_output=True, text=True, timeout=30)
    except Exception as e:
        return True, str(e)  # cannot tell: let the real start decide
    finally:
        try: os.remove(path)
        except OSError: pass
    if r.returncode == 0:
        return True, ""
    lines = [l for l in _strip_ansi(r.stdout + "\n" + r.stderr).splitlines() if l.strip()]
    msg = lines[-1] if lines else "invalid config"
    msg = re.sub(r"^\s*(?:FATAL|ERROR)\[\d+\]\s*", "", msg)
    return False, re.sub(r"^initialize outbound\[\d+\]:\s*", "", msg).strip()[:200]

def _kill_stale_singbox():
    """A sing-box left by an earlier Sentinel (os._exit skips atexit) holds our ports."""
    try:
        pid = int(open(SBPID).read().strip())
    except (OSError, ValueError):
        return
    try:
        r = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, timeout=5)
        if SBBIN in r.stdout:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
    except Exception:
        pass
    try: os.remove(SBPID)
    except OSError: pass

def stop_singbox():
    global sbp, sb_running
    with lock:
        if sbp and sbp.poll() is None:
            sbp.terminate()
            try: sbp.wait(4)
            except Exception: sbp.kill()
        sbp, sb_running = None, None
        try: os.remove(SBPID)
        except OSError: pass

atexit.register(stop_singbox)

def restart_singbox(force=False):
    """Run every sing-box config in one process. It is restarted only when its
    config or binary changed, it died, or force is set; a config sing-box refuses
    is left out (and reported) so it never stops the others."""
    global sbp, sb_errors, sb_running, sb_last_error, sb_started_at, _sb_stale_checked, _sb_log_start, _sb_candidates
    with lock:
        if not _sb_stale_checked:
            _sb_stale_checked = True
            _kill_stale_singbox()
        rows = [dict(r) for r in db_conn.execute("SELECT id, uri, port FROM configs WHERE enabled=1")]
        errs, good = {}, []
        for c in rows:
            info = _info(c)
            if not info or engine_of(c, info) != "sing-box":
                continue
            miss = engine_missing(c, info)
            if miss:
                errs[c["id"]] = sb_reason(miss)
                continue
            try:
                singbox_outbounds(c, info)
                good.append(c)
            except Exception as e:
                errs[c["id"]] = str(e)[:200]
        # The worker calls this every round when no config runs in Xray: same
        # candidates, same binary and a live process need no new check.
        ckey = (json.dumps(gen_singbox_config(good), sort_keys=True), os.path.getmtime(SBBIN)) if good else None
        if ckey and not force and sbp and sbp.poll() is None and ckey == _sb_candidates:
            return
        if good and not singbox_check(gen_singbox_config(good))[0]:
            mt = os.path.getmtime(SBBIN)
            def one(c):
                k = (c["uri"], mt)
                if k not in _sb_test_cache:
                    ok, msg = singbox_check(gen_singbox_config([c]))
                    _sb_test_cache[k] = "" if ok else (msg or "rejected")
                return c, _sb_test_cache[k]
            with ThreadPoolExecutor(max_workers=8) as ex:
                results = list(ex.map(one, good))
            good = [c for c, e in results if not e]
            for c, e in results:
                if e:
                    errs[c["id"]] = "sing-box rejected this config: " + e
        sb_errors = errs
        if not good:
            if sbp:
                stop_singbox()
            return
        cfg = gen_singbox_config(good)
        key = (json.dumps(cfg, sort_keys=True), os.path.getmtime(SBBIN))
        if not force and sbp and sbp.poll() is None and sb_running == key:
            return
        stop_singbox()
        with open(SBCFG, "w") as f:
            json.dump(cfg, f, indent=2)
        sb_started_at = time.time()
        try:
            # Failed probes are logged at warn level; keep the log from growing for months.
            if os.path.getsize(SBLOG) > 5 * 1048576:
                os.remove(SBLOG)
        except OSError:
            pass
        try:
            _sb_log_start = os.path.getsize(SBLOG)
        except OSError:
            _sb_log_start = 0
        try:
            # No preexec_fn (unsafe in a threaded process): systemd stops the whole
            # cgroup with Sentinel, and a sing-box left by os._exit is found by its pidfile.
            sbp = subprocess.Popen([SBBIN, "run", "--disable-color", "-c", SBCFG], stdout=open(SBLOG, "ab"), stderr=subprocess.STDOUT)
        except OSError as e:
            sb_last_error = f"sing-box did not start: {e}"[:200]
            return
        sb_running, _sb_candidates, proc = key, ckey, sbp
        with open(SBPID, "w") as f:
            f.write(str(sbp.pid))
    time.sleep(0.8)
    if proc.poll() is not None:
        sb_last_error = _log_tail(SBLOG, True, _sb_log_start) or f"sing-box exited with code {proc.returncode}"
    elif proc is sbp:
        sb_last_error = ""

_xray_errors = {}

def _merge_errors():
    """config_errors (what tick() reports instead of probing) = Xray's + sing-box's."""
    global config_errors
    with lock:
        config_errors = {**_xray_errors, **sb_errors}

def _restart_all(force_singbox=False):
    global _xray_errors
    _restart_xray()
    _xray_errors = dict(config_errors)
    restart_singbox(force_singbox)
    _merge_errors()

def restart_xray():
    """Every caller that restarts Xray after a change restarts sing-box too (only if its part changed)."""
    _restart_all()

def singbox_watch(s):
    """After each probe round: bring back a sing-box that died, start it when it
    became usable, restart it when its binary changed. At most every 10 s."""
    global sb_last_error
    if time.time() - sb_started_at < 10:
        return
    # A new, updated or removed binary can move links between the engines
    # (Hysteria2 with insecure=1), so that restarts both; a crash only sing-box.
    if sb_running is None:
        if any(engine_of(c) == "sing-box" and not engine_missing(c) and c["id"] not in sb_errors for c in _enabled_configs()):
            restart_xray()
        return
    try:
        changed = os.path.getmtime(SBBIN) != sb_running[1]
    except OSError:
        changed = True
    if changed:
        restart_xray()
    elif sbp and sbp.poll() is not None:
        sb_last_error = _log_tail(SBLOG, True, _sb_log_start) or f"sing-box exited with code {sbp.returncode}"
        print("sing-box stopped:", sb_last_error, flush=True)
        restart_singbox(force=True)
        _merge_errors()

TICK_HOOKS.append(singbox_watch)

def _enabled_configs():
    with lock:
        return [dict(r) for r in db_conn.execute("SELECT id, uri, port FROM configs WHERE enabled=1")]

def engine_add_note(cid):
    """For svc_add_configs: why a just-added config is not checked yet, or ""."""
    with lock:
        r = db_conn.execute("SELECT uri FROM configs WHERE id=?", (cid,)).fetchone()
    why = engine_missing({"uri": r["uri"]}) if r else ""
    return f"added, but not checked yet. {sb_reason(why)}" if why else ""

def _engine_state_rule(c, st):
    if st != "paused" and engine_missing(c):
        return "no_engine"

STATE_RULES.append(_engine_state_rule)

# ----- status, install -----
sb_install = {"running": False, "stage": "", "done": 0, "total": 0, "error": "", "ok": None, "at": 0}

def engines_status():
    """Everything the Engines section and the bot screen show."""
    xv, _ = bin_info(XBIN)
    sb = singbox_state()
    cfgs = _enabled_configs()
    n_x = n_sb = waiting = 0
    for c in cfgs:
        info = _info(c)
        if not info:
            continue
        if engine_of(c, info) == "sing-box":
            n_sb += 1
            waiting += 1 if engine_missing(c, info) else 0
        else:
            n_x += 1
    x_alive = bool(xp and xp.poll() is None)
    x_err = ""
    if xp and xp.poll() is not None:
        x_err = _log_tail(D + "/xray.log") or f"Xray exited with code {xp.returncode}"
    rejected = sum(1 for k, v in config_errors.items() if str(v).startswith("Xray rejected"))
    if not x_err and rejected:
        x_err = f"{rejected} config(s) left out: Xray rejected them"
    s_alive = bool(sbp and sbp.poll() is None)
    s_bad = sum(1 for v in sb_errors.values() if str(v).startswith("sing-box rejected"))
    s_err = sb_last_error or (f"{s_bad} config(s) left out: sing-box rejected them" if s_bad else "")
    run = lambda alive, present, n: "missing" if not present else "running" if alive else "idle" if not n else "stopped"
    return {
        "sentinel": SENTINEL_VERSION,
        "xray": {"installed": os.path.exists(XBIN), "version": xv, "min": MIN_XRAY,
                 "old": bool(xv) and _vt(xv) < _vt(MIN_XRAY), "state": run(x_alive, os.path.exists(XBIN), n_x),
                 "configs": n_x, "error": x_err},
        "singbox": {"installed": sb["present"], "version": sb["version"], "min": MIN_SINGBOX, "usable": sb["ok"],
                    "old": sb["reason"] == "old", "naive": sb["naive"], "configs": n_sb, "waiting": waiting,
                    "state": run(s_alive, sb["present"], n_sb - waiting), "error": s_err if sb["ok"] else (sb_reason(sb["reason"]) if waiting else "")},
        "install": dict(sb_install),
    }

def _sb_asset():
    m = platform.machine().lower()
    arch = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(m)
    osn = "linux" if sys.platform.startswith("linux") else "darwin" if sys.platform == "darwin" else ""
    if not arch or not osn:
        raise RuntimeError(f"There is no official sing-box build for this server ({sys.platform} {m})")
    name = f"sing-box-{SINGBOX_VERSION}-{osn}-{arch}.tar.gz"
    return name, SINGBOX_SHA256.get(f"{osn}-{arch}", "")

def _sb_progress(**kw):
    with lock:
        sb_install.update(kw)

def _sb_download(url, out, proxy_port=None):
    """curl url to out, reporting progress; returns "" or the error."""
    hdr = out + ".hdr"
    cmd = ["curl", "-fsSL", "--connect-timeout", "8", "--max-time", "600", "--speed-limit", "10000", "--speed-time", "30",
           "-D", hdr, "-o", out, url]
    if proxy_port:
        cmd[1:1] = ["-x", f"socks5h://127.0.0.1:{proxy_port}"]
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    except OSError as e:
        return str(e)
    while p.poll() is None:
        time.sleep(0.5)
        try:
            lens = re.findall(r"(?im)^content-length:\s*(\d+)", open(hdr).read())
            total = int(lens[-1]) if lens else 0
        except (OSError, ValueError):
            total = 0
        try:
            done = os.path.getsize(out)
        except OSError:
            done = 0
        _sb_progress(done=done, total=total)
    err = (p.stderr.read() or "").strip()
    try: os.remove(hdr)
    except OSError: pass
    if p.returncode != 0:
        return re.sub(r"^curl: \(\d+\)\s*", "", err)[:160] or f"curl exited with code {p.returncode}"
    return ""

def _sb_install_worker():
    tmp = D + "/sing-box.download"
    tries = []
    try:
        name, sha = _sb_asset()
        if not sha:
            raise RuntimeError("No checksum is known for " + name + ", so it cannot be verified")
        url = SINGBOX_URL.format(v=SINGBOX_VERSION, name=name)
        # GitHub is often blocked from Iran: try it directly, then through healthy
        # configs, then through public mirrors. The checksum makes any route safe.
        routes = [("GitHub", url, None)] + [(f"a healthy config (port {p})", url, p) for p in tg_proxy_ports(3)] + \
                 [(m.split("/")[2], m + url, None) for m in SB_MIRRORS]
        got = False
        for label, u, port in routes:
            _sb_progress(stage=f"Downloading sing-box {SINGBOX_VERSION} from {label}", done=0, total=0)
            err = _sb_download(u, tmp, port)
            if not err:
                h = hashlib.sha256()
                with open(tmp, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""):
                        h.update(chunk)
                if hmac.compare_digest(h.hexdigest(), sha.lower()):
                    got = True
                    break
                err = "the file did not match the official checksum"
            tries.append(f"{label}: {err}")
        if not got:
            raise RuntimeError("Could not download sing-box. " + "; ".join(tries)[:400])
        _sb_progress(stage="Unpacking")
        new = {}
        with tarfile.open(tmp, "r:gz") as tf:
            for m in tf.getmembers():
                base = os.path.basename(m.name)
                if m.isfile() and base in ("sing-box", "libcronet.so"):
                    src = tf.extractfile(m)
                    with open(D + "/" + base + ".new", "wb") as f:
                        shutil.copyfileobj(src, f)
                    os.chmod(D + "/" + base + ".new", 0o755)
                    new[base] = D + "/" + base + ".new"
        if "sing-box" not in new:
            raise RuntimeError("The archive has no sing-box binary")
        v, _ = bin_info(new["sing-box"])
        if not v or _vt(v) < _vt(MIN_SINGBOX):
            raise RuntimeError(f"The downloaded sing-box does not run here (version: {v or 'none'})")
        for base, path in new.items():
            os.replace(path, D + "/" + base)
        new = {}
        _sb_progress(stage="Restarting engines")
        _restart_all(force_singbox=True)
        _sb_progress(running=False, ok=True, stage=f"Installed sing-box {v}", error="", at=int(time.time()))
    except Exception as e:
        _sb_progress(running=False, ok=False, stage="Install failed", error=str(e)[:500], at=int(time.time()))
    finally:
        for p in [tmp, tmp + ".hdr"] + list(locals().get("new", {}).values()):
            try: os.remove(p)
            except OSError: pass

def svc_install_singbox(on_done=None):
    """Start downloading sing-box in the background; False if a download is running."""
    with lock:
        if sb_install["running"]:
            return False
        sb_install.update(running=True, ok=None, stage="Starting", error="", done=0, total=0, at=int(time.time()))
    def run():
        _sb_install_worker()
        if on_done:
            try: on_done()
            except Exception as e: print("engines on_done:", e, flush=True)
    threading.Thread(target=run, daemon=True).start()
    return True

_restarting = threading.Lock()

def svc_restart_engines(on_done=None):
    """Restart Xray and sing-box in the background; False if a restart is running."""
    if not _restarting.acquire(blocking=False):
        return False
    def run():
        try:
            _restart_all(force_singbox=True)
            wake.set()
            if on_done:
                on_done()
        except Exception as e:
            print("engines restart:", e, flush=True)
        finally:
            _restarting.release()
    threading.Thread(target=run, daemon=True).start()
    return True

# ----- web -----
def _api_engines(h, method, b, qs):
    return h.out(200, engines_status())

def _api_engines_restart(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    if not svc_restart_engines():
        return h.out(409, {"error": "The engines are already restarting"})
    return h.out(200, {"ok": True})

def _api_engines_install(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    if not svc_install_singbox():
        return h.out(409, {"error": "sing-box is already being installed"})
    return h.out(200, {"ok": True})

API_ROUTES.update({"engines": _api_engines, "engines/restart": _api_engines_restart, "engines/install": _api_engines_install})

def _engines_extras(reply):
    for c in reply.get("configs", []):
        info = _info(c)
        c["engine"] = engine_of(c, info) if info else "xray"
        miss = engine_missing(c, info) if info else ""
        if miss and c.get("enabled"):
            c["engine_note"] = sb_reason(miss)
        elif c["id"] in sb_errors:
            c["engine_note"] = sb_errors[c["id"]]
    reply["engines"] = engines_status()

STATE_EXTRAS.append(_engines_extras)

# ----- bot -----
_EN_STATE_FA = {"running": "🟢 در حال اجرا", "idle": "⚪ بیکار (کانفیگی ندارد)", "stopped": "🔴 متوقف", "missing": "⛔ نصب نیست"}

def scr_engines(note=""):
    e = engines_status()
    x, sb, ins = e["xray"], e["singbox"], e["install"]
    lines = [f"🧩 <b>موتورها</b>", "", f"🛡️ Sentinel: <b>{H(e['sentinel'])}</b>", "",
             f"<b>Xray</b>: " + (f"{H(x['version'] or '?')} · {_EN_STATE_FA[x['state']]} · {x['configs']} کانفیگ" if x["installed"] else _EN_STATE_FA["missing"])]
    if x["old"]:
        lines.append(f"⚠️ قدیمی است؛ حداقل {H(x['min'])} لازم است (Hysteria2 به آن نیاز دارد).")
    if x["error"]:
        lines.append(f"⚠️ {H(x['error'])}")
    lines += ["", f"<b>sing-box</b>: " + (f"{H(sb['version'] or '?')} · {_EN_STATE_FA[sb['state']]}" if sb["installed"] else _EN_STATE_FA["missing"])]
    if sb["configs"]:
        lines.append(f"کانفیگ‌هایی که به sing-box نیاز دارند: <b>{sb['configs']}</b>")
    if sb["waiting"]:
        lines.append(f"🧩 {sb['waiting']} کانفیگ تا نصب sing-box تست نمی‌شوند (هشدار هم نمی‌دهند).")
    if sb["old"]:
        lines.append(f"⚠️ قدیمی است؛ حداقل {H(sb['min'])} لازم است.")
    if sb["usable"] and sb["error"]:
        lines.append(f"⚠️ {H(sb['error'])}")
    if ins["running"]:
        mb = lambda n: f"{n / 1048576:.1f}"
        lines += ["", f"⏳ {H(ins['stage'])}" + (f" — {mb(ins['done'])} از {mb(ins['total'])} مگابایت" if ins["total"] else (f" — {mb(ins['done'])} مگابایت" if ins["done"] else ""))]
    elif ins["ok"] is False:
        lines += ["", f"❌ نصب sing-box نشد: {H(ins['error'])}", "اگر GitHub از این سرور باز نمی‌شود، فایل sing-box را دستی در پوشه Sentinel بگذارید."]
    elif ins["ok"]:
        lines += ["", f"✅ {H(ins['stage'])}"]
    if note:
        lines = [note, ""] + lines
    install_lbl = "⬇️ نصب sing-box" if not sb["installed"] or not sb["usable"] else "⬇️ نصب دوباره sing-box"
    return "\n".join(lines), kb(
        [("🔄 ری‌استارت موتورها", "en:rs"), (install_lbl, "en:in")],
        [("🔄 تازه‌سازی", "en"), ("« تنظیمات", "set")])

def _tg_engines(args, uid, chat_id, msg_id, cb_id, show):
    act = args[0] if args else ""
    if act == "rs":
        started = svc_restart_engines(on_done=lambda: tg_show(chat_id, scr_engines("✅ موتورها ری‌استارت شدند."), msg_id))
        tg_toast(cb_id, "در حال ری‌استارت موتورها…" if started else "یک ری‌استارت در جریان است", alert=not started)
        return
    if act == "in":
        started = svc_install_singbox(on_done=lambda: tg_show(chat_id, scr_engines(), msg_id))
        tg_toast(cb_id, "دانلود sing-box شروع شد؛ ممکن است چند دقیقه طول بکشد" if started else "دانلود sing-box در جریان است", alert=not started)
        if started:
            def progress():
                # Show the download moving, at most every 4 seconds, until it ends.
                last = ""
                while sb_install["running"]:
                    time.sleep(4)
                    text = scr_engines()
                    if sb_install["running"] and text[0] != last:
                        last = text[0]
                        tg_show(chat_id, text, msg_id)
            threading.Thread(target=progress, daemon=True).start()
        return show(scr_engines())
    return show(scr_engines())

TG_ROUTES["en"] = _tg_engines
TG_SETTINGS_ROWS.append([("🧩 موتورها", "en")])

def _tg_engine_lines(c):
    info = _info(c)
    if not info or engine_of(c, info) != "sing-box":
        return []
    out = ["موتور: sing-box"]
    miss = engine_missing(c, info)
    if miss and c.get("enabled"):
        out.append(f"🧩 {H(sb_reason(miss, fa=True))}")
    return out

TG_CONFIG_LINES.append(_tg_engine_lines)

def _engines_selftest():
    U = "2dd61d93-75d8-4da4-ac0e-6aece7eac365"
    tu = parse_proxy_uri(f"tuic://{U}:p%40ss@t.example.com:8443?congestion_control=bbr&udp_relay_mode=quic&alpn=h3&sni=s.example.com&allow_insecure=1#T")
    o = tu["sb"][0]
    assert (tu["protocol"], tu["port"], tu["name"], o["uuid"], o["password"]) == ("tuic", 8443, "T", U, "p@ss")
    assert o["congestion_control"] == "bbr" and o["udp_relay_mode"] == "quic"
    assert o["tls"] == {"enabled": True, "server_name": "s.example.com", "insecure": True, "alpn": ["h3"]}
    hy = parse_proxy_uri("hysteria://h.example.com:443?protocol=udp&auth=pw&peer=p.example.com&insecure=1&upmbps=20&obfs=xplus&obfsParam=ob#H1")["sb"][0]
    assert (hy["auth_str"], hy["obfs"], hy["up_mbps"], hy["down_mbps"]) == ("pw", "ob", 20, 100)
    assert hy["tls"]["server_name"] == "p.example.com" and hy["tls"]["alpn"] == ["hysteria"]
    try: parse_proxy_uri("hysteria://h.example.com:443?protocol=faketcp"); assert False
    except ValueError: pass
    at = parse_proxy_uri("anytls://pw@1.2.3.4:443/?sni=a.example.com&insecure=1&fp=chrome#A")["sb"][0]
    assert at["password"] == "pw" and at["tls"]["utls"]["fingerprint"] == "chrome" and at["tls"]["insecure"]
    assert "server_name" not in parse_proxy_uri("anytls://pw@1.2.3.4:443")["sb"][0]["tls"]
    nv = parse_proxy_uri("naive+quic://u%3Ax:p%40w@n.example.com#N")
    assert nv["protocol"] == "naive" and nv["port"] == 443 and nv["sb"][0]["quic"] and nv["sb"][0]["username"] == "u:x"
    assert nv["sb"][0]["password"] == "p@w" and nv["sb"][0]["tls"] == {"enabled": True, "server_name": "n.example.com"}
    sh = parse_proxy_uri("ssh://root:pw@s.example.com?hk=ssh-ed25519%20AAAA,&pk=AAAAB3+xy#S")["sb"][0]
    assert sh["server_port"] == 22 and sh["password"] == "pw" and sh["host_key"] == ["ssh-ed25519 AAAA"]
    assert sh["private_key"].startswith("-----BEGIN OPENSSH PRIVATE KEY-----\nAAAAB3+xy\n")
    sh2 = parse_proxy_uri("ssh://" + base64.b64encode(b"bob:pw").decode() + "@s.example.com:2222")["sb"][0]
    assert (sh2["user"], sh2["password"], sh2["server_port"]) == ("bob", "pw", 2222) and "host_key" not in sh2
    try: parse_proxy_uri("ssh://bob@s.example.com"); assert False
    except ValueError: pass
    ss_b = "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@st.example.com:443"
    st = parse_proxy_uri(ss_b + "?plugin=shadow-tls%3Bhost%3Dwww.example.org%3Bpassword%3Dstp%3Bversion%3D3#ST")
    assert st["protocol"] == "shadowtls" and st["name"] == "ST" and [o["type"] for o in st["sb"]] == ["shadowsocks", "shadowtls"]
    assert st["sb"][1]["tls"]["server_name"] == "www.example.org" and st["sb"][1]["version"] == 3 and st["sb"][1]["password"] == "stp"
    sr = parse_proxy_uri(ss_b + "?shadow-tls=" + base64.b64encode(json.dumps({"host": "h.example.org", "password": "x", "version": "2"}).encode()).decode() + "#SR")
    assert sr["sb"][1]["version"] == 2 and sr["sb"][0]["method"] == "aes-128-gcm"
    obs = singbox_outbounds({"id": "z", "uri": ss_b + "?plugin=shadow-tls%3Bhost%3Dw.example.org%3Bpassword%3Dp"})
    assert obs[0]["tag"] == "o_z" and obs[0]["detour"] == obs[1]["tag"] == "d_z"
    assert parse_proxy_uri(ss_b)["protocol"] == "shadowsocks"  # a plain ss:// link stays in Xray
    try: parse_proxy_uri("shadowtls://pw@st.example.com:443"); assert False
    except ValueError: pass
    # Engines: sing-box links never reach Xray; hy2 insecure moves only when sing-box can take it.
    cfgs = [{"id": "e1", "uri": f"tuic://{U}:p@t.example.com:443", "port": 1}, {"id": "e2", "uri": "hy2://pw@h.example.com:443?insecure=1", "port": 2}]
    old = dict(CAPS), singbox_state
    try:
        CAPS["insecure"] = False
        globals()["singbox_state"] = lambda: {"present": True, "version": "1.14.4", "min": MIN_SINGBOX, "ok": True, "reason": "", "naive": False}
        assert [engine_of(c) for c in cfgs] == ["sing-box", "sing-box"] and gen_xray_config(cfgs)["inbounds"] == []
        assert engine_missing({"uri": "naive+https://u:p@n.example.com"}) == "naive" and not engine_missing(cfgs[0])
        sb = gen_singbox_config(cfgs)
        assert [i["listen_port"] for i in sb["inbounds"]] == [1, 2] and sb["outbounds"][1]["tls"]["insecure"] is True
        globals()["singbox_state"] = lambda: {"present": False, "version": "", "min": MIN_SINGBOX, "ok": False, "reason": "missing", "naive": False}
        assert engine_of(cfgs[1]) == "xray" and engine_missing(cfgs[0]) == "missing" and not engine_missing(cfgs[1])
        assert config_state({"enabled": 1, "uri": cfgs[0]["uri"], "down_since": 5}) == "no_engine"
        assert config_state({"enabled": 0, "uri": cfgs[0]["uri"]}) == "paused"
    finally:
        CAPS.update(old[0]); globals()["singbox_state"] = old[1]
    CAPS["insecure"] = False
    assert not insecure_dropped("anytls://pw@a.example.com:443?insecure=1") and insecure_dropped("trojan://pw@t.example.com:443?security=tls&allowInsecure=1")
    CAPS["insecure"] = True
    assert _vt("1.14.4-beta.1") == (1, 14, 4) and _vt("26.1") < _vt("26.1.18")
    assert all(len(d.encode()) <= 64 for row in scr_engines()[1]["inline_keyboard"] for d in [b["callback_data"] for b in row])

SELFTESTS.append(_engines_selftest)



# ---------- Feature: performance ----------
# A config that works but is too slow turns "slow"; speed tests can run on a schedule and are kept
# as history; the clean feed can list the best configs first (sort=best).
import statistics

DEF_SETTINGS.update({
    "slow_ms": "0",            # slow when the median latency of the last 3 successful checks is above this (0 = off)
    "slow_mbps": "0",          # slow when the latest speed test is below this (0 = off)
    "notify_slow": "0",        # Telegram alert when a config turns slow, and when it is back to normal
    "speed_every_hours": "0",  # scheduled speed test of every working config: 0 (off), 6, 12 or 24
    "speed_size_mb": "100",    # download size of a scheduled test: 10, 25 or 100
})
PF_HOURS = (0, 6, 12, 24)
PF_SIZES = (10, 25, 100)
PF_ROUNDS = 2        # probe rounds in a row before a slow alert, and before "back to normal"
PF_KEEP_DAYS = 90    # speed history kept this long
PF_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def _pf_rule_ms(v):
    try:
        n = int(str(v).strip().translate(PF_FA_DIGITS))
    except ValueError:
        raise ValueError("Latency limit must be a whole number of milliseconds")
    if not 0 <= n <= 60000:
        raise ValueError("Latency limit must be between 0 and 60000 ms")
    return str(n)

def _pf_rule_mbps(v):
    try:
        f = float(str(v).strip().translate(PF_FA_DIGITS))
    except ValueError:
        raise ValueError("Speed limit must be a number of Mbps")
    if not 0 <= f <= 10000:
        raise ValueError("Speed limit must be between 0 and 10000 Mbps")
    return "%g" % round(f, 1)

def _pf_rule_choice(choices, what):
    def rule(v):
        try:
            n = int(str(v).strip())
        except ValueError:
            n = None
        if n not in choices:
            raise ValueError(f"{what} must be one of " + ", ".join(map(str, choices)))
        return str(n)
    return rule

SETTING_RULES["slow_ms"] = _pf_rule_ms
SETTING_RULES["slow_mbps"] = _pf_rule_mbps
SETTING_RULES["notify_slow"] = lambda v: "1" if str(v) in ("1", "true", "True") else "0"
SETTING_RULES["speed_every_hours"] = _pf_rule_choice(PF_HOURS, "Speed test schedule")
SETTING_RULES["speed_size_mb"] = _pf_rule_choice(PF_SIZES, "Speed test size")


def _pf_migrate(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS speed_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        config_id TEXT NOT NULL,
        mbps REAL NOT NULL,
        bytes INTEGER,
        tested_at INTEGER NOT NULL,
        source TEXT NOT NULL DEFAULT 'manual')""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_speed_cfg_time ON speed_tests(config_id, tested_at)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_speed_time ON speed_tests(tested_at)")
    # Hysteresis of the slow alerts: rounds in a row slow / normal, and whether the alert went out.
    conn.execute("""CREATE TABLE IF NOT EXISTS perf_slow (
        config_id TEXT PRIMARY KEY,
        slow_rounds INTEGER NOT NULL DEFAULT 0,
        normal_rounds INTEGER NOT NULL DEFAULT 0,
        flagged INTEGER NOT NULL DEFAULT 0,
        alert_sent INTEGER NOT NULL DEFAULT 0,
        since INTEGER)""")
    # Once: start the history with the speed each config already shows.
    if not conn.execute("SELECT 1 FROM meta WHERE key='pf_history_seeded'").fetchone():
        conn.execute("""INSERT INTO speed_tests (config_id, mbps, bytes, tested_at, source)
            SELECT id, last_speed_mbps, NULL, last_speed_time, 'manual' FROM configs
            WHERE last_speed_mbps IS NOT NULL AND last_speed_time IS NOT NULL""")
        conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('pf_history_seeded', '1')")

MIGRATIONS.append(_pf_migrate)


# ----- slow state -----
def pf_limits(s=None):
    """(latency limit in ms, speed limit in Mbps); 0 means that limit is off."""
    s = s or get_settings()
    try:
        ms = max(0, int(s.get("slow_ms") or 0))
    except ValueError:
        ms = 0
    try:
        mbps = max(0.0, float(s.get("slow_mbps") or 0))
    except ValueError:
        mbps = 0.0
    return ms, mbps

def pf_median_latency(cid, n=3, need=None):
    """Median latency of the last n successful checks; None with fewer than `need` (default n) of them."""
    with lock:
        v = [r[0] for r in db_conn.execute(
            "SELECT latency_ms FROM checks WHERE config_id=? AND ok=1 AND latency_ms IS NOT NULL ORDER BY checked_at DESC LIMIT ?", (cid, n))]
    return statistics.median(v) if v and len(v) >= (need or n) else None

def pf_slow_check(c, lim):
    """(is slow, median latency of the last 3 successful checks) for a config that is up.
    Slow: median above the latency limit, or latest speed test below the speed limit (both strict)."""
    ms_lim, mbps_lim = lim
    med = pf_median_latency(c["id"]) if ms_lim else None
    sp = c.get("last_speed_mbps")
    slow = bool(ms_lim and med is not None and med > ms_lim) or bool(mbps_lim and sp is not None and sp < mbps_lim)
    return slow, med

def _pf_could_be_up(c):
    return c.get("enabled") and not c.get("down_since") and c.get("last_ok") == 1

def _pf_rows(rows):
    lim = pf_limits()
    for c in rows:
        c["pf_slow"], c["pf_median"] = False, None
        if (lim[0] or lim[1]) and _pf_could_be_up(c):
            c["pf_slow"], c["pf_median"] = pf_slow_check(c, lim)

def _pf_state(c, st):
    return "slow" if st == "up" and c.get("pf_slow") else None

ROW_HOOKS.append(_pf_rows)
STATE_RULES.append(_pf_state)


def _pf_alert_text(c, kind, lim, since=None):
    now = int(time.time())
    sub_info = f"<b>{H(c['sub_name'])}</b>" if c.get("sub_name") else "<i>دستی (Manual)</i>"
    med = c.get("pf_median")
    if med is None:
        med = pf_median_latency(c["id"])
    sp = c.get("last_speed_mbps")
    lines = []
    if med is not None:
        lines.append(f"⚡ <b>پینگ (میانه ۳ تست آخر):</b> <b>{round(med)}ms</b>" + (f" (حد {lim[0]}ms)" if lim[0] else ""))
    if sp is not None:
        lines.append(f"🚀 <b>آخرین تست سرعت:</b> <b>{sp} Mbps</b>" + (f" (حد {lim[1]:g} Mbps)" if lim[1] else ""))
    if kind == "slow":
        head, foot = "🐢 <b>کندی نود | Slow Node</b>", "<i>نود وصل است و در لینک ساب تمیز می‌ماند، اما از حد تعیین‌شده کندتر است.</i>"
    else:
        head, foot = "✅ <b>سرعت نود عادی شد | Node Back to Normal</b>", "<i>نود دوباره در حد تعیین‌شده کار می‌کند.</i>"
        if since:
            lines.insert(0, f"⏱ <b>مدت کندی:</b> <b>{format_dur(now - since)}</b>")
    return (f"{head}\n━━━━━━━━━━━━━━━━━━━━━\n"
            f"📡 <b>نام نود:</b> <code>{H(c['name'])}</code>\n"
            f"🌐 <b>آدرس:</b> <code>{H(c['addr'])}</code>\n"
            f"📦 <b>اشتراک:</b> {sub_info}\n" + "".join(l + "\n" for l in lines) +
            f"🕒 <b>زمان:</b> <code>{time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(now))}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n{foot}")

def pf_slow_round(s):
    """One probe round of slow-alert hysteresis. A config must be slow for PF_ROUNDS rounds in a row
    before the alert, and normal for PF_ROUNDS rounds before "back to normal". A config that goes
    down, fails or is paused starts over silently (outage alerts cover it). Returns alerts queued."""
    lim = pf_limits(s)
    if not (lim[0] or lim[1]):
        with lock:
            db_conn.execute("DELETE FROM perf_slow")
            db_conn.commit()
        return 0
    want = s.get("notify_slow", "0") == "1"
    now = int(time.time())
    rows = [c for c in config_states() if c["enabled"]]
    with lock:
        prev = {r["config_id"]: dict(r) for r in db_conn.execute("SELECT * FROM perf_slow")}
    queued, keep = [], []
    for c in rows:
        p = prev.get(c["id"]) or {"config_id": c["id"], "slow_rounds": 0, "normal_rounds": 0, "flagged": 0, "alert_sent": 0, "since": None}
        if c["state"] == "slow":
            p["slow_rounds"], p["normal_rounds"] = p["slow_rounds"] + 1, 0
            if not p["flagged"] and p["slow_rounds"] >= PF_ROUNDS:
                p["flagged"], p["since"], p["alert_sent"] = 1, now, 0
                if want and not c["muted"]:
                    queued.append(_pf_alert_text(c, "slow", lim))
                    p["alert_sent"] = 1
        elif c["state"] == "up":
            p["normal_rounds"], p["slow_rounds"] = p["normal_rounds"] + 1, 0
            if p["flagged"] and p["normal_rounds"] >= PF_ROUNDS:
                if p["alert_sent"] and want and not c["muted"]:
                    queued.append(_pf_alert_text(c, "normal", lim, p["since"]))
                p["flagged"], p["alert_sent"], p["since"] = 0, 0, None
        else:
            continue
        keep.append(p)
    with lock:
        db_conn.execute("DELETE FROM perf_slow")
        db_conn.executemany("INSERT INTO perf_slow (config_id, slow_rounds, normal_rounds, flagged, alert_sent, since) VALUES (?,?,?,?,?,?)",
                            [(p["config_id"], p["slow_rounds"], p["normal_rounds"], p["flagged"], p["alert_sent"], p["since"]) for p in keep])
        for t in queued:
            db_conn.execute("INSERT INTO pending_alerts (text, created_at) VALUES (?, ?)", (t, now))
        db_conn.commit()
    return len(queued)


# ----- speed history -----
def pf_speed_stats(cid, days=7):
    """Latest speed and the average over the last `days` days (None when there is no test)."""
    since = int(time.time()) - days * 86400
    with lock:
        r = db_conn.execute("SELECT AVG(mbps) AS a, COUNT(*) AS n FROM speed_tests WHERE config_id=? AND tested_at>=?", (cid, since)).fetchone()
        last = db_conn.execute("SELECT mbps, tested_at FROM speed_tests WHERE config_id=? ORDER BY tested_at DESC, id DESC LIMIT 1", (cid,)).fetchone()
    return {"latest": last["mbps"] if last else None, "latest_at": last["tested_at"] if last else None,
            "avg": round(r["a"], 1) if r["n"] else None, "n": r["n"]}

def pf_trend(latest, avg, n):
    """"up", "down" or "flat": the latest test against the 7-day average (needs 2 tests; 5% dead band)."""
    if latest is None or avg is None or n < 2 or avg <= 0:
        return None
    if latest > avg * 1.05:
        return "up"
    if latest < avg * 0.95:
        return "down"
    return "flat"

def pf_prune():
    with lock:
        db_conn.execute("DELETE FROM speed_tests WHERE tested_at < ? OR config_id NOT IN (SELECT id FROM configs)",
                        (int(time.time()) - PF_KEEP_DAYS * 86400,))
        db_conn.commit()


# ----- scheduled speed tests -----
pf_sched = {"thread": None, "running": False, "done": 0, "total": 0}

def pf_due(s, now=None):
    """True when the schedule is on and its period has passed since the last run started."""
    try:
        h = int(s.get("speed_every_hours") or 0)
    except ValueError:
        h = 0
    if h <= 0:
        return False
    last = int(get_meta("pf_speed_last") or 0)
    return (now or int(time.time())) - last >= h * 3600

def pf_run_scheduled(sleep=time.sleep):
    """One scheduled run: every working config (up or slow), one at a time, never during a manual or
    "test all" run. The start time goes to meta first, so a restart mid-run doesn't repeat it."""
    s = get_settings()
    size = int(s.get("speed_size_mb") or 100)
    if size not in PF_SIZES:
        size = 100
    with lock:
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('pf_speed_last', ?)", (str(int(time.time())),))
        db_conn.commit()
    ids = [c["id"] for c in config_states() if c["state"] in ("up", "slow")]
    pf_sched.update(running=True, done=0, total=len(ids))
    tested = 0
    try:
        for cid in ids:
            if get_settings().get("speed_every_hours", "0") == "0":
                break                      # turned off during the run
            while sp_testing_all or not speed_gate.acquire(blocking=False):
                sleep(5)                   # a manual or "test all" run has the line
            try:
                with lock:
                    ok = db_conn.execute("SELECT enabled FROM configs WHERE id=?", (cid,)).fetchone()
                if ok and ok["enabled"]:
                    if run_speed_test(cid, size, "scheduled").get("ok"):
                        tested += 1
            finally:
                speed_gate.release()
            pf_sched["done"] += 1
            sleep(1)
    finally:
        pf_sched["running"] = False
    return tested

def _pf_sched_loop():
    while True:
        try:
            if pf_due(get_settings()):
                pf_run_scheduled()
        except Exception as e:
            print("scheduled speed test error:", e, flush=True)
        time.sleep(60)

def pf_cost(s=None, n=None):
    """(configs, MB a day) a scheduled test costs: configs × size × runs a day."""
    s = s or get_settings()
    if n is None:
        n = sum(1 for c in config_states() if c["state"] in ("up", "slow"))
    h = int(s.get("speed_every_hours") or 0)
    return n, (n * int(s.get("speed_size_mb") or 100) * (24 // h) if h else 0)

_pf_pruned_at = [0]

def _pf_tick(s):
    t = pf_sched["thread"]
    if not (t and t.is_alive()):
        pf_sched["thread"] = threading.Thread(target=_pf_sched_loop, daemon=True, name="pf-speed")
        pf_sched["thread"].start()
    if pf_slow_round(s):
        flush_alerts()
    if time.time() - _pf_pruned_at[0] > 3600:
        _pf_pruned_at[0] = time.time()
        pf_prune()

TICK_HOOKS.append(_pf_tick)


# ----- clean feed: sort=best -----
def pf_scores(ids):
    """Score from 0 to 100 for each config id, for the clean feed's sort=best (highest first).

        score = 100 * (0.5*U + 0.3*L + 0.2*V) / (sum of the weights used)
          U  uptime over the last 24 h: successful checks / checks (0..1; 0 with no checks)
          L  300 / (300 + m), m = median latency of the last 20 successful checks in ms
             (1 at 0 ms, 0.5 at 300 ms, 0.25 at 900 ms; 0 with no successful check)
          V  v / (v + 50), v = latest speed test in Mbps (0.5 at 50 Mbps, 0.8 at 200 Mbps).
             A config never speed tested leaves V and its 0.2 weight out, so it is judged on U and L.
        A config in the slow state (see pf_slow_check) then has its score multiplied by 0.6.
    """
    if not ids:
        return {}
    lim = pf_limits()
    since = int(time.time()) - 86400
    marks = ",".join("?" * len(ids))
    with lock:
        upt = {r["config_id"]: (r["up"] or 0) / r["n"] for r in db_conn.execute(
            f"SELECT config_id, COUNT(*) AS n, SUM(ok) AS up FROM checks WHERE checked_at>=? AND config_id IN ({marks}) GROUP BY config_id",
            [since] + list(ids))}
        speed = {r["id"]: r["last_speed_mbps"] for r in db_conn.execute(
            f"SELECT id, last_speed_mbps FROM configs WHERE id IN ({marks})", list(ids))}
    out = {}
    for cid in ids:
        med = pf_median_latency(cid, 20, 1)
        parts = [(0.5, upt.get(cid, 0.0)), (0.3, 300.0 / (300.0 + med) if med is not None else 0.0)]
        v = speed.get(cid)
        if v is not None:
            parts.append((0.2, v / (v + 50.0)))
        score = 100.0 * sum(w * x for w, x in parts) / sum(w for w, _ in parts)
        if (lim[0] or lim[1]) and pf_slow_check({"id": cid, "last_speed_mbps": v}, lim)[0]:
            score *= 0.6
        out[cid] = round(score, 2)
    return out

def pf_best(rows, limit=None):
    """Feed rows (with an "id") best first; ties keep their order. limit > 0 keeps the first N."""
    sc = pf_scores([r["id"] for r in rows])
    rows = sorted(rows, key=lambda r: -sc.get(r["id"], 0))
    return rows[:limit] if limit and limit > 0 else rows


# ----- web panel -----
def _pf_extras(reply):
    since = int(time.time()) - 7 * 86400
    with lock:
        avg7 = {r["config_id"]: [round(r["a"], 1), r["n"]] for r in db_conn.execute(
            "SELECT config_id, AVG(mbps) AS a, COUNT(*) AS n FROM speed_tests WHERE tested_at>=? GROUP BY config_id", (since,))}
    s = get_settings()
    n = sum(1 for c in reply.get("configs", []) if c.get("state") in ("up", "slow"))
    last = int(get_meta("pf_speed_last") or 0)
    h = int(s.get("speed_every_hours") or 0)
    reply["perf"] = {"avg7": avg7, "working": n, "mb_per_day": pf_cost(s, n)[1],
                     "sched": {"running": pf_sched["running"], "done": pf_sched["done"], "total": pf_sched["total"],
                               "last": last or None, "next": (last + h * 3600 if last else int(time.time())) if h else None}}

STATE_EXTRAS.append(_pf_extras)

def _pf_api_speed(handler, method, body, qs):
    cid = qs.get("id", [""])[0]
    since = int(time.time()) - PF_KEEP_DAYS * 86400
    with lock:
        if not db_conn.execute("SELECT 1 FROM configs WHERE id=?", (cid,)).fetchone():
            return handler.out(404, {"error": "not found"})
        pts = [dict(r) for r in db_conn.execute(
            "SELECT mbps, bytes, tested_at, source FROM speed_tests WHERE config_id=? AND tested_at>=? ORDER BY tested_at ASC, id ASC",
            (cid, since))][-500:]
    v = [p["mbps"] for p in pts]
    st = pf_speed_stats(cid)
    return handler.out(200, {"points": pts, "min": min(v) if v else None, "max": max(v) if v else None,
                             "avg": round(sum(v) / len(v), 1) if v else None, "latest": v[-1] if v else None,
                             "avg7": st["avg"], "n7": st["n"], "trend": pf_trend(v[-1] if v else None, st["avg"], st["n"])})

API_ROUTES["perf/speed"] = _pf_api_speed


# ----- Telegram bot -----
def _pf_fmt_mb(mb):
    return f"{mb / 1024:.1f} GB" if mb >= 1024 else f"{mb} MB"

PF_ARROW = {"up": "▲", "down": "▼", "flat": "▬"}

def scr_perf():
    s = get_settings()
    ms, mbps = pf_limits(s)
    h = int(s.get("speed_every_hours") or 0)
    size = int(s.get("speed_size_mb") or 100)
    cs = config_states()
    n, mb = pf_cost(s, sum(1 for c in cs if c["state"] in ("up", "slow")))
    slow = sum(1 for c in cs if c["state"] == "slow")
    last = int(get_meta("pf_speed_last") or 0)
    lines = ["🐢 <b>کارایی</b>\n",
             "کانفیگی که وصل است ولی از این حدها کندتر باشد «کند» 🐢 می‌شود و در ساب تمیز می‌ماند.\n",
             f"⏱ حد پینگ: <b>{f'{ms}ms' if ms else 'خاموش'}</b> (میانه ۳ تست موفق آخر)",
             f"🚀 حد سرعت: <b>{f'{mbps:g} Mbps' if mbps else 'خاموش'}</b> (آخرین تست سرعت)",
             f"🔔 هشدار کندی: <b>{'روشن' if s.get('notify_slow') == '1' else 'خاموش'}</b> (بعد از ۲ دور کندی، و ۲ دور عادی)",
             f"🐢 کند الان: <b>{slow}</b>",
             "",
             f"⚡ تست سرعت خودکار: <b>{f'هر {h} ساعت' if h else 'خاموش'}</b> · حجم هر تست: <b>{size}MB</b>"]
    if h:
        lines.append(f"📶 مصرف تقریبی: {n} کانفیگ × {size}MB × {24 // h} بار = <b>{_pf_fmt_mb(mb)} در روز</b>")
        if pf_sched["running"]:
            lines.append(f"▶ در حال اجرا: {pf_sched['done']} از {pf_sched['total']}")
        elif last:
            lines.append(f"آخرین اجرا: {format_dur(int(time.time()) - last)} پیش")
    mark = lambda v, cur: ("• " if v == cur else "")
    return "\n".join(lines), kb(
        [("⏱ حد پینگ", "pf:ms"), ("🚀 حد سرعت", "pf:mb")],
        [(("✅" if s.get("notify_slow") == "1" else "⬜") + " هشدار کندی", "pf:ns")],
        [(mark(x, h) + ("خاموش" if x == 0 else f"هر {x}h"), f"pf:h:{x}") for x in PF_HOURS],
        [(mark(x, size) + f"{x}MB", f"pf:z:{x}") for x in PF_SIZES],
        [("« تنظیمات", "set")])

PF_ASK = {"ms": ("slow_ms", "⏱ حد پینگ را به میلی‌ثانیه بفرستید (مثلاً 800).\nاگر میانه ۳ تست موفق آخر بیشتر از این باشد، کانفیگ «کند» می‌شود. 0 یعنی خاموش.", 0, 60000),
          "mb": ("slow_mbps", "🚀 حد سرعت را به Mbps بفرستید (مثلاً 5).\nاگر آخرین تست سرعت کمتر از این باشد، کانفیگ «کند» می‌شود. 0 یعنی خاموش.", 0, 10000)}

def _pf_route(args, uid, chat_id, msg_id, cb_id, show):
    act = args[0] if args else "m"
    if act in PF_ASK:
        set_pending(uid, f"pf:{act}", chat_id, msg_id)
        return show(scr_prompt(PF_ASK[act][1]))
    if act == "ns":
        on = get_settings().get("notify_slow") == "1"
        svc_apply_settings({"notify_slow": "0" if on else "1"})
        tg_toast(cb_id, "هشدار کندی خاموش شد" if on else "هشدار کندی روشن شد")
    elif act == "h" and len(args) > 1:
        err = svc_apply_settings({"speed_every_hours": args[1]})
        tg_toast(cb_id, err or "ذخیره شد", alert=bool(err))
    elif act == "z" and len(args) > 1:
        err = svc_apply_settings({"speed_size_mb": args[1]})
        tg_toast(cb_id, err or "ذخیره شد", alert=bool(err))
    return show(scr_perf())

def _pf_pending(text, uid, chat_id, p):
    act = p["kind"].split(":", 1)[1] if ":" in p["kind"] else ""
    if act not in PF_ASK:
        return tg_show(chat_id, scr_perf())
    key, _, lo, hi = PF_ASK[act]
    t = text.strip().translate(PF_FA_DIGITS)
    try:
        ok = lo <= float(t) <= hi and (act != "ms" or float(t).is_integer())
    except ValueError:
        ok = False
    if not ok:
        set_pending(uid, p["kind"], p["chat"], p["msg"])
        return tg_api("sendMessage", {"chat_id": chat_id, "text": f"عددی بین {lo} و {hi} بفرستید" + (" (بدون اعشار)." if act == "ms" else ".")})
    err = svc_apply_settings({key: str(int(float(t))) if act == "ms" else t})
    if err:
        set_pending(uid, p["kind"], p["chat"], p["msg"])
        return tg_api("sendMessage", {"chat_id": chat_id, "text": f"❌ {err}"})
    return tg_show(p["chat"], scr_perf(), p["msg"])

TG_ROUTES["pf"] = _pf_route
TG_PENDING["pf"] = _pf_pending
TG_SETTINGS_ROWS.append([("🐢 کارایی", "pf:m")])

def _pf_config_lines(c):
    st = pf_speed_stats(c["id"])
    out = []
    if st["avg"] is not None:
        tr = pf_trend(st["latest"], st["avg"], st["n"])
        out.append(f"سرعت ۷ روز: آخرین <b>{st['latest']} Mbps</b> · میانگین <b>{st['avg']} Mbps</b> ({st['n']} تست)" + (f" {PF_ARROW[tr]}" if tr else ""))
    if c.get("state") == "slow":
        ms, mbps = pf_limits()
        why = []
        if ms and c.get("pf_median") is not None and c["pf_median"] > ms:
            why.append(f"پینگ {round(c['pf_median'])}ms بیشتر از حد {ms}ms")
        if mbps and c.get("last_speed_mbps") is not None and c["last_speed_mbps"] < mbps:
            why.append(f"سرعت {c['last_speed_mbps']} Mbps کمتر از حد {mbps:g} Mbps")
        out.append("🐢 کند: " + "، ".join(why))
    return out

TG_CONFIG_LINES.append(_pf_config_lines)


def _pf_selftest():
    lim = (500, 10.0)
    # Pure checks only: the installer never runs this, but keep it off the real data anyway.
    orig = globals()["pf_median_latency"]
    try:
        for med, sp, want in ((500, 50, False), (501, 50, True), (None, 50, False), (100, 10.0, False), (100, 9.9, True), (100, None, False)):
            globals()["pf_median_latency"] = lambda cid, n=3, need=None, m=med: m
            assert pf_slow_check({"id": "x", "last_speed_mbps": sp}, lim)[0] is want, (med, sp)
        globals()["pf_median_latency"] = lambda cid, n=3, need=None: 9999
        assert pf_slow_check({"id": "x", "last_speed_mbps": 1}, (0, 0.0))[0] is False
    finally:
        globals()["pf_median_latency"] = orig
    assert _pf_state({"pf_slow": True}, "up") == "slow" and _pf_state({"pf_slow": True}, "down") is None
    assert _pf_state({"pf_slow": False}, "up") is None
    assert pf_trend(110, 100, 2) == "up" and pf_trend(90, 100, 3) == "down" and pf_trend(103, 100, 2) == "flat"
    assert pf_trend(110, 100, 1) is None and pf_trend(None, 100, 5) is None
    assert _pf_rule_mbps("2.55") in ("2.5", "2.6") and _pf_rule_ms("۳۰۰") == "300"
    for rule, bad in ((_pf_rule_ms, "-1"), (_pf_rule_ms, "x"), (SETTING_RULES["speed_every_hours"], "3"), (SETTING_RULES["speed_size_mb"], "50")):
        try:
            rule(bad); assert False, bad
        except ValueError:
            pass
    assert all(len(f"pf:{a}".encode()) <= 64 for a in ("ms", "mb", "ns", "h:24", "z:100", "m"))

SELFTESTS.append(_pf_selftest)



# ---------- Feature: sharing ----------
# Customer feeds: named links /sub/<token>, each with saved filters, its own token and stats.
# The main feed (meta sub_token) keeps working exactly as before and shows up as "Main feed".
# A public, read-only status page at /status/<token>, and the public address every shown link uses.
import ipaddress
import ssl as _ssl

DEF_SETTINGS.update({"status_page": "0", "public_addr": "auto"})
FEED_SORTS = {"recent": "Newest first", "ping": "Lowest ping", "speed": "Highest speed", "best": "Best first"}
FEED_SORTS_FA = {"recent": "جدیدترین", "ping": "کمترین پینگ", "speed": "بیشترین سرعت", "best": "بهترین‌ها"}
FEED_MAX_ITEMS = 1000
SHARE_CLIENT_DAYS = 30            # distinct clients are counted over this many days
STATUS_CACHE_SEC = 30             # the status page is rendered at most this often
STATUS_BARS, STATUS_BAR_SEC = 28, 6 * 3600   # 7 days in 6-hour bars
_share_memo = {}                  # "addr" -> (key, at, value), "status" -> (at, body)
_share_memo_lock = threading.Lock()
_HOST_RE = re.compile(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?")


def _share_migrate(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS feeds (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        token TEXT NOT NULL UNIQUE,
        protocols TEXT NOT NULL DEFAULT '',
        countries TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT '',
        sort TEXT NOT NULL DEFAULT 'recent',
        max_items INTEGER NOT NULL DEFAULT 0,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL,
        fetch_count INTEGER NOT NULL DEFAULT 0,
        last_fetch INTEGER,
        clients INTEGER NOT NULL DEFAULT 0)""")
    # One row per (feed, salted hash of IP + User-Agent); raw IPs are never stored.
    conn.execute("""CREATE TABLE IF NOT EXISTS feed_clients (
        feed_id TEXT NOT NULL,
        client TEXT NOT NULL,
        last_seen INTEGER NOT NULL,
        PRIMARY KEY (feed_id, client))""")
    if "status_hidden" not in [r[1] for r in conn.execute("PRAGMA table_info(configs)")]:
        conn.execute("ALTER TABLE configs ADD COLUMN status_hidden INTEGER DEFAULT 0")
    for k, v in (("status_token", secrets.token_urlsafe(18)), ("feed_salt", secrets.token_hex(16))):
        conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES (?, ?)", (k, v))

MIGRATIONS.append(_share_migrate)


def _share_flag(v):
    return "1" if str(v).strip().lower() in ("1", "true", "on", "yes") else "0"

def _share_rule_status(v):
    _share_forget("status")
    return _share_flag(v)

def share_norm_addr(v):
    """'auto', a domain, an IPv4 or an IPv6 address, each with an optional :port. Returns what to store."""
    s = str(v or "").strip().lower()
    if s in ("", "auto"):
        return "auto"
    s = re.sub(r"^[a-z][a-z0-9+.-]*://", "", s).split("/")[0].strip().rstrip(".")
    host, port = s, ""
    m = re.fullmatch(r"\[([0-9a-f:.]+)\](?::(\d*))?", s)
    if m:
        host, port = m.group(1), m.group(2) or ""
    elif s.count(":") == 1:
        host, port = s.split(":")
    try:
        ip = ipaddress.ip_address(host)
        host = f"[{ip}]" if ip.version == 6 else str(ip)
    except ValueError:
        if not _HOST_RE.fullmatch(host):
            raise ValueError("Public address must be a domain like vpn.example.com, an IP address, or auto")
    if port:
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            raise ValueError("The port in the public address must be between 1 and 65535")
        host += f":{int(port)}"
    return host

def _share_rule_addr(v):
    return share_norm_addr(v)

SETTING_RULES["status_page"] = _share_rule_status
SETTING_RULES["public_addr"] = _share_rule_addr


def _share_forget(key):
    with _share_memo_lock:
        _share_memo.pop(key, None)

# ----- public address -----
def share_cert_file():
    """The certificate setup_ssl serves: SENTINEL_SSL_CERT when it loads, otherwise Sentinel's own."""
    own = (D + "/certs/cert.pem", D + "/certs/key.pem")
    env = (os.getenv("SENTINEL_SSL_CERT", own[0]), os.getenv("SENTINEL_SSL_KEY", own[1]))
    if env != own:
        try:
            _ssl.SSLContext(_ssl.PROTOCOL_TLS_SERVER).load_cert_chain(certfile=env[0], keyfile=env[1])
            return env[0]
        except (OSError, _ssl.SSLError, ValueError):
            pass
    return own[0]

def share_cert_names(path):
    """The DNS names a PEM certificate is issued for: its SAN entries, then its CN."""
    try:
        info = _ssl._ssl._test_decode_cert(path)
    except Exception:
        return []
    names = [v for k, v in info.get("subjectAltName", ()) if k == "DNS"]
    names += [v for rdn in info.get("subject", ()) for k, v in rdn if k == "commonName"]
    return list(dict.fromkeys(str(n).strip().lower().rstrip(".") for n in names if n))

def share_cert_host(path):
    """The first real hostname of the certificate (no wildcards, no bare names like 'sentinel')."""
    for n in share_cert_names(path):
        if not n.startswith("*") and _HOST_RE.fullmatch(n):
            return n
    return None

def _share_https(s=None):
    s = s or get_settings()
    return os.getenv("SENTINEL_USE_HTTPS", "").lower() in ("1", "true", "yes") or s.get("use_https") == "1"

def share_public():
    """Where customers reach this server: {"base": "https://vpn.example.com:2053", "host", "source", "setting"}.
    source is "setting" (typed in), "certificate" (auto, HTTPS on) or "ip" (auto)."""
    s = get_settings()
    https = _share_https(s)
    setting = s.get("public_addr") or "auto"
    key = (setting, https, os.getenv("SENTINEL_SSL_CERT", ""))
    now = time.time()
    with _share_memo_lock:
        m = _share_memo.get("addr")
    if m and m[0] == key and now - m[1] < 60:
        host, source = m[2]
    else:
        if setting != "auto":
            host, source = setting, "setting"
        else:
            host = share_cert_host(share_cert_file()) if https else None
            source = "certificate" if host else "ip"
            if not host:
                ip = get_public_ip()
                host = f"[{ip}]" if ":" in ip else ip
        with _share_memo_lock:
            _share_memo["addr"] = (key, now, (host, source))
    scheme = "https" if https else "http"
    hostport = host
    if not re.search(r":\d+$", host):
        port = str(get_meta("port") or "")
        if port and port != ("443" if https else "80"):
            hostport = f"{host}:{port}"
    elif host.endswith(":443" if https else ":80"):
        hostport = host.rsplit(":", 1)[0]
    bare = re.sub(r":\d+$", "", host).strip("[]")
    return {"base": f"{scheme}://{hostport}", "host": host, "source": source, "setting": setting,
            "https": https, "local": bare in ("127.0.0.1", "::1", "localhost")}

def share_clean_url():
    """The main feed's full public link, or None when the address is unknown (the page then uses its own)."""
    return None if share_public()["local"] else feed_url()

# ----- feeds -----
def _share_split(v, norm=str):
    return [norm(x.strip()) for x in str(v or "").split(",") if x.strip()]

def _share_int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return 0

def _share_feeds():
    with lock:
        return [dict(r) for r in db_conn.execute("SELECT * FROM feeds ORDER BY created_at ASC, id ASC")]

def _share_feed(fid):
    with lock:
        r = db_conn.execute("SELECT * FROM feeds WHERE id=?", (str(fid),)).fetchone()
    return dict(r) if r else None

def share_feed_url(f):
    return f"{share_public()['base']}/sub/{f['token']}"

def _share_client_hash(handler):
    ip = (handler.client_address or ("",))[0]
    ua = (handler.headers.get("User-Agent") or "")[:300]
    salt = (get_meta("feed_salt") or "").encode()
    return hmac.new(salt, f"{ip}\n{ua}".encode("utf-8", "replace"), hashlib.sha256).hexdigest()[:32]

def _share_note_fetch(fid, handler):
    """Count a fetch. Only a salted hash of IP + User-Agent is kept, to count distinct clients."""
    try:
        h, now = _share_client_hash(handler), int(time.time())
        with lock:
            db_conn.execute("INSERT OR REPLACE INTO feed_clients (feed_id, client, last_seen) VALUES (?, ?, ?)", (fid, h, now))
            n = db_conn.execute("SELECT COUNT(*) FROM feed_clients WHERE feed_id=? AND last_seen>=?",
                                (fid, now - SHARE_CLIENT_DAYS * 86400)).fetchone()[0]
            if fid == "main":
                cnt = _share_int(get_meta("main_fetch_count")) + 1
                for k, v in (("main_fetch_count", cnt), ("main_last_fetch", now), ("main_clients", n)):
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (k, str(v)))
            else:
                db_conn.execute("UPDATE feeds SET fetch_count=fetch_count+1, last_fetch=?, clients=? WHERE id=?", (now, n, fid))
            db_conn.commit()
    except Exception as e:
        print("feed stats failed:", e, flush=True)

def _share_merge_qs(f, qs):
    """A feed's saved filters; query parameters may narrow them but never widen them."""
    q = {k: list(v) for k, v in qs.items()}
    for key, col, norm in (("proto", "protocols", str.lower), ("country", "countries", str.upper), ("source", "source", str)):
        saved = _share_split(f.get(col), norm)
        asked = _share_split(q.get(key, [""])[0], norm)
        vals = ([x for x in asked if x in saved] or ["!"]) if saved and asked else (saved or asked)  # "!" matches nothing
        if vals:
            q[key] = [",".join(vals)]
        else:
            q.pop(key, None)
    if f.get("sort") and not q.get("sort", [""])[0].strip():
        q["sort"] = [f["sort"]]
    lims = [x for x in (_share_int(f.get("max_items")), _share_int(q.get("limit", [""])[0])) if x > 0]
    if lims:
        q["limit"] = [str(min(lims))]
    else:
        q.pop("limit", None)
    return q

def share_feed_query(handler, tok, qs):
    """The query to serve /sub/<tok> with, or None for a 404. The main token keeps its query as is.
    Every candidate token is compared in constant time; a disabled feed answers like a wrong token."""
    t = str(tok).encode("utf-8", "replace")
    main = (get_meta("sub_token") or "").encode()
    is_main = bool(main) and hmac.compare_digest(t, main)
    hit = None
    for f in _share_feeds():
        if hmac.compare_digest(t, str(f["token"]).encode()) and hit is None:
            hit = f
    if is_main:
        _share_note_fetch("main", handler)
        return qs
    if not hit or not hit["enabled"]:
        return None
    _share_note_fetch(hit["id"], handler)
    return _share_merge_qs(hit, qs)

def share_source_filter(qs, where, params):
    """?source=<subscription id>,manual keeps configs from those subscriptions (manual: added by hand)."""
    vals = _share_split(qs.get("source", [""])[0])
    if not vals:
        return
    ids = [v for v in vals if v != "manual"]
    parts = []
    if ids:
        parts.append("c.sub_id IN (%s)" % ",".join("?" * len(ids)))
        params.extend(ids)
    if "manual" in vals:
        parts.append("c.sub_id IS NULL")
    where.append("(" + " OR ".join(parts) + ")")

def _share_feed_items(f, states):
    """How many configs a feed serves right now (the same rules as /sub)."""
    pro = set(_share_split(f.get("protocols"), str.lower))
    ccs = set(_share_split(f.get("countries"), str.upper))
    src = set(_share_split(f.get("source")))
    n = 0
    for c in states:
        if not c.get("enabled") or c.get("last_ok") != 1 or c.get("down_since") or c.get("state") == "no_engine":
            continue
        if pro and (c.get("protocol") or "").lower() not in pro:
            continue
        if ccs and (c.get("country_code") or "").upper() not in ccs:
            continue
        if src and not ((c.get("sub_id") or "manual") in src):
            continue
        n += 1
    lim = _share_int(f.get("max_items"))
    return min(n, lim) if lim > 0 else n

def _share_rows(rows):
    """config_states() rows get status_hidden and country_code."""
    with lock:
        extra = {r["id"]: r for r in db_conn.execute("SELECT id, status_hidden, country_code FROM configs")}
    for c in rows:
        e = extra.get(c["id"])
        c["status_hidden"] = (e["status_hidden"] or 0) if e else 0
        c.setdefault("country_code", (e["country_code"] or "") if e else "")

ROW_HOOKS.append(_share_rows)

def _share_clean(name=None, protocols=None, countries=None, source=None, sort=None, max_items=None):
    """Validated column values for the fields given (None = leave alone). Raises ValueError."""
    out = {}
    if name is not None:
        name = re.sub(r"\s+", " ", str(name)).strip()[:60]
        if not name:
            raise ValueError("Give the feed a name")
        out["name"] = name
    if protocols is not None:
        vals = protocols if isinstance(protocols, (list, tuple)) else _share_split(protocols)
        vals = list(dict.fromkeys(str(p).strip().lower() for p in vals if str(p).strip()))
        if any(not re.fullmatch(r"[a-z0-9+_-]{1,24}", p) for p in vals):
            raise ValueError("Unknown protocol")
        out["protocols"] = ",".join(vals)
    if countries is not None:
        vals = countries if isinstance(countries, (list, tuple)) else _share_split(countries)
        vals = list(dict.fromkeys(str(c).strip().upper() for c in vals if str(c).strip()))
        if any(not re.fullmatch(r"[A-Z]{2}", c) for c in vals):
            raise ValueError("Countries are two-letter codes like DE")
        out["countries"] = ",".join(vals)
    if source is not None:
        source = str(source).strip()
        if source not in ("", "manual"):
            with lock:
                if not db_conn.execute("SELECT 1 FROM subscriptions WHERE id=?", (source,)).fetchone():
                    raise ValueError("That subscription does not exist")
        out["source"] = source
    if sort is not None:
        sort = str(sort).strip().lower() or "recent"
        if sort not in FEED_SORTS:
            raise ValueError("Unknown order")
        out["sort"] = sort
    if max_items is not None:
        n = _share_int(max_items) if str(max_items).strip() else 0
        if not str(max_items).strip().isdigit() and str(max_items).strip() or not 0 <= n <= FEED_MAX_ITEMS:
            raise ValueError(f"The limit must be a number from 0 to {FEED_MAX_ITEMS} (0 = no limit)")
        out["max_items"] = n
    return out

def svc_feed_save(fid=None, **fields):
    """Create a feed (fid None, a name is required) or change the fields given. Returns the feed or None."""
    vals = _share_clean(**fields)
    with lock:
        if fid is None:
            if "name" not in vals:
                raise ValueError("Give the feed a name")
            fid = secrets.token_hex(4)
            db_conn.execute("INSERT INTO feeds (id, name, token, created_at) VALUES (?, ?, ?, ?)",
                            (fid, vals["name"], secrets.token_urlsafe(18), int(time.time())))
        elif not db_conn.execute("SELECT 1 FROM feeds WHERE id=?", (str(fid),)).fetchone():
            return None
        for k, v in vals.items():
            db_conn.execute(f"UPDATE feeds SET {k}=? WHERE id=?", (v, str(fid)))
        db_conn.commit()
    return _share_feed(fid)

def svc_feed_rotate(fid):
    """A new link for one feed; the old one stops working. "main" rotates the main feed."""
    if fid == "main":
        return svc_rotate_feed()
    tok = secrets.token_urlsafe(18)
    with lock:
        n = db_conn.execute("UPDATE feeds SET token=? WHERE id=?", (tok, str(fid))).rowcount
        db_conn.commit()
    return tok if n else None

def svc_feed_toggle(fid, enabled=None):
    """Turn a feed on or off; returns the new value, or None if not found."""
    f = _share_feed(fid)
    if not f:
        return None
    v = (0 if f["enabled"] else 1) if enabled is None else (1 if enabled else 0)
    with lock:
        db_conn.execute("UPDATE feeds SET enabled=? WHERE id=?", (v, f["id"]))
        db_conn.commit()
    return v

def svc_feed_delete(fid):
    with lock:
        n = db_conn.execute("DELETE FROM feeds WHERE id=?", (str(fid),)).rowcount
        db_conn.execute("DELETE FROM feed_clients WHERE feed_id=?", (str(fid),))
        db_conn.commit()
    return bool(n)

def _share_prune(s):
    """Hourly: forget client hashes not seen for SHARE_CLIENT_DAYS and recount."""
    now = int(time.time())
    if now - _share_memo.get("pruned", 0) < 3600:
        return
    _share_memo["pruned"] = now
    cut = now - SHARE_CLIENT_DAYS * 86400
    with lock:
        db_conn.execute("DELETE FROM feed_clients WHERE last_seen<?", (cut,))
        db_conn.execute("UPDATE feeds SET clients=(SELECT COUNT(*) FROM feed_clients WHERE feed_id=feeds.id)")
        n = db_conn.execute("SELECT COUNT(*) FROM feed_clients WHERE feed_id='main'").fetchone()[0]
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('main_clients', ?)", (str(n),))
        db_conn.commit()

TICK_HOOKS.append(_share_prune)

# ----- status page -----
def status_url():
    return f"{share_public()['base']}/status/{get_meta('status_token')}"

def svc_status_rotate():
    tok = secrets.token_urlsafe(18)
    with lock:
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('status_token', ?)", (tok,))
        db_conn.commit()
    return tok

def svc_status_hide(cid, hidden=None):
    """Hide a config from the status page or show it again (None toggles). Returns the new value or None."""
    with lock:
        r = db_conn.execute("SELECT status_hidden FROM configs WHERE id=?", (str(cid),)).fetchone()
        if not r:
            return None
        v = (0 if r["status_hidden"] else 1) if hidden is None else (1 if hidden else 0)
        db_conn.execute("UPDATE configs SET status_hidden=? WHERE id=?", (v, str(cid)))
        db_conn.commit()
    _share_forget("status")
    return v

# Customer-facing words for each state, and the colour class.
STATUS_WORDS = {"up": ("Working", "up"), "slow": ("Slow", "wr"), "down": ("Down", "dn"),
                "iran_only": ("Down outside Iran", "dn"), "fail": ("Unstable", "wr"),
                "no_engine": ("Not monitored", "no"), "new": ("Not checked yet", "no"), "paused": ("Paused", "no")}
_IP_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b|\[?[0-9a-f]{0,4}(?::[0-9a-f]{0,4}){2,7}\]?(?::\d+)?", re.I)

def share_public_name(c, n):
    """A config's name without its own host or any IP in it; "Server n" when nothing is left."""
    name = str(c.get("name") or "")
    host = str(c.get("addr") or "").rsplit(":", 1)[0].strip("[]")
    if host:
        name = re.sub(re.escape(host) + r"(?::\d+)?", " ", name, flags=re.I)
    name = re.sub(r"\s+", " ", _IP_RE.sub(" ", name)).strip(" -_|:·,")
    return name if re.search(r"\w", name) else f"Server {n}"

def _share_ago(sec):
    sec = max(0, int(sec))
    if sec < 90:
        return "just now"
    if sec < 3600:
        return f"{round(sec / 60)} min ago"
    if sec < 86400:
        h = round(sec / 3600)
        return f"{h} hour{'s' if h != 1 else ''} ago"
    d = round(sec / 86400)
    return f"{d} day{'s' if d != 1 else ''} ago"

def _share_pct(up, n):
    if not n:
        return "—"
    p = 100.0 * up / n
    return f"{p:.1f}%" if p < 99.95 else "100%"

def share_status_html(now=None):
    """The public status page. It has names, states and uptime only: no address, link, IP or panel path."""
    now = int(now or time.time())
    start = now - STATUS_BARS * STATUS_BAR_SEC
    cs = [c for c in config_states() if c.get("enabled") and not c.get("status_hidden")]
    # A separate read connection: WAL lets it run without holding the global lock.
    conn = get_db()
    try:
        rows = conn.execute("SELECT config_id, (checked_at - ?) / ? AS b, COUNT(*) AS n, SUM(ok) AS up FROM checks "
                            "WHERE checked_at >= ? GROUP BY config_id, b", (start, STATUS_BAR_SEC, start)).fetchall()
    finally:
        conn.close()
    buckets = {}
    for r in rows:
        if 0 <= r["b"] < STATUS_BARS:
            buckets.setdefault(r["config_id"], {})[r["b"]] = (r["n"], r["up"] or 0)
    try:
        every = max(2, int(get_settings().get("interval", 30)))
    except ValueError:
        every = 30
    e = lambda v: _html.escape(str(v), quote=True)
    items, counts = [], {"up": 0, "wr": 0, "dn": 0, "no": 0}
    cs.sort(key=lambda c: (str(c.get("name") or "").lower(), c["id"]))
    for i, c in enumerate(cs, 1):
        word, cls = STATUS_WORDS.get(c["state"], ("Unknown", "no"))
        counts[cls] += 1
        b = buckets.get(c["id"], {})
        bars = []
        for k in range(STATUS_BARS):
            t0 = start + k * STATUS_BAR_SEC
            span = time.strftime("%a %d %b %H:%M", time.gmtime(t0)) + "–" + time.strftime("%H:%M UTC", time.gmtime(t0 + STATUS_BAR_SEC))
            n, up = b.get(k, (0, 0))
            if not n:
                bars.append(f'<i title="{e(span)}: no checks"></i>')
                continue
            p = 100.0 * up / n
            k_cls = "up" if p >= 99 else "dn" if p < 50 else "wr"
            bars.append(f'<i class="{k_cls}" title="{e(span)}: {e(_share_pct(up, n))} up"></i>')
        d_n = sum(n for k, (n, _) in b.items() if k >= STATUS_BARS - 4)
        d_up = sum(u for k, (_, u) in b.items() if k >= STATUS_BARS - 4)
        w_n = sum(n for n, _ in b.values())
        w_up = sum(u for _, u in b.values())
        checked = f"Checked {_share_ago(now - c['last_check'])}" if c.get("last_check") else "Not checked yet"
        items.append(
            f'<li><div class="top"><span class="nm">{e(share_public_name(c, i))}</span>'
            f'<span class="st {cls}"><span class="dot"></span>{e(word)}</span></div>'
            f'<div class="bars" role="img" aria-label="Uptime over the last 7 days">{"".join(bars)}</div>'
            f'<div class="ax"><span>7 days ago</span><span>Now</span></div>'
            f'<div class="meta"><span>24 hours <b>{_share_pct(d_up, d_n)}</b></span>'
            f'<span>7 days <b>{_share_pct(w_up, w_n)}</b></span><span>{e(checked)}</span></div></li>')
    if not cs:
        summary, scls = "No servers to show yet.", "no"
    elif counts["dn"]:
        summary, scls = f"{counts['dn']} of {len(cs)} server{'s are' if counts['dn'] != 1 else ' is'} down", "dn"
    elif counts["wr"]:
        summary, scls = f"{counts['wr']} of {len(cs)} server{'s are' if counts['wr'] != 1 else ' is'} slow or unstable", "wr"
    elif counts["up"] == len(cs):
        summary, scls = f"All {len(cs)} server{'s are' if len(cs) != 1 else ' is'} working", "up"
    else:
        summary, scls = f"{counts['up']} of {len(cs)} servers are working", "up"
    every_s = f"{every} seconds" if every < 120 else f"{round(every / 60)} minutes" if every < 7200 else f"{round(every / 3600)} hours"
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="60">
<meta name="robots" content="noindex,nofollow">
<meta name="referrer" content="no-referrer">
<meta name="color-scheme" content="light dark">
<title>Service status</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='6' fill='%2310b981'/%3E%3C/svg%3E">
<style>
:root{{--bg:#f5f6f8;--card:#fff;--tx:#17191d;--mu:#5c636e;--ln:#e2e5e9;--up:#10b981;--dn:#ef4444;--wr:#f59e0b;--no:#c9ced6}}
@media (prefers-color-scheme:dark){{:root{{--bg:#0c0d10;--card:#16181d;--tx:#eceef1;--mu:#9aa1ac;--ln:#272b32;--no:#3a3f48}}}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,"Vazirmatn",sans-serif;-webkit-text-size-adjust:100%}}
main{{max-width:760px;margin:0 auto;padding:32px 16px 40px}}
h1{{font-size:22px;line-height:1.3;margin:0}}
.sum{{display:flex;align-items:center;gap:10px;margin:18px 0 20px;padding:14px 16px;background:var(--card);border:1px solid var(--ln);border-radius:12px;font-weight:600}}
.dot{{width:10px;height:10px;border-radius:50%;flex:none;background:var(--no)}}
.up .dot{{background:var(--up)}}.dn .dot{{background:var(--dn)}}.wr .dot{{background:var(--wr)}}
ul{{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:10px}}
li{{background:var(--card);border:1px solid var(--ln);border-radius:12px;padding:14px 16px}}
.top{{display:flex;align-items:center;justify-content:space-between;gap:12px}}
.nm{{font-weight:600;min-width:0;overflow-wrap:anywhere}}
.st{{display:inline-flex;align-items:center;gap:7px;font-size:13px;font-weight:600;white-space:nowrap;color:var(--mu)}}
.st.up{{color:var(--up)}}.st.dn{{color:var(--dn)}}.st.wr{{color:var(--wr)}}
.bars{{display:flex;gap:2px;height:26px;margin:12px 0 4px}}
.bars i{{flex:1;min-width:0;border-radius:2px;background:var(--no)}}
.bars i.up{{background:var(--up)}}.bars i.dn{{background:var(--dn)}}.bars i.wr{{background:var(--wr)}}
.ax{{display:flex;justify-content:space-between;font-size:11.5px;color:var(--mu)}}
.meta{{display:flex;flex-wrap:wrap;gap:4px 18px;margin-top:8px;font-size:13px;color:var(--mu)}}
.meta b{{color:var(--tx);font-weight:600;font-variant-numeric:tabular-nums}}
footer{{margin-top:22px;font-size:12.5px;color:var(--mu)}}
@media (max-width:420px){{main{{padding-top:22px}}.top{{flex-wrap:wrap}}.bars{{gap:1px}}}}
</style></head>
<body><main>
<h1>Service status</h1>
<div class="sum {scls}"><span class="dot"></span><span>{e(summary)}</span></div>
<ul>{"".join(items)}</ul>
<footer>Every server is checked automatically every {e(every_s)}. Updated {e(time.strftime("%d %b %Y, %H:%M UTC", time.gmtime(now)))}; this page refreshes every minute.</footer>
</main></body></html>
"""

def _share_status_route(h, method, path, qs):
    if method != "GET" or not path.startswith("/status/"):
        return False
    tok = path[len("/status/"):].strip("/").encode("utf-8", "replace")
    real = (get_meta("status_token") or "").encode()
    ok = hmac.compare_digest(tok, real) and bool(real)
    if not ok or get_settings().get("status_page") != "1":
        h.out(404, "Not found", "text/plain")
        return True
    now = time.time()
    with _share_memo_lock:
        m = _share_memo.get("status")
    if m and now - m[0] < STATUS_CACHE_SEC:
        body = m[1]
    else:
        body = share_status_html(now).encode("utf-8")
        with _share_memo_lock:
            _share_memo["status"] = (now, body)
    gz = "gzip" in (h.headers.get("Accept-Encoding") or "")
    out = gzip.compress(body, 6) if gz else body
    h.send_response(200)
    for k, v in (("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(out))),
                 ("Cache-Control", "no-store"), ("X-Frame-Options", "DENY"), ("X-Content-Type-Options", "nosniff"),
                 ("Referrer-Policy", "no-referrer"), ("X-Robots-Tag", "noindex, nofollow"),
                 ("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")):
        h.send_header(k, v)
    if gz:
        h.send_header("Content-Encoding", "gzip")
    h.end_headers()
    h.wfile.write(out)
    return True

PUBLIC_ROUTES.append(_share_status_route)

# ----- web API -----
def share_overview():
    states = config_states()
    with lock:
        subs = [dict(r) for r in db_conn.execute("SELECT id, name FROM subscriptions ORDER BY created_at DESC")]
        countries = [dict(r) for r in db_conn.execute(
            "SELECT DISTINCT country_code AS code, country_name AS name FROM configs WHERE country_code != '' AND country_code != 'XX' ORDER BY country_code")]
    for cc in countries:
        cc["flag"] = country_flag(cc["code"])
    sub_names = {s["id"]: s["name"] for s in subs}
    feeds = []
    for f in _share_feeds():
        feeds.append({
            "id": f["id"], "name": f["name"], "url": share_feed_url(f), "enabled": f["enabled"],
            "protocols": _share_split(f["protocols"]), "countries": _share_split(f["countries"]),
            "source": f["source"], "source_name": "Added by hand" if f["source"] == "manual" else sub_names.get(f["source"], "Deleted subscription") if f["source"] else "",
            "sort": f["sort"], "max_items": f["max_items"], "created_at": f["created_at"],
            "fetch_count": f["fetch_count"], "last_fetch": f["last_fetch"], "clients": f["clients"],
            "items": _share_feed_items(f, states)})
    s = get_settings()
    return {
        "public": share_public(),
        "main": {"id": "main", "name": "Main feed", "url": feed_url(), "enabled": 1,
                 "fetch_count": _share_int(get_meta("main_fetch_count")), "last_fetch": _share_int(get_meta("main_last_fetch")) or None,
                 "clients": _share_int(get_meta("main_clients")), "items": _share_feed_items({}, states)},
        "feeds": feeds,
        "status": {"enabled": s.get("status_page") == "1", "url": status_url(),
                   "hidden": sum(1 for c in states if c.get("status_hidden")),
                   "shown": sum(1 for c in states if c.get("enabled") and not c.get("status_hidden"))},
        "options": {"protocols": sorted({c["protocol"] for c in states if c.get("protocol")}),
                    "countries": countries, "subs": subs, "sorts": FEED_SORTS},
        "client_days": SHARE_CLIENT_DAYS,
    }

def _api_share(h, method, b, qs):
    return h.out(200, share_overview())

def _api_share_feed(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    fid = str(b.get("id") or "").strip() or None
    fields = {k: b[k] for k in ("name", "protocols", "countries", "source", "sort", "max_items") if k in b}
    try:
        f = svc_feed_save(fid, **fields)
    except ValueError as e:
        return h.out(400, {"error": str(e)})
    return h.out(200, {"ok": True, "id": f["id"]}) if f else h.out(404, {"error": "Feed not found"})

def _api_share_feed_rotate(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    return h.out(200, {"ok": True}) if svc_feed_rotate(str(b.get("id", ""))) else h.out(404, {"error": "Feed not found"})

def _api_share_feed_toggle(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    v = svc_feed_toggle(str(b.get("id", "")), b.get("enabled"))
    return h.out(200, {"ok": True, "enabled": v}) if v is not None else h.out(404, {"error": "Feed not found"})

def _api_share_feed_delete(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    return h.out(200, {"ok": True}) if svc_feed_delete(str(b.get("id", ""))) else h.out(404, {"error": "Feed not found"})

def _api_share_status_rotate(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    svc_status_rotate()
    return h.out(200, {"ok": True, "url": status_url()})

def _api_share_status_hide(h, method, b, qs):
    if method != "POST":
        return h.out(405, {"error": "POST only"})
    v = svc_status_hide(str(b.get("id", "")), b.get("hidden"))
    return h.out(200, {"ok": True, "hidden": v}) if v is not None else h.out(404, {"error": "Config not found"})

API_ROUTES.update({"share": _api_share, "share/feed": _api_share_feed, "share/feed/rotate": _api_share_feed_rotate,
                   "share/feed/toggle": _api_share_feed_toggle, "share/feed/delete": _api_share_feed_delete,
                   "share/status/rotate": _api_share_status_rotate, "share/status/hide": _api_share_status_hide})

# ----- bot -----
SHARE_SRC_FA = {"setting": "تنظیم دستی", "certificate": "از گواهی HTTPS", "ip": "IP سرور"}

def _sh_ago(ts):
    return f"{format_dur(int(time.time()) - ts)} پیش" if ts else "هنوز نه"

def scr_share():
    p = share_public()
    on = get_settings().get("status_page") == "1"
    feeds = _share_feeds()
    mc = _share_int(get_meta("main_fetch_count"))
    text = ("👥 <b>فیدهای مشتری‌ها</b>\n\n"
            "برای هر مشتری یک لینک جدا با فیلترهای خودش بسازید. هر لینک را می‌شود جدا عوض یا خاموش کرد و بقیه دست نمی‌خورند.\n\n"
            f"⭐ فید اصلی: {mc} بار دریافت · {_share_int(get_meta('main_clients'))} کاربر\n"
            f"📚 فیدها: <b>{len(feeds)}</b>\n"
            f"📊 صفحه وضعیت عمومی: <b>{'روشن' if on else 'خاموش'}</b>\n"
            f"🌐 آدرس لینک‌ها: <code>{H(p['base'])}</code> ({SHARE_SRC_FA[p['source']]})")
    rows = [[("⭐ فید اصلی", "fd")]]
    rows += [[(f"{'🟢' if f['enabled'] else '⏸'} {f['name'][:36]}", f"sh:f:{f['id']}")] for f in feeds]
    rows += [[("➕ فید جدید", "sh:new")], [("📊 صفحه وضعیت", "sh:st"), ("🌐 آدرس عمومی", "sh:pa")], [BACK]]
    return text, kb(*rows)

def scr_share_feed(fid):
    f = _share_feed(fid)
    if not f:
        return "این فید دیگر وجود ندارد.", kb([("« فیدها", "sh:m")])
    with lock:
        sub = db_conn.execute("SELECT name FROM subscriptions WHERE id=?", (f["source"],)).fetchone() if f["source"] not in ("", "manual") else None
    src = "همه" if not f["source"] else "فقط دستی" if f["source"] == "manual" else (sub["name"] if sub else "ساب حذف‌شده")
    ccs = _share_split(f["countries"])
    lines = [f"{'🟢' if f['enabled'] else '⏸'} <b>{H(f['name'])}</b>" + ("" if f["enabled"] else " — غیرفعال؛ لینکش جواب نمی‌دهد"),
             "", f"<code>{H(share_feed_url(f))}</code>", "",
             f"🧩 پروتکل‌ها: <b>{H(', '.join(p.upper() for p in _share_split(f['protocols'])) or 'همه')}</b>",
             f"🌍 کشورها: <b>{H(' '.join(country_flag(c) + c for c in ccs) or 'همه')}</b>",
             f"📦 منبع: <b>{H(src)}</b>",
             f"↕️ ترتیب: <b>{FEED_SORTS_FA.get(f['sort'], f['sort'])}</b> · سقف: <b>{f['max_items'] or 'بدون سقف'}</b>",
             f"📡 الان <b>{_share_feed_items(f, config_states())}</b> کانفیگ سالم در این لینک است.",
             "", f"📥 دریافت: <b>{f['fetch_count']}</b> بار · آخرین: {_sh_ago(f['last_fetch'])}",
             f"👤 کاربرهای مختلف ({SHARE_CLIENT_DAYS} روز): <b>{f['clients']}</b>"]
    i = f["id"]
    return "\n".join(lines), kb(
        [("✏️ تغییر نام", f"sh:rn:{i}"), ("🔢 سقف تعداد", f"sh:lm:{i}")],
        [("🧩 پروتکل‌ها", f"sh:fp:{i}"), ("🌍 کشورها", f"sh:fc:{i}"), ("📦 منبع", f"sh:fs:{i}")],
        [(("• " if f["sort"] == k else "") + lbl, f"sh:so:{i}:{k}") for k, lbl in FEED_SORTS_FA.items()],
        [("⏸ غیرفعال کن" if f["enabled"] else "▶ فعال کن", f"sh:en:{i}"), ("🔁 عوض کردن لینک", f"sh:rx:{i}")],
        [("🗑 حذف", f"sh:dx:{i}"), ("« فیدها", "sh:m")])

def scr_share_pick(fid, what):
    """Choose protocols (p), countries (c) or the subscription source (s) of a feed."""
    f = _share_feed(fid)
    if not f:
        return "این فید دیگر وجود ندارد.", kb([("« فیدها", "sh:m")])
    i, mark = f["id"], lambda on: "✅" if on else "⬜"
    with lock:
        if what == "p":
            opts = [r[0] for r in db_conn.execute("SELECT DISTINCT LOWER(protocol) FROM configs WHERE protocol IS NOT NULL AND protocol != '' ORDER BY 1")]
        elif what == "c":
            opts = [r[0] for r in db_conn.execute("SELECT DISTINCT UPPER(country_code) FROM configs WHERE country_code != '' AND country_code != 'XX' ORDER BY 1")]
        else:
            opts = [(r["id"], r["name"]) for r in db_conn.execute("SELECT id, name FROM subscriptions ORDER BY created_at DESC")]
    if what in ("p", "c"):
        col, act = ("protocols", "tp") if what == "p" else ("countries", "tc")
        cur = _share_split(f[col], str.lower if what == "p" else str.upper)
        opts = list(dict.fromkeys(opts + cur))[:30]
        title = "🧩 <b>پروتکل‌ها</b>" if what == "p" else "🌍 <b>کشورها</b>"
        text = f"{title} — {H(f['name'])}\n\nروی هر مورد بزنید تا اضافه یا حذف شود. اگر هیچ‌کدام انتخاب نشود، همه سرو می‌شوند."
        btn = [(f"{mark(o in cur)} {o.upper() if what == 'p' else country_flag(o) + ' ' + o}", f"sh:{act}:{i}:{o}") for o in opts]
        rows = [btn[k:k + 3] for k in range(0, len(btn), 3)]
        rows.append([(f"{mark(not cur)} همه", f"sh:{act}:{i}:*")])
    else:
        text = f"📦 <b>منبع</b> — {H(f['name'])}\n\nفقط کانفیگ‌های یک ساب، یا فقط کانفیگ‌هایی که دستی اضافه شده‌اند."
        rows = [[(f"{mark(not f['source'])} همه", f"sh:ss:{i}:*"), (f"{mark(f['source'] == 'manual')} فقط دستی", f"sh:ss:{i}:manual")]]
        rows += [[(f"{mark(f['source'] == sid)} {nm[:36]}", f"sh:ss:{i}:{sid}")] for sid, nm in opts]
    rows.append([("« این فید", f"sh:f:{i}")])
    return text, kb(*rows)

def scr_share_status():
    on = get_settings().get("status_page") == "1"
    cs = config_states()
    hidden = sum(1 for c in cs if c.get("status_hidden"))
    text = ("📊 <b>صفحه وضعیت عمومی</b>\n\n"
            "یک صفحه فقط‌خواندنی برای مشتری‌ها: اسم و وضعیت هر کانفیگ، آپتایم ۲۴ ساعت و ۷ روز. "
            "هیچ آدرس، لینک کانفیگ یا IP ای در آن نیست.\n\n"
            f"وضعیت: <b>{'روشن' if on else 'خاموش'}</b>\n" +
            (f"🔗 <code>{H(status_url())}</code>\n" if on else "") +
            f"🙈 کانفیگ‌های پنهان: <b>{hidden}</b>\n"
            "برای پنهان کردن یک کانفیگ، در صفحه همان کانفیگ «پنهان در صفحه وضعیت» را بزنید.")
    rows = [[("🔴 خاموش کن" if on else "🟢 روشن کن", "sh:sp")]]
    if on:
        rows.append([("🔁 عوض کردن لینک", "sh:sx")])
    rows.append([("« فیدها", "sh:m"), BACK])
    return text, kb(*rows)

def scr_share_addr():
    p = share_public()
    auto = p["setting"] == "auto"
    text = ("🌐 <b>آدرس عمومی</b>\n\nلینک فیدها و صفحه وضعیت با این آدرس ساخته می‌شوند.\n\n"
            f"تنظیم: <b>{'خودکار' if auto else H(p['setting'])}</b>\n"
            f"الان: <code>{H(p['base'])}</code> ({SHARE_SRC_FA[p['source']]})\n\n"
            "در حالت خودکار، وقتی HTTPS روشن است دامنه‌ی گواهی و وقتی خاموش است IP سرور استفاده می‌شود.")
    rows = [[("✏️ تنظیم دامنه یا IP", "sh:pe")]]
    if not auto:
        rows.append([("🔄 برگرد به خودکار", "sh:pauto")])
    rows.append([("« فیدها", "sh:m"), BACK])
    return text, kb(*rows)

def _sh_route(a, uid, chat_id, msg_id, cb_id, show):
    act = a[0] if a else "m"
    fid = a[1] if len(a) > 1 else ""
    val = ":".join(a[2:])
    if act == "m":
        return show(scr_share())
    if act == "f":
        return show(scr_share_feed(fid))
    if act == "new":
        set_pending(uid, "sh:new", chat_id, msg_id)
        return show(scr_prompt("➕ اسم فید جدید را بفرستید (مثلاً اسم مشتری)."))
    if act in ("rn", "lm"):
        if not _share_feed(fid):
            return show(scr_share_feed(fid))
        set_pending(uid, f"sh:{act}:{fid}", chat_id, msg_id)
        return show(scr_prompt("✏️ اسم جدید این فید را بفرستید." if act == "rn" else
                               f"🔢 حداکثر چند کانفیگ در این لینک باشد؟ یک عدد از ۰ تا {FEED_MAX_ITEMS} بفرستید (۰ یعنی بدون سقف)."))
    if act in ("fp", "fc", "fs"):
        return show(scr_share_pick(fid, act[1]))
    if act in ("tp", "tc", "ss", "so"):
        f = _share_feed(fid)
        if not f:
            return show(scr_share_feed(fid))
        if act in ("tp", "tc"):
            col = "protocols" if act == "tp" else "countries"
            cur = _share_split(f[col], str.lower if act == "tp" else str.upper)
            v = val.lower() if act == "tp" else val.upper()
            cur = [] if val == "*" else [x for x in cur if x != v] if v in cur else cur + [v]
            svc_feed_save(fid, **{col: cur})
            return show(scr_share_pick(fid, "p" if act == "tp" else "c"))
        if act == "ss":
            svc_feed_save(fid, source="" if val == "*" else val)
        else:
            svc_feed_save(fid, sort=val)
        return show(scr_share_feed(fid))
    if act == "en":
        v = svc_feed_toggle(fid)
        if v is not None:
            tg_toast(cb_id, "فید فعال شد" if v else "فید غیرفعال شد؛ لینکش دیگر جواب نمی‌دهد")
        return show(scr_share_feed(fid))
    if act == "rx":
        return show(scr_confirm("🔁 لینک این فید عوض شود؟ لینک فعلی از کار می‌افتد و این مشتری باید لینک جدید را وارد کند.",
                                f"sh:r!:{fid}", f"sh:f:{fid}", "عوض کن"))
    if act == "r!":
        if svc_feed_rotate(fid):
            tg_toast(cb_id, "لینک عوض شد")
        return show(scr_share_feed(fid))
    if act == "dx":
        f = _share_feed(fid)
        if not f:
            return show(scr_share())
        return show(scr_confirm(f"🗑 فید <b>{H(f['name'])}</b> حذف شود؟ لینکش از کار می‌افتد. این کار برگشت ندارد.",
                                f"sh:d!:{fid}", f"sh:f:{fid}", "حذف کن"))
    if act == "d!":
        svc_feed_delete(fid)
        tg_toast(cb_id, "حذف شد")
        return show(scr_share())
    if act == "st":
        return show(scr_share_status())
    if act == "sp":
        on = get_settings().get("status_page") == "1"
        svc_apply_settings({"status_page": "0" if on else "1"})
        tg_toast(cb_id, "صفحه وضعیت خاموش شد" if on else "صفحه وضعیت روشن شد")
        return show(scr_share_status())
    if act == "sx":
        return show(scr_confirm("🔁 لینک صفحه وضعیت عوض شود؟ لینک فعلی از کار می‌افتد.", "sh:s!", "sh:st", "عوض کن"))
    if act == "s!":
        svc_status_rotate()
        tg_toast(cb_id, "لینک عوض شد")
        return show(scr_share_status())
    if act == "pa":
        return show(scr_share_addr())
    if act == "pe":
        set_pending(uid, "sh:pa", chat_id, msg_id)
        return show(scr_prompt("🌐 دامنه یا IP ای را بفرستید که مشتری‌ها با آن به این سرور وصل می‌شوند، مثلاً <code>vpn.example.com</code>.\n"
                               "اگر پورت فرق دارد، آن را هم بنویسید: <code>vpn.example.com:443</code>\n"
                               "برای حالت خودکار، <code>auto</code> بفرستید."))
    if act == "pauto":
        svc_apply_settings({"public_addr": "auto"})
        tg_toast(cb_id, "آدرس خودکار شد")
        return show(scr_share_addr())
    if act == "hc":
        v = svc_status_hide(fid)
        if v is not None:
            tg_toast(cb_id, "در صفحه وضعیت پنهان شد" if v else "در صفحه وضعیت نشان داده می‌شود")
        return show(scr_config(fid))
    return tg_toast(cb_id)

def _sh_pending(t, uid, chat_id, p):
    kind = p["kind"].split(":")
    back = lambda scr: tg_show(p["chat"], scr, p["msg"])
    def again(msg):
        set_pending(uid, p["kind"], p["chat"], p["msg"])
        return tg_api("sendMessage", {"chat_id": chat_id, "text": msg, "parse_mode": "HTML"})
    act, fid = kind[1], (kind[2] if len(kind) > 2 else "")
    if act == "new":
        if not t.strip():
            return again("یک اسم بفرستید.")
        return back(scr_share_feed(svc_feed_save(None, name=t)["id"]))
    if act == "rn":
        if not t.strip():
            return again("یک اسم بفرستید.")
        svc_feed_save(fid, name=t)
        return back(scr_share_feed(fid))
    if act == "lm":
        n = t.strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
        if not n.isdigit() or int(n) > FEED_MAX_ITEMS:
            return again(f"یک عدد از ۰ تا {FEED_MAX_ITEMS} بفرستید (۰ یعنی بدون سقف).")
        svc_feed_save(fid, max_items=int(n))
        return back(scr_share_feed(fid))
    if act == "pa":
        if svc_apply_settings({"public_addr": t}):
            return again("❌ این آدرس درست نیست. یک دامنه مثل <code>vpn.example.com</code>، یک IP، یا <code>auto</code> بفرستید.")
        return back(scr_share_addr())

TG_ROUTES["sh"] = _sh_route
TG_PENDING["sh"] = _sh_pending
TG_MAIN_ROWS.append([("👥 فیدهای مشتری‌ها و صفحه وضعیت", "sh:m")])
TG_CONFIG_LINES.append(lambda c: ["🙈 در صفحه وضعیت عمومی پنهان است"]
                       if c.get("status_hidden") and get_settings().get("status_page") == "1" else [])
TG_CONFIG_ROWS.append(lambda c: [[("👁 نمایش در صفحه وضعیت" if c.get("status_hidden") else "🙈 پنهان در صفحه وضعیت", f"sh:hc:{c['id']}")]]
                      if get_settings().get("status_page") == "1" else [])

# ----- selftest -----
def _share_selftest():
    """Runs on any database: everything it changes is put back afterwards."""
    keys_s, keys_m = ("public_addr", "status_page"), ("public_ip", "main_fetch_count", "main_last_fetch", "main_clients")
    with lock:
        saved_s = {k: db_conn.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone() for k in keys_s}
        saved_m = {k: db_conn.execute("SELECT value FROM meta WHERE key=?", (k,)).fetchone() for k in keys_m}
        main_clients = [tuple(r) for r in db_conn.execute("SELECT feed_id, client, last_seen FROM feed_clients WHERE feed_id='main'")]
        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('public_ip', '203.0.113.9')")
        db_conn.commit()
    state = {"cid": "st" + secrets.token_hex(3), "fid": None}
    _share_forget("addr")
    try:
        # Addresses
        assert share_norm_addr("") == "auto" and share_norm_addr(" AUTO ") == "auto"
        assert share_norm_addr("https://VPN.Example.com/") == "vpn.example.com"
        assert share_norm_addr("vpn.example.com:2053") == "vpn.example.com:2053"
        assert share_norm_addr("1.2.3.4") == "1.2.3.4" and share_norm_addr("2001:db8::1") == "[2001:db8::1]"
        assert share_norm_addr("[2001:db8::1]:443") == "[2001:db8::1]:443"
        for bad in ("sentinel", "bad host.com", "1.2.3.4:99999", "-x.example.com", "a..b", "vpn.example.com:0", "<b>.com"):
            try:
                share_norm_addr(bad)
                assert False, bad
            except ValueError:
                pass
        before = get_settings().get("public_addr")
        assert svc_apply_settings({"public_addr": "not a host"}) and get_settings().get("public_addr") == before
        assert svc_apply_settings({"public_addr": "cdn.example.org"}) is None
        port, scheme = get_meta("port"), "https" if _share_https() else "http"
        want = f"{scheme}://cdn.example.org" + ("" if port == ("443" if scheme == "https" else "80") else f":{port}")
        assert share_public()["base"] == want and share_public()["source"] == "setting", share_public()
        assert feed_url().startswith(want + "/sub/") and status_url().startswith(want + "/status/")
        # Filters: saved ones may only be narrowed by the query
        f = {"protocols": "vless,trojan", "countries": "DE", "source": "", "sort": "ping", "max_items": 5}
        q = _share_merge_qs(f, {"proto": ["vless,vmess"], "limit": ["50"], "format": ["plain"]})
        assert q == {"proto": ["vless"], "country": ["DE"], "sort": ["ping"], "limit": ["5"], "format": ["plain"]}, q
        assert _share_merge_qs(f, {"proto": ["vmess"]})["proto"] == ["!"]
        assert _share_merge_qs(f, {"sort": ["speed"], "limit": ["2"]})["sort"] == ["speed"]
        assert _share_merge_qs(f, {"limit": ["2"]})["limit"] == ["2"]
        assert _share_merge_qs({"protocols": "", "countries": "", "source": "", "sort": "", "max_items": 0}, {}) == {}
        w, prm = [], []
        share_source_filter({"source": ["ab12cd34,manual"]}, w, prm)
        assert w == ["(c.sub_id IN (?) OR c.sub_id IS NULL)"] and prm == ["ab12cd34"]
        # Feed life cycle
        fd = svc_feed_save(None, name="  Shop  A ", protocols=["VLESS"], max_items="3")
        state["fid"] = fd["id"]
        assert fd["name"] == "Shop A" and fd["protocols"] == "vless" and fd["max_items"] == 3 and fd["enabled"] == 1
        for bad in ({"name": " "}, {"sort": "x"}, {"countries": ["DEU"]}, {"max_items": "-1"}, {"source": "nope"}):
            try:
                svc_feed_save(fd["id"], **bad)
                assert False, bad
            except ValueError:
                pass
        class _H:
            client_address = ("198.51.100.77", 5555)
            headers = {"User-Agent": "selftest-agent"}
        assert share_feed_query(_H(), fd["token"], {}) == {"proto": ["vless"], "sort": ["recent"], "limit": ["3"]}
        assert share_feed_query(_H(), fd["token"] + "x", {}) is None and share_feed_query(_H(), "é" * 5, {}) is None
        assert share_feed_query(_H(), get_meta("sub_token"), {"sort": ["ping"]}) == {"sort": ["ping"]}
        old = fd["token"]
        svc_feed_rotate(fd["id"])
        assert share_feed_query(_H(), old, {}) is None
        svc_feed_toggle(fd["id"])
        assert share_feed_query(_H(), _share_feed(fd["id"])["token"], {}) is None
        with lock:
            dump = "\n".join(db_conn.iterdump())
        assert "198.51.100.77" not in dump and "selftest-agent" not in dump
        assert _share_feed(fd["id"])["fetch_count"] == 1 and _share_feed(fd["id"])["clients"] == 1
        assert svc_feed_delete(fd["id"]) and not _share_feed(fd["id"])
        # Status page: names only, never the address
        cid = state['cid']
        with lock:
            db_conn.execute("INSERT INTO configs (id, name, uri, addr, port, protocol, created_at) VALUES (?,?,?,?,?,?,?)",
                            (cid, "edge9.example.net:443", "trojan://pw@edge9.example.net:443#x", "edge9.example.net:443", 65001, "trojan", int(time.time())))
            db_conn.execute("INSERT INTO checks (config_id, ok, latency_ms, checked_at) VALUES (?, 1, 80, ?)", (cid, int(time.time()) - 60))
            db_conn.commit()
        page = share_status_html()
        assert "Server " in page and "edge9" not in page and "trojan://" not in page and get_meta("path") not in page
        assert "/static" not in page and "203.0.113.9" not in page and "100%" in page
        shown = page.count("<li>")
        assert svc_status_hide(cid) == 1 and share_status_html().count("<li>") == shown - 1
        assert share_public_name({"name": "🇩🇪 Berlin 10.1.2.3", "addr": "x.example.com:1"}, 1) == "🇩🇪 Berlin"
    finally:
        with lock:
            for table, saved in (("settings", saved_s), ("meta", saved_m)):
                for k, r in saved.items():
                    if r is None:
                        db_conn.execute(f"DELETE FROM {table} WHERE key=?", (k,))
                    else:
                        db_conn.execute(f"INSERT OR REPLACE INTO {table} (key, value) VALUES (?, ?)", (k, r[0]))
            db_conn.execute("DELETE FROM feed_clients WHERE feed_id='main'")
            db_conn.executemany("INSERT INTO feed_clients (feed_id, client, last_seen) VALUES (?, ?, ?)", main_clients)
            db_conn.execute("DELETE FROM configs WHERE id=?", (state["cid"],))
            db_conn.execute("DELETE FROM checks WHERE config_id=?", (state["cid"],))
            if state["fid"]:
                db_conn.execute("DELETE FROM feeds WHERE id=?", (state["fid"],))
                db_conn.execute("DELETE FROM feed_clients WHERE feed_id=?", (state["fid"],))
            db_conn.commit()
        _share_forget("addr")
        _share_forget("status")

SELFTESTS.append(_share_selftest)



# ---------- Feature: reports ----------
# 1. Weekly report: a PNG chart plus a Persian caption, sent to the alert chat every Monday
#    00:00 UTC (from tg_daily) and on demand from the web panel and the bot. The image is drawn
#    with the standard library only: a small RGB canvas, a built-in 5x9 bitmap font and a
#    zlib/struct PNG writer. It holds Latin text only (Persian needs a shaping engine); the
#    caption carries the full names.
# 2. status.json next to app.py, rewritten atomically after every probe round, for the Hashem
#    panel's dashboard. Its schema is documented above status_payload().
import calendar, datetime, math, struct, tempfile, zlib

SENTINEL_VERSION = "1.4.0"
DEF_SETTINGS.update({"weekly_report": "1"})  # send the weekly chart on Mondays 00:00 UTC
SETTING_RULES["weekly_report"] = lambda v: "1" if str(v).strip().lower() in ("1", "true", "on", "yes") else "0"

# ASCII 32..126, 9 rows per glyph (7 above the baseline, 2 for descenders), 5 pixels per row,
# one base32 character per row (leftmost pixel = 16). Readable source: tests/reports/gen_font.py.
RP_FONT = ("AAAAAAAAAEEEEEAEAAKKAAAAAAAKK7K7KKAAEPUOF6EAAZZCEITTAAMSUIVSNAAEEAAAAAAACEIIIECAAIECCCEIAAAEVOVEAAA"
           "AEE7EEAAAAAAAAGGCEAAAOAAAAAAAAAAMMAAABCEIQAAAORTVZROAAEMEEEEOAAORBCEI7AA7CECBROAACGKS7CCAA7Q6BBROAA"
           "GIQ6RROAA7BCEIIIAAORRORROAAORRPBCMAAAMMAMMAAAAMMAMMEIACEIQIECAAAA7A7AAAAIECBCEIAAORBCEAEAAORBNVVOAA"
           "ORR7RRRAA6RR6RR6AAORQQQROAA6RRRRR6AA7QQ6QQ7AA7QQ6QQQAAORQXRRPAARRR7RRRAAOEEEEEOAAHCCCCSMAARSUYUSRAA"
           "QQQQQQ7AAR3VVRRRAARRZVTRRAAORRRRROAA6RR6QQQAAORRRVSNAA6RR6USRAAPQQOBB6AA7EEEEEEAARRRRRROAARRRRRKEAA"
           "RRRVVVKAARRKEKRRAARRKEEEEAA7BCEIQ7AAOIIIIIOAAAQIECBAAAOCCCCCOAAEKRAAAAAAAAAAAAA7AIEAAAAAAAAAOBPRPAA"
           "QQWZRR6AAAAOQQROAABBNTRRPAAAAOR7QOAAGJI4IIIAAAAPRRRPBOQQWZRRRAAEAMEEEOAACAGCCCCSMQQSUYUSAAMEEEEEOAA"
           "AA2VVVVAAAAWZRRRAAAAORRROAAAA6RRR6QQAAPRRRPBBAAWZQQQAAAAOQOB6AAII4IIJGAAAARRRTNAAAARRRKEAAAARRVVKAA"
           "AARKEKRAAAARRRRPBOAA7CEI7AACEEIEECAAEEEEEEEAAIEECEEIAAAAIVCAAAA")
_RP_B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
RP_C = {"bg": (255, 255, 255), "tx": (15, 23, 42), "mu": (100, 116, 139), "ln": (226, 232, 240),
        "track": (237, 241, 245), "tile": (245, 247, 250), "ok": (22, 163, 74), "wr": (217, 119, 6),
        "er": (220, 38, 38), "ac": (2, 132, 199)}
RP_MAX_BARS = 25        # more configs than this are listed in the caption only
RP_RETRY = 600          # seconds between tries when the Monday report could not be delivered


class _Canvas:
    """An RGB image you can draw rectangles, bitmap text and antialiased lines on, saved as PNG."""
    def __init__(self, w, h, bg):
        self.w, self.h = w, h
        self.px = bytearray(bytes(bg) * (w * h))

    def rect(self, x0, y0, x1, y1, c):
        x0, y0, x1, y1 = max(0, int(x0)), max(0, int(y0)), min(self.w, int(x1)), min(self.h, int(y1))
        if x0 >= x1:
            return
        row = bytes(c) * (x1 - x0)
        for y in range(y0, y1):
            i = (y * self.w + x0) * 3
            self.px[i:i + len(row)] = row

    def blend(self, x, y, c, a):
        if a <= 0 or not (0 <= x < self.w and 0 <= y < self.h):
            return
        i = (y * self.w + x) * 3
        a = min(1.0, a)
        for k in range(3):
            self.px[i + k] = int(self.px[i + k] + (c[k] - self.px[i + k]) * a + 0.5)

    def _cover(self, x0, y0, x1, y1, dist, c):
        """Antialiased fill of the pixels in a box by their distance outside a shape (<= 0 inside)."""
        for y in range(max(0, int(y0)), min(self.h, int(math.ceil(y1)))):
            for x in range(max(0, int(x0)), min(self.w, int(math.ceil(x1)))):
                self.blend(x, y, c, 0.5 - dist(x + 0.5, y + 0.5))

    def rrect(self, x0, y0, x1, y1, r, c):
        """A rectangle with round ends; r is capped at half the height or width."""
        r = min(r, (x1 - x0) / 2.0, (y1 - y0) / 2.0)
        if r < 1:
            return self.rect(x0, y0, x1, y1, c)
        ri = int(math.ceil(r))
        self.rect(x0 + ri, y0, x1 - ri, y1, c)
        self.rect(x0, y0 + ri, x0 + ri, y1 - ri, c)
        self.rect(x1 - ri, y0 + ri, x1, y1 - ri, c)
        for cx, cy, bx, by in ((x0 + r, y0 + r, x0, y0), (x1 - r, y0 + r, x1 - ri, y0),
                               (x0 + r, y1 - r, x0, y1 - ri), (x1 - r, y1 - r, x1 - ri, y1 - ri)):
            self._cover(bx, by, bx + ri, by + ri, lambda x, y, cx=cx, cy=cy: math.hypot(x - cx, y - cy) - r, c)

    def dot(self, cx, cy, r, c):
        self._cover(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, lambda x, y: math.hypot(x - cx, y - cy) - r, c)

    def polyline(self, pts, c, width):
        cov, r = {}, width / 2.0
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            dx, dy = bx - ax, by - ay
            l2 = dx * dx + dy * dy or 1e-9
            for y in range(int(min(ay, by) - r - 1), int(max(ay, by) + r + 2)):
                for x in range(int(min(ax, bx) - r - 1), int(max(ax, bx) + r + 2)):
                    px, py = x + 0.5, y + 0.5
                    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / l2))
                    a = r + 0.5 - math.hypot(px - ax - t * dx, py - ay - t * dy)
                    if a > 0:
                        cov[(x, y)] = max(cov.get((x, y), 0), a)
        for (x, y), a in cov.items():
            self.blend(x, y, c, a)

    @staticmethod
    def text_w(t, sc):
        return max(0, len(t) * 6 * sc - sc)

    def text(self, x, y, t, c, sc=2, bold=False):
        """Draws t with its capitals' top at y; returns the x after it."""
        for ch in t:
            o = ord(ch) - 32
            if not 0 <= o < 95:
                o = 31  # "?"
            for r, k in enumerate(RP_FONT[o * 9:o * 9 + 9]):
                bits, col = _RP_B32.index(k), 0
                while col < 5:
                    if bits & (16 >> col):
                        end = col
                        while end < 5 and bits & (16 >> end):
                            end += 1
                        self.rect(x + col * sc, y + r * sc, x + end * sc + (1 if bold else 0), y + (r + 1) * sc, c)
                        col = end
                    else:
                        col += 1
            x += 6 * sc
        return x

    def png(self):
        w3 = self.w * 3
        raw = b"".join(b"\x00" + bytes(self.px[y * w3:(y + 1) * w3]) for y in range(self.h))
        chunk = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 2, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def report_label(name, cc, n):
    """The Latin part of a config name for the image (flags and emoji dropped), else its country code, else Config n."""
    t = re.sub(r"\s+", " ", re.sub(r"[^\x20-\x7e]+", " ", name or "")).strip(" -_|.,:;")
    if re.search(r"[A-Za-z0-9]", t):
        return t if len(t) <= 20 else t[:18].rstrip() + ".."
    cc = (cc or flag_to_cc(name or "") or "").upper()
    return cc if re.fullmatch(r"[A-Z]{2}", cc) and cc != "XX" else f"Config {n}"


def report_week(now=None):
    y, w, _ = datetime.date(*time.gmtime(now if now is not None else time.time())[:3]).isocalendar()
    return f"{y:04d}-W{w:02d}"


def _rp_pct(u):
    return "100%" if u >= 100 else f"{math.floor(u * 10) / 10:.1f}%"


def _rp_health(u):
    return "ok" if u >= 99 else "wr" if u >= 95 else "er"


def report_data(now=None):
    """The numbers behind the weekly report: the 7 days before `now` and, for the latency trend, the 7 before that."""
    now = int(now if now is not None else time.time())
    start, prev = now - 7 * 86400, now - 14 * 86400
    with lock:
        rows = [dict(r) for r in db_conn.execute("""
            SELECT c.id, c.name, c.country_code AS cc, COUNT(*) AS n, SUM(ch.ok) AS up,
                   AVG(CASE WHEN ch.ok=1 THEN ch.latency_ms END) AS lat
            FROM checks ch JOIN configs c ON c.id = ch.config_id
            WHERE ch.checked_at >= ? AND ch.checked_at < ?
            GROUP BY c.id ORDER BY c.created_at, c.id""", (start, now))]
        lat_sql = "SELECT AVG(latency_ms) FROM checks WHERE ok=1 AND latency_ms IS NOT NULL AND checked_at >= ? AND checked_at < ?"
        lat_now = db_conn.execute(lat_sql, (start, now)).fetchone()[0]
        lat_prev = db_conn.execute(lat_sql, (prev, start)).fetchone()[0]
        incs = [dict(r) for r in db_conn.execute("""
            SELECT i.started_at, i.resolved_at, c.name FROM incidents i JOIN configs c ON c.id = i.config_id
            WHERE i.started_at < ? AND (i.resolved_at IS NULL OR i.resolved_at >= ?)""", (now, start))]
    cfgs = [{"name": r["name"], "label": report_label(r["name"], r["cc"], i + 1), "checks": r["n"],
             "uptime": 100.0 * (r["up"] or 0) / r["n"], "lat": round(r["lat"]) if r["lat"] is not None else None}
            for i, r in enumerate(rows)]
    cfgs.sort(key=lambda c: (c["uptime"], -(c["lat"] or 0)))  # worst first
    per_day = [0] * 7
    for i in incs:
        if i["started_at"] >= start:
            per_day[min(6, (i["started_at"] - start) // 86400)] += 1
    longest = max(incs, key=lambda i: (i["resolved_at"] or now) - i["started_at"]) if incs else None
    n_all = sum(c["checks"] for c in cfgs)
    return {
        "start": start, "end": now, "configs": cfgs, "incidents": sum(per_day), "per_day": per_day,
        "days": [time.strftime("%a", time.gmtime(start + k * 86400)) for k in range(7)],
        "longest": {"name": longest["name"], "secs": (longest["resolved_at"] or now) - longest["started_at"],
                    "ongoing": longest["resolved_at"] is None} if longest else None,
        "uptime": sum(c["uptime"] * c["checks"] for c in cfgs) / n_all if n_all else None,
        "lat": round(lat_now) if lat_now is not None else None,
        "lat_prev": round(lat_prev) if lat_prev is not None else None,
        "best": max(cfgs, key=lambda c: (c["uptime"], -(c["lat"] or 0))) if cfgs else None,
        "worst": cfgs[0] if cfgs else None,
    }


def _rp_trend(d):
    """(+7, "7% slower") style change of the average latency against the previous week, or None."""
    if d["lat"] is None or not d["lat_prev"]:
        return None
    return round((d["lat"] - d["lat_prev"]) * 100.0 / d["lat_prev"])


def report_caption(d):
    """(summary, per-config list) in Persian HTML. Telegram allows 1024 characters in a photo caption."""
    day = lambda t: time.strftime("%Y-%m-%d", time.gmtime(t))
    head = f"📊 <b>گزارش هفتگی Sentinel</b>\n🗓 {day(d['start'])} تا {day(d['end'] - 1)} (UTC)\n\n"
    if not d["configs"]:
        return head + "در ۷ روز گذشته هیچ تستی ثبت نشده، پس نموداری برای فرستادن نیست.", ""
    lines = [f"📈 میانگین آپتایم: <b>{_rp_pct(d['uptime'])}</b>", f"🚨 قطعی‌ها: <b>{d['incidents']}</b>"]
    if d["longest"]:
        lg = d["longest"]
        lines.append(f"⏱ طولانی‌ترین قطعی: <b>{format_dur(lg['secs'])}</b> — {H(lg['name'])}" + (" (هنوز ادامه دارد)" if lg["ongoing"] else ""))
    b, w = d["best"], d["worst"]
    lines.append(f"🏆 بهترین: <b>{H(b['name'])}</b> ({_rp_pct(b['uptime'])})")
    if len(d["configs"]) > 1:
        lines.append(f"⚠️ بدترین: <b>{H(w['name'])}</b> ({_rp_pct(w['uptime'])})")
    if d["lat"] is not None:
        tr = _rp_trend(d)
        if d["lat_prev"] is None:
            note = "هفته قبل داده‌ای نبود"
        elif tr is None or abs(tr) < 1:
            note = f"هفته قبل {d['lat_prev']}ms، بدون تغییر"
        else:
            note = f"هفته قبل {d['lat_prev']}ms، {abs(tr)}% {'کندتر' if tr > 0 else 'سریع‌تر'}"
        lines.append(f"⚡ میانگین پینگ: <b>{d['lat']}ms</b> ({note})")
    icon = {"ok": "🟢", "wr": "🟠", "er": "🔴"}
    rows = [f"{icon[_rp_health(c['uptime'])]} {_rp_pct(c['uptime'])} — {H(c['name'])}" for c in d["configs"]]
    return head + "\n".join(lines), "<b>آپتایم ۷ روزه هر کانفیگ</b>\n" + "\n".join(rows)


def report_png(d):
    """The weekly chart as PNG bytes: a bar per config (7-day uptime, colored by health) and incidents per day."""
    C, W, M, ROW = RP_C, 1080, 48, 50
    cfgs = d["configs"][:RP_MAX_BARS]
    more = len(d["configs"]) - len(cfgs)
    name_w = min(_Canvas.text_w("x" * 20, 3), max([_Canvas.text_w(c["label"], 3) for c in cfgs] + [120]))
    y_rows = 352
    y_inc = y_rows + len(cfgs) * ROW + (44 if more else 8) + 28
    H_ = y_inc + 356
    im = _Canvas(W, H_, C["bg"])
    day = lambda t: time.strftime("%d %b %Y", time.gmtime(t))

    im.text(M, 44, "Sentinel weekly report", C["tx"], 5, bold=True)
    im.text(M, 98, f"{day(d['start'])} - {day(d['end'] - 1)}, UTC", C["mu"], 3)

    # Three summary tiles
    tr = _rp_trend(d)
    lg = d["longest"]
    tiles = [("UPTIME", _rp_pct(d["uptime"] or 0), C[_rp_health(d["uptime"] or 0)], f"{len(d['configs'])} configs"),
             ("INCIDENTS", str(d["incidents"]), C["er"] if d["incidents"] else C["tx"],
              f"longest {format_dur(lg['secs'])}" if lg else "no outages"),
             ("AVG PING", f"{d['lat']} ms" if d["lat"] is not None else "-", C["tx"],
              "no data last week" if d["lat_prev"] is None or d["lat"] is None else
              "same as last week" if not tr else f"{abs(tr)}% {'slower' if tr > 0 else 'faster'} than last week")]
    gap = 20
    tw = (W - 2 * M - 2 * gap) // 3
    for i, (lbl, val, col, note) in enumerate(tiles):
        x = M + i * (tw + gap)
        im.rrect(x, 150, x + tw, 272, 14, C["tile"])
        im.text(x + 22, 170, lbl, C["mu"], 2, bold=True)
        im.text(x + 22, 198, val, col, 5, bold=True)
        im.text(x + 22, 246, note[:24], C["mu"], 2)

    # Uptime bars, worst first
    im.text(M, 304, "Uptime by config", C["tx"], 3, bold=True)
    lx = W - M
    for key, lbl in (("er", "under 95%"), ("wr", "95-99%"), ("ok", "99%+")):
        lx -= _Canvas.text_w(lbl, 2)
        im.text(lx, 309, lbl, C["mu"], 2)
        lx -= 22
        im.rrect(lx, 309, lx + 14, 323, 3, C[key])
        lx -= 22
    im.rect(M, 338, W - M, 340, C["ln"])
    val_w = _Canvas.text_w("100.0%", 3)
    bx0, bx1 = M + name_w + 24, W - M - val_w - 20
    for i, c in enumerate(cfgs):
        y = y_rows + i * ROW
        im.text(M, y + 14, c["label"], C["tx"], 3)
        im.rrect(bx0, y + 15, bx1, y + 36, 10, C["track"])
        fill = int(round((bx1 - bx0) * c["uptime"] / 100.0))
        if fill >= 2:
            im.rrect(bx0, y + 15, bx0 + fill, y + 36, 10, C[_rp_health(c["uptime"])])
        v = _rp_pct(c["uptime"])
        im.text(W - M - _Canvas.text_w(v, 3), y + 14, v, C["tx"], 3, bold=True)
    if more:
        im.text(M, y_rows + len(cfgs) * ROW + 12, f"+{more} more configs, listed in the message", C["mu"], 2)

    # Incidents per day
    im.text(M, y_inc, "Incidents per day", C["tx"], 3, bold=True)
    im.rect(M, y_inc + 34, W - M, y_inc + 36, C["ln"])
    vals = d["per_day"]
    top = max(vals) or 1
    ax0, ax1, ay0, ay1 = M + 56, W - M - 8, y_inc + 84, y_inc + 244
    for g in sorted({0, top} | ({(top + 1) // 2} if top > 1 else set())):
        gy = int(ay1 - g * (ay1 - ay0) / top)
        im.rect(ax0, gy, ax1, gy + 1, C["ln"])
        im.text(ax0 - 16 - _Canvas.text_w(str(g), 2), gy - 7, str(g), C["mu"], 2)
    step = (ax1 - ax0) / 7.0
    pts = [(ax0 + (k + 0.5) * step, ay1 - v * (ay1 - ay0) / top) for k, v in enumerate(vals)]
    im.polyline(pts, C["ac"], 4)
    for (px, py), v, dn in zip(pts, vals, d["days"]):
        im.dot(px, py, 7, C["ac"])
        im.dot(px, py, 3.5, C["bg"])
        im.text(int(px - _Canvas.text_w(str(v), 2) / 2), int(py) - 30, str(v), C["tx"], 2, bold=True)
        im.text(int(px - _Canvas.text_w(dn, 2) / 2), ay1 + 18, dn, C["mu"], 2)
    im.text(M, H_ - 42, f"Sentinel {SENTINEL_VERSION} - made {time.strftime('%Y-%m-%d %H:%M', time.gmtime(d['end']))} UTC", C["mu"], 2)
    return im.png()


def _tg_len(html_text):
    """Length as Telegram counts it: UTF-16 units of the text once the HTML is parsed."""
    return len(_html.unescape(re.sub(r"<[^>]+>", "", html_text)).encode("utf-16-le")) // 2


def report_send(chat_id, now=None):
    """Send the weekly report to a chat: the chart with its caption, or a short text when there is no data.
    Returns (ok, reason)."""
    d = report_data(now)
    summary, listing = report_caption(d)
    tg_ok = lambda r: (True, "") if r and r.get("ok") else (False, str((r or {}).get("description") or "Telegram could not be reached"))
    if not d["configs"]:
        ok = tg_ok(tg_api("sendMessage", {"chat_id": chat_id, "text": summary, "parse_mode": "HTML"}))
    else:
        full = summary + "\n\n" + listing
        fd, tmp = tempfile.mkstemp(prefix=".report-", suffix=".png", dir=D)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(report_png(d))
            fits = _tg_len(full) <= 1000  # Telegram allows 1024 in a photo caption
            photo = lambda cap: tg_api("sendPhoto", {"chat_id": chat_id, "caption": cap, "parse_mode": "HTML"},
                                       doc=(tmp, "weekly-report.png", "photo"), timeout=60)
            res = photo(full if fits else summary)
            if fits and res and not res.get("ok") and "caption" in str(res.get("description", "")).lower():
                fits, res = False, photo(summary)
            ok = tg_ok(res)
        finally:
            try:
                os.unlink(tmp)
            except OSError:
                pass
        if ok[0] and not fits:
            if len(listing) > 4000:
                listing = listing[:listing.rfind("\n", 0, 3950)] + "\n…"
            tg_api("sendMessage", {"chat_id": chat_id, "text": listing, "parse_mode": "HTML"})
    if ok[0]:
        with lock:
            db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('weekly_report_sent_at', ?)", (str(int(time.time())),))
            db_conn.commit()
    return ok


_rp_lock = threading.Lock()
rp_state = {"running": False, "next_try": 0, "last": None}  # last: {"ok", "error", "at"} of the latest send


def report_send_bg(chat_id, week=None, at=None):
    """Send in a thread; with `week`, store it in meta once Telegram accepted the report. `at` ends the 7 days
    reported (default: now). False if one is running."""
    with _rp_lock:
        if rp_state["running"]:
            return False
        rp_state["running"] = True

    def run():
        try:
            ok, err = report_send(chat_id, at)
        except Exception as e:
            ok, err = False, str(e)[:200]
            print("weekly report failed:", err, flush=True)
        if ok and week:
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('weekly_report_week', ?)", (week,))
                db_conn.commit()
        rp_state.update(running=False, last={"ok": ok, "error": err, "at": int(time.time())})
    threading.Thread(target=run, daemon=True).start()
    return True


def report_weekly_due(s, now=None):
    """Called from tg_daily (every ~20 s). Sends the report once per ISO week, the first time it runs on or after
    Monday 00:00 UTC. The sent week is kept in meta, so a restart neither repeats nor skips it; a failed send is
    retried every RP_RETRY seconds. Returns True when a send was started."""
    now = now if now is not None else time.time()
    wk, last = report_week(now), get_meta("weekly_report_week")
    if last == wk:
        return False
    if last is None or s.get("weekly_report", "1") != "1" or not (s.get("token") and s.get("chat")):
        # First run (a fresh install or the upgrade that adds this), or switched off: start from next Monday.
        with lock:
            db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('weekly_report_week', ?)", (wk,))
            db_conn.commit()
        return False
    if now < rp_state["next_try"]:
        return False
    g = time.gmtime(now)
    monday = calendar.timegm((g.tm_year, g.tm_mon, g.tm_mday, 0, 0, 0)) - g.tm_wday * 86400
    started = report_send_bg(s["chat"], wk, at=monday)  # the Mon-Sun week that just ended, even when sent late
    if started:
        rp_state["next_try"] = now + RP_RETRY  # only matters if this send fails
    return started


def _rp_png_route(h, method, path, qs):
    """GET <panel>/api/report.png for the Preview button. It opens in a new tab, which cannot send the X-R header
    the API routes need, so it is answered here, signed-in only. It only reads, and the cookie is SameSite=Strict."""
    if method != "GET" or path != "/" + get_meta("path") + "/api/report.png":
        return False
    if not h.is_authed():
        h.out(401, {"error": "unauthorized"})
        return True
    d = report_data()
    if not d["configs"]:
        h.out(404, "There are no checks in the last 7 days, so there is no chart yet.", "text/plain; charset=utf-8")
        return True
    h.out(200, report_png(d), "image/png")
    return True


def _rp_api_send(h, method, b, qs):
    """POST report-send: send the report to the alert chat now (in a thread). GET: whether it is running, and the last result."""
    if method == "POST":
        s = get_settings()
        if not (s.get("token") and s.get("chat")):
            return h.out(400, {"error": "Set the bot token and chat ID under Telegram bot first"})
        if not report_send_bg(s["chat"]):
            return h.out(409, {"error": "A report is already being sent"})
        return h.out(200, {"ok": True, "started": True})
    return h.out(200, {"running": rp_state["running"], "last": rp_state["last"]})


def scr_report():
    s = get_settings()
    on = s.get("weekly_report", "1") == "1"
    sent = get_meta("weekly_report_sent_at")
    text = ("📊 <b>گزارش هفتگی</b>\n\n"
            "هر دوشنبه ساعت 00:00 UTC یک نمودار از آپتایم ۷ روز گذشته هر کانفیگ، با تعداد قطعی‌ها، طولانی‌ترین قطعی "
            "و روند پینگ به چت هشدار فرستاده می‌شود.\n\n"
            f"ارسال خودکار: <b>{'روشن' if on else 'خاموش'}</b>"
            + (f"\nآخرین ارسال: <code>{time.strftime('%Y-%m-%d %H:%M', time.gmtime(int(sent)))} UTC</code>" if sent else ""))
    return text, kb(
        [(f"{'✅' if on else '⬜'} ارسال خودکار هر دوشنبه", "rp:t")],
        [("🖼 پیش‌نمایش همین‌جا", "rp:p"), ("📤 ارسال به چت هشدار", "rp:s")],
        [("🔔 اعلان‌ها", "nt"), BACK])


def _rp_tg(args, uid, chat_id, msg_id, cb_id, show):
    act = args[0] if args else ""
    if act == "t":
        on = get_settings().get("weekly_report", "1") == "1"
        svc_apply_settings({"weekly_report": "0" if on else "1"})
        tg_toast(cb_id, "ارسال خودکار خاموش شد" if on else "ارسال خودکار روشن شد")
        return show(scr_report())
    if act in ("p", "s"):
        dest = chat_id if act == "p" else get_settings().get("chat", "")
        if not dest:
            return tg_toast(cb_id, "اول Chat ID را در تنظیمات تلگرام وارد کنید.", alert=True)
        tg_toast(cb_id, "در حال ساخت گزارش…")
        ok, err = report_send(dest)
        if not ok:
            tg_api("sendMessage", {"chat_id": chat_id, "text": f"❌ گزارش فرستاده نشد: {H(err)}", "parse_mode": "HTML"})
        elif str(dest) != str(chat_id):
            tg_api("sendMessage", {"chat_id": chat_id, "text": "✅ گزارش هفتگی به چت هشدار فرستاده شد."})
        return None
    return show(scr_report())


PUBLIC_ROUTES.append(_rp_png_route)
API_ROUTES["report-send"] = _rp_api_send
TG_ROUTES["rp"] = _rp_tg
TG_MAIN_ROWS.append([("📊 گزارش هفتگی", "rp")])

# ----- status.json for the Hashem panel -----
# Rewritten after every probe round (TICK_HOOKS): written to a temp file in the same folder, then
# os.replace()d over status.json, mode 0640, so a reader never sees half a file. Schema 1; times are
# unix seconds (UTC); new keys may be added without changing "schema":
#   schema              1
#   generated_at        when the file was written (treat as stale if much older than `interval`)
#   sentinel_version    e.g. "1.4.0"
#   interval            seconds between probe rounds
#   counts              {state: number of configs} for every state: up, slow, down, iran_only, fail,
#                       no_engine, new, paused (zeros included)
#   total, enabled      number of configs, and of those not paused
#   worst               up to 5 configs that are down (down, iran_only) or failing (fail), worst first:
#                       [{"name", "state", "down_since" (unix or null), "last_error_plain"}]
#   avg_latency_ms      mean latest latency of the working (up, slow) configs, or null
#   last_check_at       time of the newest check, or null
#   telegram_configured bot token and chat ID are both set
#   pending_alerts      alerts waiting because Telegram could not be reached
# It never holds config links, server addresses, tokens, passwords or the panel path.
STATUS_FILE = D + "/status.json"


def _status_err(c):
    """The last error in plain words, with any link, address or host name taken out."""
    t = human_err(c.get("last_error") or "")
    host = (c.get("addr") or "").rsplit(":", 1)[0].strip("[]")
    if len(host) > 2:
        t = t.replace(host, "<server>")
    t = re.sub(r"[A-Za-z][A-Za-z0-9+.-]*://\S+", "<link>", t)
    t = re.sub(r"\[[0-9A-Fa-f:.]+\]|\b[0-9A-Fa-f]{0,4}(?::[0-9A-Fa-f]{0,4}){3,7}\b", "<ip>", t)
    t = re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "<ip>", t)
    t = re.sub(r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b", "<host>", t)
    return t[:160]


def status_payload(now=None):
    s = get_settings()
    cs = config_states()
    counts = {k: 0 for k in STATE_ICON}
    for c in cs:
        counts[c["state"]] = counts.get(c["state"], 0) + 1
    lats = [c["latency"] for c in cs if c["state"] in ("up", "slow") and c.get("latency")]
    with lock:
        last = db_conn.execute("SELECT MAX(checked_at) FROM checks").fetchone()[0]
        pending = db_conn.execute("SELECT COUNT(*) FROM pending_alerts").fetchone()[0]
    try:
        interval = int(s.get("interval", 30))
    except ValueError:
        interval = 30
    return {
        "schema": 1,
        "generated_at": int(now if now is not None else time.time()),
        "sentinel_version": SENTINEL_VERSION,
        "interval": interval,
        "counts": counts,
        "total": len(cs),
        "enabled": sum(1 for c in cs if c.get("enabled")),
        "worst": [{"name": c["name"], "state": c["state"], "down_since": c.get("down_since"),
                   "last_error_plain": _status_err(c)} for c in cs if c["state"] in ("down", "iran_only", "fail")][:5],
        "avg_latency_ms": round(sum(lats) / len(lats)) if lats else None,
        "last_check_at": last,
        "telegram_configured": bool(s.get("token") and s.get("chat")),
        "pending_alerts": pending,
    }


def write_status(s=None):
    """TICK_HOOK: write status.json atomically. Never raises, so it cannot stop the probe loop."""
    tmp = None
    try:
        data = json.dumps(status_payload(), ensure_ascii=False, indent=1).encode("utf-8")
        fd, tmp = tempfile.mkstemp(prefix=".status-", suffix=".tmp", dir=os.path.dirname(STATUS_FILE))
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o640)
        os.replace(tmp, STATUS_FILE)
        tmp = None
    except Exception as e:
        print("status.json not written:", e, flush=True)
    finally:
        if tmp:
            try:
                os.unlink(tmp)
            except OSError:
                pass


TICK_HOOKS.append(write_status)


def _rp_selftest():
    def check_png(b):
        assert b[:8] == b"\x89PNG\r\n\x1a\n"
        i, chunks = 8, []
        while i < len(b):
            n, = struct.unpack(">I", b[i:i + 4])
            t, body = b[i + 4:i + 8], b[i + 8:i + 8 + n]
            assert struct.unpack(">I", b[i + 8 + n:i + 12 + n])[0] == zlib.crc32(t + body) & 0xFFFFFFFF
            chunks.append((t, body))
            i += 12 + n
        assert chunks[0][0] == b"IHDR" and chunks[-1] == (b"IEND", b"")
        w, h, depth, ctype = struct.unpack(">IIBB", chunks[0][1][:10])
        raw = zlib.decompress(b"".join(body for t, body in chunks if t == b"IDAT"))
        assert depth == 8 and ctype == 2 and len(raw) == h * (1 + 3 * w)
        return w, h
    now = 1763337600  # Monday 2025-11-17 00:00 UTC
    assert report_week(now) == "2025-W47" and report_week(now - 1) == "2025-W46"
    assert report_label("🇩🇪 Frankfurt Reality", "DE", 1) == "Frankfurt Reality"
    assert report_label("🇩🇪🔥", "", 2) == "DE" and report_label("🔥 ⚡", "", 3) == "Config 3"
    cf = [{"name": f"<b>N{i}</b> 🇩🇪", "label": f"N{i}", "checks": 10, "uptime": u, "lat": 100 + i}
          for i, u in enumerate((80.0, 97.5, 100.0))]
    d = {"start": now - 7 * 86400, "end": now, "configs": cf, "incidents": 3, "per_day": [0, 1, 0, 2, 0, 0, 0],
         "days": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], "longest": {"name": "N0", "secs": 7200, "ongoing": False},
         "uptime": 92.5, "lat": 110, "lat_prev": 100, "best": cf[2], "worst": cf[0]}
    assert check_png(report_png(d))[0] == 1080
    summary, listing = report_caption(d)
    assert "&lt;b&gt;N0" in listing and "<b>N" not in listing.replace("<b>آپتایم", "") and "10% کندتر" in summary
    empty = report_data(now)
    if not empty["configs"]:
        assert report_caption(empty)[1] == "" and "هیچ تستی" in report_caption(empty)[0]
    c = {"addr": "de1.example.net:443", "last_error": "Xray rejected: dial de1.example.net:443 via 10.1.2.3 vless://x@y"}
    e = _status_err(c)
    assert "example" not in e and "10.1.2.3" not in e and "vless" not in e
    p = status_payload()
    assert p["schema"] == 1 and set(p["counts"]) >= set(STATE_ICON) and "uri" not in json.dumps(p)


SELFTESTS.append(_rp_selftest)



# ---------- dashboard: the chart in buckets, outages on the chart, 30-day uptime ----------
HIST_SPANS = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}

def history_buckets(range_key, cfg_id=None, nb=60, now=None):
    """The dashboard chart, bucketed here so the page never loads every check. Per bucket: the average,
    lowest and 95th-percentile latency of the probes that worked, and how many failed. Also every outage
    that overlaps the range, so one config going down shows even when the others are fine."""
    span = HIST_SPANS.get(range_key, 86400)
    nb = max(10, min(int(nb or 60), 240))
    now = int(now or time.time())
    since, bw = now - span, span / nb
    where, args = "checked_at >= ? AND checked_at <= ?", [since, now]
    iq = ("SELECT i.config_id, i.started_at, i.resolved_at, i.last_error, i.diag_verdict, c.name FROM incidents i "
          "JOIN configs c ON c.id = i.config_id WHERE (i.resolved_at IS NULL OR i.resolved_at >= ?) AND i.started_at <= ?")
    ia = [since, now]
    if cfg_id:
        where += " AND config_id = ?"; args.append(cfg_id)
        iq += " AND i.config_id = ?"; ia.append(cfg_id)
    bk = [([], [0, 0]) for _ in range(nb)]
    with lock:
        for t, ok, ms in db_conn.execute(f"SELECT checked_at, ok, latency_ms FROM checks WHERE {where}", args):
            lats, nf = bk[min(nb - 1, max(0, int((t - since) // bw)))]
            nf[0] += 1
            if ok and ms:
                lats.append(ms)
            elif not ok:
                nf[1] += 1
        incs = [dict(r) for r in db_conn.execute(iq + " ORDER BY i.started_at", ia)]
    out = []
    for i, (lats, (n, f)) in enumerate(bk):
        lats.sort()
        out.append({"t": round(since + (i + .5) * bw), "n": n, "fail": f,
                    "avg": round(sum(lats) / len(lats)) if lats else None,
                    "min": lats[0] if lats else None,
                    "p95": lats[min(len(lats) - 1, int(.95 * len(lats)))] if lats else None})
    for x in incs:
        x["open"] = x["resolved_at"] is None
        x["start"], x["end"] = max(x.pop("started_at"), since), min(x.pop("resolved_at") or now, now)
        x["why"] = x.pop("diag_verdict") or human_err(x.pop("last_error"))
        x.pop("last_error", None)
    return {"span": span, "since": since, "now": now, "buckets": out, "incidents": incs}

_UPTIME_CACHE = {}
def uptime_window(days=30, now=None):
    """Share of probes that worked over the last <days> days, enabled configs only. Cached a minute:
    the dashboard asks every few seconds."""
    now = int(now or time.time())
    hit = _UPTIME_CACHE.get(days)
    if hit and now - hit[0] < 60:
        return hit[1]
    with lock:
        r = db_conn.execute("SELECT COUNT(*) AS n, SUM(k.ok) AS up FROM checks k JOIN configs c ON c.id = k.config_id "
                            "WHERE c.enabled = 1 AND k.checked_at >= ?", (now - days * 86400,)).fetchone()
    val = round(100.0 * r["up"] / r["n"], 2) if r["n"] else None
    _UPTIME_CACHE[days] = (now, val)
    return val

def _dash_extras(reply):
    """30-day uptime for the top cards, and why each open outage happened for the attention strip."""
    reply["uptime_30d"] = uptime_window(30)
    with lock:
        why = {r["config_id"]: r["diag_verdict"] for r in db_conn.execute(
            "SELECT config_id, diag_verdict FROM incidents WHERE resolved_at IS NULL AND diag_verdict IS NOT NULL")}
    for c in reply.get("configs", []):
        c["down_why"] = why.get(c["id"]) or (human_err(c.get("last_error")) if c.get("is_down") else None)

STATE_EXTRAS.append(_dash_extras)

def _dash_selftest():
    h = history_buckets("24h", nb=24)
    assert len(h["buckets"]) == 24 and h["span"] == 86400 and all(set(b) >= {"t", "avg", "min", "p95", "n", "fail"} for b in h["buckets"])
    assert all(x["start"] <= x["end"] for x in h["incidents"])
    assert history_buckets("30d", nb=99999)["buckets"].__len__() == 240

SELFTESTS.append(_dash_selftest)


# ---------- HTTP Handler ----------
def sign_sid(exp):
    secret = get_meta("secret")
    return hmac.new(bytes.fromhex(secret), str(exp).encode(), hashlib.sha256).hexdigest()

class SentinelHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def out(self, code=200, body=b"", ct="application/json", cookie=None):
        if not isinstance(body, (bytes, str)):
            body = json.dumps(body)
        if isinstance(body, str):
            body = body.encode()
        gz = len(body) > 512 and "gzip" in self.headers.get("Accept-Encoding", "") and not ct.startswith(("image/", "font/"))
        if gz:
            body = gzip.compress(body, 6)
        self.send_response(code)
        if gz:
            self.send_header("Content-Encoding", "gzip")
        for k, v in [
            ("Content-Type", ct),
            ("Content-Length", len(body)),
            ("Cache-Control", "no-store"),
            ("X-Frame-Options", "DENY"),
            ("X-Content-Type-Options", "nosniff"),
            ("Referrer-Policy", "no-referrer")
        ]:
            self.send_header(k, v)
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def is_authed(self):
        try:
            cookie_hdr = self.headers.get("Cookie", "")
            exp_str, sig = SimpleCookie(cookie_hdr)["sid"].value.split(".")
            exp = int(exp_str)
            return exp > time.time() and hmac.compare_digest(sig, sign_sid(exp))
        except Exception:
            return False

    def do_GET(self): self.dispatch("GET")
    def do_POST(self): self.dispatch("POST")

    def dispatch(self, method):
        P = "/" + get_meta("path")
        path = self.path.split("?")[0]
        qs = up.parse_qs(up.urlparse(self.path).query)

        # Clean subscription feed (public with token)
        sub_tok = None
        if method == "GET":
            if path.startswith("/sub/"):
                sub_tok = path[5:].strip("/")
            elif path.startswith(P + "/sub/"):
                sub_tok = path[len(P) + 5:].strip("/")
        if sub_tok:
            qs = share_feed_query(self, sub_tok, qs)  # main token, or a named feed with its saved filters
            if qs is None:
                return self.out(404, "Invalid subscription token", "text/plain")

            sort_by = qs.get("sort", ["recent"])[0].lower()
            proto_filter = [p.strip().lower() for p in qs.get("proto", [""])[0].split(",") if p.strip()]
            country_filter = [c.strip().upper() for c in qs.get("country", [""])[0].split(",") if c.strip()]
            limit_val = None
            if "limit" in qs:
                try: limit_val = int(qs["limit"][0])
                except ValueError: pass

            where_clauses = [
                "c.enabled = 1",
                "ch.ok = 1",
                "c.id NOT IN (SELECT config_id FROM incidents WHERE resolved_at IS NULL)"
            ]
            params = []

            if proto_filter:
                placeholders = ",".join("?" * len(proto_filter))
                where_clauses.append(f"LOWER(c.protocol) IN ({placeholders})")
                params.extend(proto_filter)

            if country_filter:
                placeholders = ",".join("?" * len(country_filter))
                where_clauses.append(f"UPPER(c.country_code) IN ({placeholders})")
                params.extend(country_filter)

            share_source_filter(qs, where_clauses, params)

            if sort_by == "ping":
                order_clause = "ORDER BY ch.latency_ms ASC, c.created_at DESC"
            elif sort_by == "speed":
                order_clause = "ORDER BY c.last_speed_mbps DESC, c.created_at DESC"
            elif sort_by == "best":
                order_clause = "ORDER BY c.created_at DESC, c.id"   # pf_best re-sorts and applies the limit
            else:
                order_clause = "ORDER BY c.created_at DESC"

            limit_clause = f"LIMIT {int(limit_val)}" if limit_val and limit_val > 0 and sort_by != "best" else ""

            where_str = " AND ".join(where_clauses)
            sql = f"""
                SELECT c.id, c.uri, c.name, c.protocol, c.country_code FROM configs c
                JOIN (SELECT config_id, ok, latency_ms, MAX(checked_at) AS max_t FROM checks GROUP BY config_id) ch ON ch.config_id = c.id
                WHERE {where_str}
                {order_clause}
                {limit_clause}
            """

            with lock:
                rows = db_conn.execute(sql, params).fetchall()
                rows = [r for r in rows if not engine_missing(r)]  # Feature: engines: not checked any more
                if sort_by == "best":
                    rows = pf_best(rows, limit_val)
                uris = [r["uri"] for r in rows]

            raw_text = "\n".join(uris)
            fmt = qs.get("format", ["b64"])[0].lower()
            if fmt == "plain":
                out_body = raw_text.encode("utf-8")
            else:
                b64_feed = base64.b64encode(raw_text.encode("utf-8")).decode("ascii")
                out_body = b64_feed.encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(out_body)))
            self.send_header("Content-Disposition", 'attachment; filename="sentinel.txt"')
            self.send_header("Subscription-Userinfo", f"upload=0; download=0; total={len(uris)*1073741824}; expire=0")
            self.send_header("Profile-Update-Interval", "1")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.end_headers()
            self.wfile.write(out_body)
            return

        for h in PUBLIC_ROUTES:
            if h(self, method, path, qs):
                return

        # Static assets
        if method == "GET" and path.startswith(P + "/static/"):
            rel = path[len(P) + 8:].strip("/")
            # protect directory traversal
            full = os.path.normpath(os.path.join(STATIC_DIR, rel))
            if full.startswith(STATIC_DIR) and os.path.isfile(full):
                ct = "text/plain"
                if full.endswith(".css"): ct = "text/css; charset=utf-8"
                elif full.endswith(".js"): ct = "application/javascript; charset=utf-8"
                elif full.endswith(".woff2"): ct = "font/woff2"
                elif full.endswith(".png"): ct = "image/png"
                elif full.endswith(".svg"): ct = "image/svg+xml"
                return self.out(200, open(full, "rb").read(), ct)
            return self.out(404)

        # Single page app entry
        if method == "GET" and path.rstrip("/") == P:
            return self.out(200, open(INDEX_FILE, "rb").read(), "text/html; charset=utf-8")

        # API routing
        if not path.startswith(P + "/api/"):
            return self.out(404)
        ep = path[len(P) + 5:]

        # CSRF check
        if self.headers.get("X-R") != "1":
            return self.out(403, {"error": "forbidden"})

        # Read JSON body for POST
        b = {}
        if method == "POST":
            clen = int(self.headers.get("Content-Length", 0))
            if clen > 500000:
                return self.out(413, {"error": "payload too large"})
            raw = self.rfile.read(clen) or b"{}"
            try:
                b = json.loads(raw.decode("utf-8"))
            except Exception:
                return self.out(400, {"error": "invalid json"})

        # External Alert from Hashem Panel (Localhost only)
        if ep == "external-alert":
            ip = self.client_address[0]
            if ip not in ("127.0.0.1", "::1", "localhost"):
                return self.out(403, {"error": "Localhost only"})
            txt = str(b.get("text", "")).strip()
            if not txt:
                return self.out(400, {"error": "text required"})
            al_queue(txt, "external"); _al_kick()   # Telegram plus the alert channels
            return self.out(200, {"ok": True, "dispatched": True})

        # Public Login endpoint
        if ep == "login":
            ip = self.client_address[0]
            recent = [t for t in fails_by_ip.get(ip, []) if t > time.time() - 300]
            if len(recent) >= 5:
                return self.out(429, {"error": "too many attempts"})
            pw = str(b.get("password", ""))
            stored_pw = get_meta("pw")
            salt = get_meta("salt")
            if not hmac.compare_digest(hashpw(pw, salt), stored_pw):
                fails_by_ip[ip] = recent + [time.time()]
                time.sleep(1)
                return self.out(401, {"error": "invalid credentials"})

            # Check 2FA TOTP
            totp_on = get_meta("totp_enabled") == "1"
            if totp_on:
                code = str(b.get("totp_code", "")).strip()
                if not code:
                    return self.out(401, {"error": "2fa_required", "need_2fa": True})
                sec = get_meta("totp_secret") or ""
                if not verify_totp(sec, code):
                    time.sleep(1)
                    return self.out(401, {"error": "Invalid 2FA authenticator code", "need_2fa": True})

            exp = int(time.time()) + (86400 * 7)
            sig = sign_sid(exp)
            cookie = f"sid={exp}.{sig}; Path={P}; HttpOnly; SameSite=Strict; Max-Age=604800"
            return self.out(200, {"ok": True}, cookie=cookie)

        # All subsequent endpoints require auth
        if not self.is_authed():
            return self.out(401, {"error": "unauthorized"})

        if ep == "logout":
            cookie = f"sid=0; Path={P}; HttpOnly; Max-Age=0"
            return self.out(200, {"ok": True}, cookie=cookie)

        # Dashboard Summary
        if ep == "dashboard":
            with lock:
                cur = db_conn.execute("""
                    SELECT c.id, c.name, c.uri, c.addr, c.port, c.protocol, c.network, c.security, c.enabled, c.muted, c.created_at, c.sub_id, c.last_speed_mbps, c.last_speed_time, c.country_code, c.country_name, s.name as sub_name, s.url as sub_url
                    FROM configs c
                    LEFT JOIN subscriptions s ON s.id = c.sub_id
                    ORDER BY c.created_at DESC
                """)
                cfgs = [dict(r) for r in cur.fetchall()]
                # latest check per config
                cur = db_conn.execute("""
                    SELECT c1.config_id, c1.ok, c1.latency_ms, c1.error, c1.checked_at, c1.ok_iran
                    FROM checks c1
                    JOIN (SELECT config_id, MAX(id) AS max_id FROM checks GROUP BY config_id) c2
                    ON c1.id = c2.max_id
                """)
                latest = {r["config_id"]: dict(r) for r in cur.fetchall()}
                # open incidents
                cur = db_conn.execute("SELECT config_id, started_at, last_error FROM incidents WHERE resolved_at IS NULL")
                down_cfgs = {r["config_id"]: dict(r) for r in cur.fetchall()}

                cur = db_conn.execute("SELECT config_id, COUNT(*) AS n, SUM(ok) AS up FROM checks WHERE checked_at>=? GROUP BY config_id", (int(time.time()) - 86400,))
                upt = {r["config_id"]: (round(100.0 * r["up"] / r["n"], 1) if r["n"] else None) for r in cur.fetchall()}
                since_24h = int(time.time()) - 24 * 3600
                cur_sla = db_conn.execute(
                    "SELECT config_id, checked_at, ok, latency_ms FROM checks WHERE checked_at >= ? ORDER BY checked_at ASC",
                    (since_24h,)
                )
                checks_by_cfg = {}
                for r_ch in cur_sla.fetchall():
                    checks_by_cfg.setdefault(r_ch["config_id"], []).append(r_ch)

                now_ts = int(time.time())
                start_24h = now_ts - 24 * 3600

                for c in cfgs:
                    c["uptime"] = upt.get(c["id"])
                    c["country_flag"] = country_flag(c.get("country_code"))
                    ch = latest.get(c["id"], {})
                    c["last_ok"] = ch.get("ok")
                    c["latency"] = ch.get("latency_ms")
                    c["ok_iran"] = ch.get("ok_iran", 1)
                    c["last_error"] = ch.get("error", "")
                    c["last_check"] = ch.get("checked_at")
                    c["is_down"] = c["id"] in down_cfgs
                    c["down_since"] = down_cfgs[c["id"]]["started_at"] if c["is_down"] else None

                    # Compute 24 hourly SLA bars
                    c_checks = checks_by_cfg.get(c["id"], [])
                    buckets = [[] for _ in range(24)]
                    for r_c in c_checks:
                        b_idx = int((r_c["checked_at"] - start_24h) // 3600)
                        if 0 <= b_idx < 24:
                            buckets[b_idx].append(r_c)
                    bars = []
                    for b_i in range(24):
                        slot_t = start_24h + b_i * 3600
                        slot_hr = time.strftime("%H:00", time.localtime(slot_t))
                        b_items = buckets[b_i]
                        if not b_items:
                            bars.append({"h": slot_hr, "status": -1, "up_pct": None, "ms": None})
                        else:
                            tot = len(b_items)
                            up_cnt = sum(1 for x in b_items if x["ok"])
                            lats = [x["latency_ms"] for x in b_items if x["ok"] and x["latency_ms"]]
                            avg_ms = round(sum(lats) / len(lats)) if lats else None
                            pct = round(100.0 * up_cnt / tot, 1)
                            st = 1 if up_cnt == tot else (0 if up_cnt == 0 else 2)
                            bars.append({"h": slot_hr, "status": st, "up_pct": pct, "ms": avg_ms})
                    c["sla_bars"] = bars

                # Recent incidents
                cur = db_conn.execute("""
                    SELECT i.id, i.started_at, i.resolved_at, i.last_error, c.name, c.addr
                    FROM incidents i
                    JOIN configs c ON c.id = i.config_id
                    ORDER BY i.started_at DESC LIMIT 10
                """)
                recent_inc = [dict(r) for r in cur.fetchall()]

                # Pending alerts count
                cur = db_conn.execute("SELECT COUNT(*) AS c FROM pending_alerts")
                pending = cur.fetchone()["c"]

                s = get_settings()
                for k in SECRET_SETTINGS:
                    s[k + "_configured"] = bool(s.get(k))
                    s.pop(k, None)

            # The server decides each config's state; the page only shows it.
            states = {c["id"]: c["state"] for c in config_states()}
            for c in cfgs:
                c["state"] = states.get(c["id"])
            reply = {"configs": cfgs, "incidents": recent_inc, "settings": s, "pending_alerts": pending}
            run_hooks(STATE_EXTRAS, reply)
            return self.out(200, reply)

        # Configs CRUD
        if ep == "configs":
            with lock:
                rows = [dict(r) for r in db_conn.execute("""
                    SELECT c.id, c.name, c.uri, c.addr, c.port, c.protocol, c.network, c.security, c.enabled, c.created_at, c.sub_id, s.name as sub_name, s.url as sub_url
                    FROM configs c
                    LEFT JOIN subscriptions s ON s.id = c.sub_id
                    ORDER BY c.created_at DESC
                """).fetchall()]
            return self.out(200, {"configs": rows})

        if ep == "configs/add":
            text = str(b.get("text", "")).strip()
            if not text:
                return self.out(400, {"error": "no URIs provided"})
            added, errs = svc_add_configs(text)
            return self.out(200, {"added": added, "errors": errs})

        if ep == "configs/delete":
            svc_delete_config(str(b.get("id", "")))
            return self.out(200, {"ok": True})

        if ep == "configs/mute":
            v = svc_mute_config(str(b.get("id", "")))
            return self.out(200, {"ok": True, "muted": v}) if v is not None else self.out(404, {"error": "not found"})

        if ep == "configs/toggle":
            v = svc_toggle_config(str(b.get("id", "")))
            return self.out(200, {"ok": True, "enabled": v}) if v is not None else self.out(404, {"error": "not found"})

        # Per-config detail: stats + recent checks
        if ep == "config":
            cid = qs.get("id", [""])[0]
            span = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}.get(qs.get("range", ["24h"])[0], 86400)
            since = int(time.time()) - span
            with lock:
                r = db_conn.execute("SELECT * FROM configs WHERE id=?", (cid,)).fetchone()
                if not r:
                    return self.out(404, {"error": "not found"})
                st = db_conn.execute(
                    "SELECT COUNT(*) AS n, SUM(ok) AS up, AVG(CASE WHEN ok=1 THEN latency_ms END) AS avg, "
                    "MIN(CASE WHEN ok=1 THEN latency_ms END) AS mn, MAX(CASE WHEN ok=1 THEN latency_ms END) AS mx "
                    "FROM checks WHERE config_id=? AND checked_at>=?", (cid, since)).fetchone()
                pts = [dict(x) for x in db_conn.execute(
                    "SELECT checked_at, ok, latency_ms, error FROM checks WHERE config_id=? AND checked_at>=? ORDER BY checked_at ASC",
                    (cid, since)).fetchall()]
                incs = [dict(x) for x in db_conn.execute(
                    "SELECT id, started_at, resolved_at, last_error FROM incidents WHERE config_id=? ORDER BY started_at DESC LIMIT 20",
                    (cid,)).fetchall()]
            n = st["n"] or 0
            return self.out(200, {
                "config": dict(r), "points": pts, "incidents": incs, "span": span,
                "stats": {"checks": n, "uptime": round(100.0 * (st["up"] or 0) / n, 2) if n else None,
                          "avg": round(st["avg"]) if st["avg"] is not None else None, "min": st["mn"], "max": st["mx"]}})

        if ep == "configs/rename":
            if not svc_rename_config(str(b.get("id", "")), b.get("name", "")):
                return self.out(400, {"error": "name required"})
            return self.out(200, {"ok": True})

        if ep == "password":
            old, new = str(b.get("old", "")), str(b.get("new", ""))
            if len(new) < 8:
                return self.out(400, {"error": "New password must be at least 8 characters"})
            if not hmac.compare_digest(hashpw(old, get_meta("salt")), get_meta("pw")):
                return self.out(403, {"error": "Current password is wrong"})
            salt = secrets.token_hex(8)
            with lock:
                for k, v in (("salt", salt), ("pw", hashpw(new, salt))):
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (k, v))
                db_conn.commit()
            try:
                write_credentials(new, get_meta("path"), get_meta("port"))
            except OSError:
                pass
            return self.out(200, {"ok": True})

        if ep == "incidents.csv":
            return self.out(200, svc_incidents_csv(), "text/csv; charset=utf-8")

        # SP-Test Endpoints
        if ep == "speedtest":
            cid = str(b.get("id", "")).strip()
            res = run_speed_test(cid)
            return self.out(200 if res.get("ok") else 400, res)

        if ep == "speedtest/all":
            if not svc_start_speed_all():
                return self.out(409, {"error": "Speed test already in progress"})
            return self.out(200, {"ok": True, "message": "Speed test started across healthy nodes"})

        # Support / Donate Nudge
        if ep == "support":
            act = str(b.get("action", "claim"))
            now = int(time.time())
            with lock:
                snooze_until = int(get_meta("sup_snooze_until") or 0)
                last_shown = int(get_meta("sup_last_shown") or 0)

            if act == "claim":
                # Only show if not snoozed and not shown in last 3 days
                should_show = (now >= snooze_until) and (now - last_shown >= 3 * 86400)
                if should_show:
                    with lock:
                        db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_last_shown', ?)", (str(now),))
                        db_conn.commit()
                return self.out(200, {"show": should_show})

            if act in ("close", "later"):
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            if act == "snooze":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 30 * 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            if act == "donate":
                with lock:
                    db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('sup_snooze_until', ?)", (str(now + 90 * 86400),))
                    db_conn.commit()
                return self.out(200, {"ok": True})

            return self.out(200, {"ok": True})

        # 2FA Management Endpoints
        if ep == "2fa":
            is_on = get_meta("totp_enabled") == "1"
            sec = get_meta("totp_secret") if is_on else generate_totp_secret()
            uri = f"otpauth://totp/Sentinel:admin?secret={sec}&issuer=Sentinel"
            return self.out(200, {"enabled": is_on, "secret": sec, "uri": uri})

        if ep == "2fa/enable":
            sec = str(b.get("secret", "")).strip()
            code = str(b.get("code", "")).strip()
            if not verify_totp(sec, code):
                return self.out(400, {"error": "Invalid 6-digit code. Please check your authenticator app."})
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_secret', ?)", (sec,))
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_enabled', '1')")
                db_conn.commit()
            return self.out(200, {"ok": True})

        if ep == "2fa/disable":
            pw = str(b.get("password", ""))
            stored_pw = get_meta("pw")
            salt = get_meta("salt")
            if not hmac.compare_digest(hashpw(pw, salt), stored_pw):
                return self.out(403, {"error": "Invalid admin password"})
            with lock:
                db_conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('totp_enabled', '0')")
                db_conn.commit()
            return self.out(200, {"ok": True})

        # Clean Subscription Info & Rotate
        if ep == "clean-sub":
            tok = get_meta("sub_token")
            with lock:
                h_count = db_conn.execute("""
                    SELECT COUNT(*) AS c FROM configs c
                    JOIN (SELECT config_id, ok, MAX(checked_at) AS max_t FROM checks GROUP BY config_id) ch ON ch.config_id = c.id
                    WHERE c.enabled=1 AND ch.ok=1
                    AND c.id NOT IN (SELECT config_id FROM incidents WHERE resolved_at IS NULL)
                """).fetchone()["c"]
                tot_count = db_conn.execute("SELECT COUNT(*) AS c FROM configs").fetchone()["c"]
                protos = [r["protocol"] for r in db_conn.execute("SELECT DISTINCT protocol FROM configs WHERE enabled=1 AND protocol IS NOT NULL").fetchall()]
                countries = [dict(r) for r in db_conn.execute("SELECT DISTINCT country_code, country_name FROM configs WHERE enabled=1 AND country_code != '' AND country_code != 'XX'").fetchall()]
                for cc_item in countries:
                    cc_item["flag"] = country_flag(cc_item.get("country_code"))
            return self.out(200, {
                "token": tok,
                "url": f"/sub/{tok}",
                "healthy_count": h_count,
                "total_count": tot_count,
                "protocols": protos,
                "countries": countries,
                "public_url": share_clean_url()
            })

        if ep == "clean-sub/rotate":
            new_tok = svc_rotate_feed()
            return self.out(200, {"ok": True, "token": new_tok, "url": f"/sub/{new_tok}"})

        # Subscriptions
        if ep == "subscriptions":
            with lock:
                rows = [dict(r) for r in db_conn.execute("SELECT id, name, url, interval_hours, enabled, last_sync, last_ok, last_msg, config_count, created_at FROM subscriptions ORDER BY created_at DESC")]
            return self.out(200, {"subscriptions": rows})

        if ep == "subscriptions/add":
            try:
                hrs = int(b.get("interval_hours", 6))
            except (TypeError, ValueError):
                hrs = 0
            ok, res = svc_add_sub(b.get("url", ""), b.get("name", ""), hrs) if hrs in (1, 6, 12, 24) else (False, "Interval must be 1, 6, 12 or 24 hours")
            if not ok:
                code = 409 if "already" in res else 502 if res.startswith("Could not fetch") else 400
                return self.out(code, {"error": res})
            return self.out(200, res)

        if ep == "subscriptions/sync":
            res = sync_sub(str(b.get("id", "")))
            return self.out(200 if res.get("ok") else 502, res)

        if ep == "subscriptions/update":
            sid = str(b.get("id", ""))
            try:
                err = svc_update_sub(sid, b.get("interval_hours"), b.get("enabled") if "enabled" in b else None, b.get("name"))
            except (TypeError, ValueError):
                err = "Interval must be 1, 6, 12 or 24 hours"
            if err:
                return self.out(404 if err == "not found" else 400, {"error": err})
            return self.out(200, {"ok": True})

        if ep == "subscriptions/delete":
            svc_delete_sub(str(b.get("id", "")), bool(b.get("delete_configs")))
            return self.out(200, {"ok": True})

        if ep == "sparks":
            since = int(time.time()) - 3600
            with lock:
                rows = db_conn.execute("SELECT config_id, ok, latency_ms FROM checks WHERE checked_at>=? ORDER BY checked_at ASC", (since,)).fetchall()
            sp = {}
            for r in rows:
                sp.setdefault(r["config_id"], []).append(r["latency_ms"] if r["ok"] else None)
            return self.out(200, {k: v[-40:] for k, v in sp.items()})

        # History Chart Data
        if ep == "history":
            range_key = qs.get("range", ["24h"])[0]
            seconds_map = {"1h": 3600, "24h": 86400, "7d": 7 * 86400, "30d": 30 * 86400}
            span = seconds_map.get(range_key, 86400)
            since = int(time.time()) - span
            cfg_id = qs.get("id", [None])[0]
            if qs.get("buckets"):  # the dashboard chart; the drawer still takes raw points
                nb = qs["buckets"][0]
                return self.out(200, history_buckets(range_key, cfg_id, int(nb) if nb.isdigit() else 60))

            with lock:
                if cfg_id:
                    cur = db_conn.execute(
                        "SELECT checked_at, ok, latency_ms FROM checks WHERE config_id=? AND checked_at >= ? ORDER BY checked_at ASC",
                        (cfg_id, since)
                    )
                else:
                    cur = db_conn.execute(
                        "SELECT checked_at, ok, latency_ms FROM checks WHERE checked_at >= ? ORDER BY checked_at ASC",
                        (since,)
                    )
                rows = [dict(r) for r in cur.fetchall()]
            return self.out(200, {"points": rows, "span": span})

        # Incidents List
        if ep == "incidents":
            with lock:
                cur = db_conn.execute("""
                    SELECT i.id, i.config_id, i.started_at, i.resolved_at, i.last_error, i.diag_verdict, c.name, c.addr
                    FROM incidents i
                    JOIN configs c ON c.id = i.config_id
                    ORDER BY i.started_at DESC LIMIT 100
                """)
                return self.out(200, {"incidents": [dict(r) for r in cur.fetchall()]})

        # Settings
        if ep == "settings":
            err = svc_apply_settings(b)
            if err:
                return self.out(400, {"error": err})
            return self.out(200, {"ok": True})

        # Action: Check Now
        if ep == "check-now":
            wake.set()
            return self.out(200, {"ok": True})

        # Action: Test Telegram
        if ep == "test-telegram":
            ok, used, attempts = send_telegram(
                "🛡️ <b>پیام تست سیستم پایشگر Sentinel</b>\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                "✅ ارتباط سرور و ربات تلگرام با موفقیت برقرار شد!\n"
                "⚡ پیام از طریق مسیریابی هوشمند ارسال گردید.\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                "<i>از دکمه‌های شیشه‌ای زیر برای تعامل با ربات استفاده کنید:</i>",
                reply_markup=scr_main()[1],
                record_trace=True
            )
            return self.out(200, {
                "ok": ok,
                "used_node": used["name"] if used else None,
                "used_addr": used["addr"] if used else None,
                "attempts": attempts
            })

        if ep in API_ROUTES:
            return API_ROUTES[ep](self, method, b, qs)
        return self.out(404)

def setup_ssl(srv, port, path):
    cert_file = os.getenv("SENTINEL_SSL_CERT", D + "/certs/cert.pem")
    key_file = os.getenv("SENTINEL_SSL_KEY", D + "/certs/key.pem")
    use_https = os.getenv("SENTINEL_USE_HTTPS", "").lower() in ("1", "true", "yes") or get_settings().get("use_https") == "1"

    if use_https:
        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        try:
            ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
        except (OSError, ssl.SSLError) as e:
            # A missing or broken certificate (e.g. the Hashem panel's, passed in
            # SENTINEL_SSL_CERT) must not crash-loop the service: fall back to
            # Sentinel's own self-signed one.
            if os.getenv("SENTINEL_SSL_CERT"):
                print(f"Sentinel: cannot load {cert_file} ({e}); using the self-signed certificate", flush=True)
            cert_file, key_file = D + "/certs/cert.pem", D + "/certs/key.pem"
            if not (os.path.exists(cert_file) and os.path.exists(key_file)):
                os.makedirs(os.path.dirname(cert_file), exist_ok=True)
                subprocess.run([
                    "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "3650",
                    "-keyout", key_file, "-out", cert_file,
                    "-subj", "/CN=sentinel"
                ], check=True, capture_output=True)
                os.chmod(key_file, 0o600)
                os.chmod(cert_file, 0o644)
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
        # The handshake runs in each request's thread, not in accept(), so one
        # slow or plain-HTTP client cannot stall the whole panel.
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True, do_handshake_on_connect=False)
        return "https"
    return "http"

def selftest():
    init_db()
    assert get_meta("path") is not None

    # 1. VLESS test
    test_vless = "vless://11111111-1111-1111-1111-111111111111@127.0.0.1:443?type=ws&security=tls&sni=example.com&path=%2Fws#🇩🇪 My VLESS"
    u, q, name = parse_vless(test_vless)
    assert name == "🇩🇪 My VLESS"
    c1 = {"id": "test1", "name": name, "uri": test_vless, "addr": "127.0.0.1:443", "port": 41001}
    out1 = outbound_for(c1)
    assert out1["protocol"] == "vless"

    # 2. Trojan test
    test_trojan = "trojan://password123@tr.example.com:443?security=tls&sni=tr.example.com#🇫🇮 My Trojan"
    c2 = {"id": "test2", "name": "My Trojan", "uri": test_trojan, "addr": "tr.example.com:443", "port": 41002}
    out2 = outbound_for(c2)
    assert out2["protocol"] == "trojan"
    assert out2["settings"]["servers"][0]["password"] == "password123"

    # 3. Shadowsocks test
    test_ss = "ss://YWVzLTEyOC1nY206cGFzc3dvcmQ=@ss.example.com:8388#Shadowsocks-Node"
    c3 = {"id": "test3", "name": "Shadowsocks-Node", "uri": test_ss, "addr": "ss.example.com:8388", "port": 41003}
    out3 = outbound_for(c3)
    assert out3["protocol"] == "shadowsocks"

    # 4. VMess test
    vm_json = json.dumps({"add": "vm.example.com", "port": 443, "id": "11111111-1111-1111-1111-111111111111", "net": "ws", "tls": "tls", "ps": "VMess-Node"})
    test_vmess = "vmess://" + base64.b64encode(vm_json.encode()).decode()
    c4 = {"id": "test4", "name": "VMess-Node", "uri": test_vmess, "addr": "vm.example.com:443", "port": 41004}
    out4 = outbound_for(c4)
    assert out4["protocol"] == "vmess"

    # 4b. Hysteria2: port hopping list, salamander, pinned cert
    test_hy2 = "hysteria2://p%40ss@hy.example.com:443,20000-30000/?sni=real.example.com&obfs=salamander&obfs-password=ob&insecure=1&pinSHA256=AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA#HY2"
    info = parse_proxy_uri(test_hy2)
    assert (info["protocol"], info["host"], info["port"], info["password"], info["name"]) == ("hysteria2", "hy.example.com", 443, "p@ss", "HY2")
    c5 = {"id": "test5", "uri": test_hy2, "port": 41005}
    out5 = outbound_for(c5)
    assert out5["protocol"] == "hysteria" and out5["settings"] == {"version": 2, "address": "hy.example.com", "port": 443}
    st5 = out5["streamSettings"]
    assert st5["network"] == "hysteria" and st5["hysteriaSettings"]["auth"] == "p@ss"
    assert st5["tlsSettings"]["serverName"] == "real.example.com" and st5["tlsSettings"]["pinnedPeerCertSha256"] == "AA" * 32
    assert "allowInsecure" not in st5["tlsSettings"]
    assert st5["finalmask"]["udp"][0] == {"type": "salamander", "settings": {"password": "ob"}}
    plain_hy2 = outbound_for({"id": "t", "uri": "hy2://pw@[2001:db8::1]:8443?insecure=1#v6"})
    assert plain_hy2["settings"]["address"] == "2001:db8::1" and plain_hy2["settings"]["port"] == 8443
    assert "finalmask" not in plain_hy2["streamSettings"]
    assert parse_proxy_uri("hy2://pw@h.example.com")["port"] == 443
    for bad in ("hy2://pw@h.example.com?obfs=gecko", "shadowtls://p@h.example.com:443", "hysteria://h.example.com:443?protocol=faketcp"):
        try: parse_proxy_uri(bad); assert False, bad
        except ValueError: pass

    # 4c. Newer Xray refuses allowInsecure: drop it instead of breaking every config
    insecure_vless = test_vless.replace("&path", "&allowInsecure=1&path")
    assert outbound_for({"id": "t", "uri": insecure_vless})["streamSettings"]["tlsSettings"]["allowInsecure"] is True
    CAPS["insecure"] = False
    assert "allowInsecure" not in outbound_for({"id": "t", "uri": insecure_vless})["streamSettings"]["tlsSettings"]
    assert insecure_dropped(insecure_vless) and not insecure_dropped(test_vless) and not insecure_dropped(test_hy2)
    CAPS["insecure"] = True

    # 4d. WireGuard and SOCKS
    test_wg = "wireguard://aGVsbG8+key=@162.159.192.1:2408?publickey=bmV3+pub=&address=172.16.0.2/32,2606:4700::2/128&mtu=1280&reserved=1,2,3#WARP"
    out6 = outbound_for({"id": "test6", "uri": test_wg})
    w = out6["settings"]
    assert out6["protocol"] == "wireguard" and w["secretKey"] == "aGVsbG8+key=" and w["peers"][0]["publicKey"] == "bmV3+pub="
    assert w["address"] == ["172.16.0.2/32", "2606:4700::2/128"] and w["mtu"] == 1280 and w["reserved"] == [1, 2, 3]
    assert w["peers"][0]["endpoint"] == "162.159.192.1:2408"
    # An unescaped "/" in a base64 key or password must not cut the link.
    w2 = outbound_for({"id": "t", "uri": "wg://ab/cd+e=@9.9.9.9:2408/?publickey=x/y&address=10.0.0.2/32#W"})["settings"]
    assert w2["secretKey"] == "ab/cd+e=" and w2["peers"][0]["endpoint"] == "9.9.9.9:2408"
    h2 = parse_proxy_uri("hysteria2://pa/ss@h.example.com:443/?sni=h.example.com#H")
    assert (h2["password"], h2["host"], h2["port"]) == ("pa/ss", "h.example.com", 443)
    try: parse_proxy_uri("wg://key@1.2.3.4:51820?publickey=x"); assert False
    except ValueError: pass
    test_socks = "socks://" + base64.b64encode(b"u:p").decode() + "@so.example.com:1080#SOCKS"
    out7 = outbound_for({"id": "test7", "uri": test_socks})
    assert out7["settings"]["servers"][0] == {"address": "so.example.com", "port": 1080, "users": [{"user": "u", "pass": "p"}]}
    assert "users" not in outbound_for({"id": "t", "uri": "socks5://so.example.com:1080"})["settings"]["servers"][0]

    # 5. Full Xray config test
    cfg = gen_xray_config([c1, c2, c3, c4, c5])
    assert len(cfg["inbounds"]) == 5
    assert len(cfg["outbounds"]) == 5

    # 6. Flag and CC tests
    assert flag_to_cc("🇩🇪 Germany") == "DE"
    assert country_flag("DE") == "🇩🇪"
    assert country_flag("FI") == "🇫🇮"

    # 7. Sub decode test (all 4 protocols included)
    plain = f"{test_vless}\n{test_trojan}\n{test_ss}\n{test_vmess}\n{test_hy2}\ntuic://u:p@t.example.com:443\n"
    decoded = decode_sub(plain)
    assert len(decoded) == 6
    assert test_vmess in decoded and test_hy2 in decoded
    assert decode_sub(base64.b64encode(test_hy2.encode()).decode()) == [test_hy2]

    for bad in ("hello world", "bm90X2FfcHJveHk="):
        try: decode_sub(bad); assert False
        except ValueError: pass
    for t in SELFTESTS:
        t()
    print("Sentinel backend selftest PASSED (Multi-Protocol, GeoIP, SLA, Sub Filters).")

if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
        sys.exit(0)
    init_db()
    restart_xray()
    threading.Thread(target=worker_loop, daemon=True).start()
    threading.Thread(target=telegram_bot_worker, daemon=True).start()
    port = int(get_meta("port"))
    srv = ThreadingHTTPServer(("0.0.0.0", port), SentinelHandler)
    proto = setup_ssl(srv, port, get_meta("path"))
    print(f"Sentinel running on {proto}://0.0.0.0:{port}/{get_meta('path')}/", flush=True)
    srv.serve_forever()
